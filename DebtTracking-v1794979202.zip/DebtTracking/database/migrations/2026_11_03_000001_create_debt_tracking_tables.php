<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('debt_tracking_entries')) {
            Schema::create('debt_tracking_entries', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('branch_id')->index();
                $table->string('record_no', 40);
                $table->enum('record_type', ['payable', 'receivable'])->comment('payable: ödenecek borç; receivable: tahsil edilecek alacak');
                $table->string('party_name', 180);
                $table->string('party_contact', 120)->nullable();
                $table->string('party_phone', 40)->nullable();
                $table->string('party_email', 150)->nullable();
                $table->string('title', 180);
                $table->text('description')->nullable();
                $table->date('document_date')->nullable();
                $table->string('document_no', 80)->nullable();
                $table->date('due_date');
                $table->decimal('amount', 16, 2);
                $table->string('currency', 3)->default('TRY');
                $table->enum('status', ['open', 'partial', 'paid'])->default('open');
                $table->string('category', 100)->nullable();
                $table->string('attachment_path')->nullable();
                $table->string('attachment_name')->nullable();
                $table->text('notes')->nullable();
                $table->unsignedBigInteger('created_by')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['branch_id', 'record_no'], 'dte_branch_record_uq');
                $table->index(['branch_id', 'record_type', 'status', 'due_date'], 'dte_branch_due_idx');
                $table->index(['branch_id', 'party_name'], 'dte_branch_party_idx');
            });
        }

        if (!Schema::hasTable('debt_tracking_payments')) {
            Schema::create('debt_tracking_payments', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('branch_id')->index();
                $table->unsignedBigInteger('entry_id')->index();
                $table->date('payment_date');
                $table->decimal('amount', 16, 2);
                $table->string('currency', 3)->default('TRY');
                $table->unsignedBigInteger('bank_account_id')->nullable()->index();
                $table->string('bank_name_snapshot', 160)->nullable();
                $table->string('bank_reference', 100)->nullable();
                $table->enum('payment_method', ['bank_transfer', 'cash', 'credit_card', 'check', 'other'])->default('bank_transfer');
                $table->string('receipt_path')->nullable();
                $table->string('receipt_name')->nullable();
                $table->text('notes')->nullable();
                $table->unsignedBigInteger('recorded_by')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->index(['branch_id', 'payment_date'], 'dtp_branch_date_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('debt_tracking_payments');
        Schema::dropIfExists('debt_tracking_entries');
    }
};

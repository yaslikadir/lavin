<?php
use Illuminate\Support\Facades\Route;
use Modules\DebtTracking\Http\Controllers\DashboardController;
use Modules\DebtTracking\Http\Controllers\EntryController;
use Modules\DebtTracking\Http\Controllers\PaymentController;

Route::middleware(['check.module:debt-tracking'])->prefix('debt-tracking')->name('debt-tracking.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/entries', [EntryController::class, 'index'])->name('index');
    Route::get('/entries/create', [EntryController::class, 'create'])->name('create');
    Route::post('/entries', [EntryController::class, 'store'])->name('store');
    Route::get('/entries/{id}/edit', [EntryController::class, 'edit'])->name('edit');
    Route::put('/entries/{id}', [EntryController::class, 'update'])->name('update');
    Route::delete('/entries/{id}', [EntryController::class, 'destroy'])->name('destroy');
    Route::get('/entries/{id}/attachment', [EntryController::class, 'attachment'])->name('attachment');
    Route::get('/entries/{id}', [EntryController::class, 'show'])->name('show');
    Route::post('/entries/{entryId}/payments', [PaymentController::class, 'store'])->name('payments.store');
    Route::get('/payments', [PaymentController::class, 'index'])->name('payments.index');
    Route::get('/payments/{id}/receipt', [PaymentController::class, 'receipt'])->name('payments.receipt');
});

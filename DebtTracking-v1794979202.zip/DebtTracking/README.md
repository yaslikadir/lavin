# Borç Alacak Takip modülü

Borç Alacak Takip, modüler Laravel ERP yapısına uygun bağımsız bir modüldür. ZIP arşivinin içindeki `DebtTracking/` klasörü, uygulamanızın `modules/` klasörüne çıkarılmalıdır.

## Özellikler

- Ödenecek borç ve tahsil edilecek alacak kayıtları
- Kişi/kurum, iletişim, fatura/belge no, kategori, açıklama ve dosya eki
- Vade tarihi, para birimi, açık/kısmi/tamamlandı durumu
- Kısmi ve tam ödeme/tahsilat, işlem geçmişi, isteğe bağlı banka hesabı ve dekont
- Vadesi önümüzdeki 15 gün içinde olanlar ile vadesi geçmiş kayıtlar için dashboard
- Aktif şube bazında veri izolasyonu ve banka hesabı şube kontrolü
- Türkçe DataTables, 10/25/50/100 sayfa seçimi ve Excel aktarımı

## Kurulum

1. `DebtTracking.zip` içindeki `DebtTracking/` klasörünü uygulamadaki `modules/` dizinine çıkarın.
2. Modül keşif mekanizmanız manifest içindeki `provider` değerini okuyorsa provider otomatik kaydolur. Gerekiyorsa `Modules\\DebtTracking\\Providers\\DebtTrackingServiceProvider` sınıfını kendi modül kayıt mekanizmanıza tanıtın.
3. Uygulama kökünde `php artisan migrate --path=modules/DebtTracking/database/migrations/2026_11_03_000001_create_debt_tracking_tables.php --force` çalıştırın.
4. `php artisan optimize:clear` çalıştırın ve kullanıcı/rol yetkilerinizde `debt-tracking` modül iznini açın. Route middleware `check.module:debt-tracking` kullanır.
5. Modül sayfaları `/admin/debt-tracking` altında, route adları `admin.debt-tracking.*` biçimindedir.

## Önemli davranış

- Tüm kayıtlar `session('active_branch_id')` ile seçilen şubeye yazılır ve her sorguda aynı şubeyle sınırlandırılır. İşlem için aktif şube seçili olmalıdır.
- Banka hesabı zorunlu değildir. Hesap seçilirse `bank_accounts` tablosunda aynı `branch_id` değerine sahip hesap olması aranır; varsa pasif hesaplar dışlanır. Banka paketi kurulu değilse boş bırakılarak ödeme/tahsilat yapılabilir.
- Ödeme ve tahsilatlar silinmez; her hareket ayrı geçmiş kaydıdır. Kayıt tutarı, yapılan ödemelerin toplamından aşağı indirilemez; kalan bakiyeden fazla ödeme girilemez.
- Yüklenen belgeler Laravel `local` diskinde `storage/app/debt-tracking/{şube}/` altında tutulur. Web sunucusunun bu depolama dizinine yazma izni bulunmalıdır.
- Para birimleri birbirine çevrilmez; dashboard bakiyeleri para birimi bazında gösterilir.

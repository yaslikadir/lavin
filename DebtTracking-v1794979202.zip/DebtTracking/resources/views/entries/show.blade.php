@extends('layouts.admin')
@include('debttracking::partials.styles')
@section('title', 'Borç / Alacak Detayı')
@section('content')
@php($paid=(float)$record->payments->sum('amount'))
@php($remaining=max(0,(float)$record->amount-$paid))
<div class="container-fluid px-3 px-lg-4 py-4 dt-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><div class="text-muted">{{ $record->record_no }}</div><h1 class="h3 mb-0">{{ $record->title }}</h1></div><div class="d-flex gap-2"><a class="btn btn-outline-secondary" href="{{ route('admin.debt-tracking.index') }}">Listeye dön</a>@if($record->status!=='paid')<a class="btn btn-outline-primary" href="{{ route('admin.debt-tracking.edit',$record->id) }}">Düzenle</a>@endif</div></div>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger"><strong>Ödeme kaydedilemedi:</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
    <div class="row g-3 mb-3">
        <div class="col-md-4"><div class="card dt-stat dt-gradient-1"><div class="card-body"><small>{{ $record->record_type==='payable'?'Ödenecek borç':'Tahsil edilecek alacak' }}</small><div class="value">{{ number_format((float)$record->amount,2,',','.') }} {{ $record->currency }}</div><div>{{ $record->party_name }}</div></div></div></div>
        <div class="col-md-4"><div class="card dt-stat dt-gradient-2"><div class="card-body"><small>Ödenen / tahsil edilen</small><div class="value">{{ number_format($paid,2,',','.') }} {{ $record->currency }}</div><div>{{ $record->payments->count() }} işlem kaydı</div></div></div></div>
        <div class="col-md-4"><div class="card dt-stat {{ $remaining>0?'dt-gradient-3':'dt-gradient-2' }}"><div class="card-body"><small>Kalan bakiye</small><div class="value">{{ number_format($remaining,2,',','.') }} {{ $record->currency }}</div><div>Vade: {{ $record->due_date->format('d.m.Y') }}</div></div></div></div>
    </div>
    <div class="row g-3">
        <div class="col-xl-5"><div class="card dt-card h-100"><div class="card-header fw-semibold">Kayıt bilgileri</div><div class="card-body"><dl class="row mb-0">
            <dt class="col-5">Kayıt türü</dt><dd class="col-7">{{ $record->record_type==='payable'?'Ödenecek borç':'Tahsil edilecek alacak' }}</dd>
            <dt class="col-5">Kişi / kurum</dt><dd class="col-7">{{ $record->party_name }}</dd>
            <dt class="col-5">İlgili kişi</dt><dd class="col-7">{{ $record->party_contact ?: '—' }}</dd>
            <dt class="col-5">Telefon / e-posta</dt><dd class="col-7">{{ $record->party_phone ?: '—' }}<br>{{ $record->party_email ?: '' }}</dd>
            <dt class="col-5">Kategori</dt><dd class="col-7">{{ $record->category ?: '—' }}</dd>
            <dt class="col-5">Belge numarası</dt><dd class="col-7">{{ $record->document_no ?: '—' }}</dd>
            <dt class="col-5">Belge tarihi</dt><dd class="col-7">{{ $record->document_date?->format('d.m.Y') ?: '—' }}</dd>
            <dt class="col-5">Durum</dt><dd class="col-7">{{ ['open'=>'Açık','partial'=>'Kısmi ödendi/tahsil edildi','paid'=>'Tamamlandı'][$record->status] ?? $record->status }}</dd>
            <dt class="col-5">Açıklama</dt><dd class="col-7">{{ $record->description ?: '—' }}</dd>
            <dt class="col-5">İç not</dt><dd class="col-7">{{ $record->notes ?: '—' }}</dd>
            @if($record->attachment_path)<dt class="col-5">Ek belge</dt><dd class="col-7"><a href="{{ route('admin.debt-tracking.attachment',$record->id) }}">{{ $record->attachment_name ?: 'Belgeyi indir' }}</a></dd>@endif
        </dl></div></div></div>
        <div class="col-xl-7"><div class="card dt-card mb-3"><div class="card-header fw-semibold">{{ $record->record_type==='payable'?'Ödeme kaydı ekle':'Tahsilat kaydı ekle' }}</div><div class="card-body">
            @if($remaining>0)
            <form method="POST" enctype="multipart/form-data" action="{{ route('admin.debt-tracking.payments.store',$record->id) }}"><div class="row g-3">@csrf
                <div class="col-md-4"><label class="form-label">İşlem tarihi *</label><input class="form-control" type="date" name="payment_date" value="{{ old('payment_date',today()->format('Y-m-d')) }}" required></div>
                <div class="col-md-4"><label class="form-label">Tutar (kalan: {{ number_format($remaining,2,',','.') }} {{ $record->currency }}) *</label><input class="form-control" type="number" min="0.01" max="{{ number_format($remaining,2,'.','') }}" step="0.01" name="amount" value="{{ old('amount') }}" required></div>
                <div class="col-md-4"><label class="form-label">İşlem yöntemi *</label><select class="form-select" name="payment_method" required><option value="bank_transfer">Banka havalesi / EFT</option><option value="cash">Nakit</option><option value="credit_card">Kredi kartı</option><option value="check">Çek</option><option value="other">Diğer</option></select></div>
                <div class="col-md-6"><label class="form-label">Banka hesabı (isteğe bağlı)</label><select class="form-select" name="bank_account_id"><option value="">Banka hesabı seçmeden devam et</option>@foreach($bankAccounts as $bank)<option value="{{ $bank->id }}">{{ $bank->bank_name ?? 'Banka hesabı' }}{{ !empty($bank->account_name)?' · '.$bank->account_name:'' }}{{ !empty($bank->iban)?' · '.$bank->iban:'' }}</option>@endforeach</select><div class="form-text">Banka seçmek zorunlu değildir.</div></div>
                <div class="col-md-6"><label class="form-label">Banka işlem / dekont referansı</label><input class="form-control" name="bank_reference" value="{{ old('bank_reference') }}"></div>
                <div class="col-md-6"><label class="form-label">Dekont</label><input class="form-control" type="file" name="receipt" accept=".pdf,.jpg,.jpeg,.png"></div>
                <div class="col-md-6"><label class="form-label">İşlem notu</label><input class="form-control" name="notes"></div>
            </div><div class="text-end mt-3"><button class="btn btn-success">{{ $record->record_type==='payable'?'Ödemeyi kaydet':'Tahsilatı kaydet' }}</button></div></form>
            @else<div class="alert alert-success mb-0">Bu kayıt tamamen kapatılmıştır.</div>@endif
        </div></div>
        <div class="card dt-card"><div class="card-header fw-semibold">Ödeme / tahsilat geçmişi</div><div class="table-responsive"><table id="debtPaymentsTable" class="table table-hover align-middle mb-0"><thead><tr><th>Tarih</th><th>Tutar</th><th>Yöntem</th><th>Banka</th><th>Referans</th><th>Dekont</th><th>Not</th></tr></thead><tbody>
            @foreach($record->payments as $payment)<tr><td>{{ $payment->payment_date->format('d.m.Y') }}</td><td>{{ number_format((float)$payment->amount,2,',','.') }} {{ $payment->currency }}</td><td>{{ ['bank_transfer'=>'Havale / EFT','cash'=>'Nakit','credit_card'=>'Kredi kartı','check'=>'Çek','other'=>'Diğer'][$payment->payment_method] ?? $payment->payment_method }}</td><td>{{ $payment->bank_name_snapshot ?: ($payment->bank_account_id ? 'Banka hesabı #'.$payment->bank_account_id : 'Belirtilmedi') }}</td><td>{{ $payment->bank_reference ?: '—' }}</td><td>@if($payment->receipt_path)<a href="{{ route('admin.debt-tracking.payments.receipt',$payment->id) }}">Dekontu indir</a>@else—@endif</td><td>{{ $payment->notes ?: '—' }}</td></tr>@endforeach
        </tbody></table></div></div></div>
    </div>
</div>
@endsection
@include('debttracking::partials.datatable',['tableId'=>'debtPaymentsTable','title'=>'Ödeme ve tahsilat geçmişi'])

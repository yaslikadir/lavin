@extends('layouts.admin')
@include('debttracking::partials.styles')
@section('title', 'Borç / Alacak Listesi')
@section('content')
<div class="container-fluid px-3 px-lg-4 py-4 dt-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div><h1 class="h3 mb-1">Borç / Alacak Takibi</h1><div class="text-muted">Borçlarınızı, tahsil edilecek alacaklarınızı ve vade durumlarını izleyin.</div></div>
        <a class="btn btn-primary" href="{{ route('admin.debt-tracking.create') }}">+ Yeni borç / alacak</a>
    </div>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    <form class="card dt-card mb-3"><div class="card-body"><div class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label">Ara</label><input class="form-control" name="q" value="{{ request('q') }}" placeholder="Kayıt no, kişi/kurum, konu"></div>
        <div class="col-md-2"><label class="form-label">Kayıt türü</label><select class="form-select" name="type"><option value="">Tümü</option><option value="payable" @selected(request('type')==='payable')>Ödenecek borç</option><option value="receivable" @selected(request('type')==='receivable')>Tahsil edilecek alacak</option></select></div>
        <div class="col-md-2"><label class="form-label">Durum</label><select class="form-select" name="status"><option value="">Tümü</option><option value="open" @selected(request('status')==='open')>Açık</option><option value="partial" @selected(request('status')==='partial')>Kısmi ödendi</option><option value="paid" @selected(request('status')==='paid')>Tamamlandı</option></select></div>
        <div class="col-md-2"><label class="form-label">Vade başlangıcı</label><input type="date" class="form-control" name="from" value="{{ request('from') }}"></div>
        <div class="col-md-2"><label class="form-label">Vade bitişi</label><input type="date" class="form-control" name="to" value="{{ request('to') }}"></div>
        <div class="col-md-1 d-grid"><button class="btn btn-outline-primary">Süz</button></div>
    </div></div></form>
    <div class="card dt-card"><div class="table-responsive"><table id="debtEntriesTable" class="table table-hover align-middle mb-0 w-100">
        <thead><tr><th>Kayıt no</th><th>Tür</th><th>Kişi / kurum</th><th>Konu</th><th>Belge no</th><th>Vade</th><th>Tutar</th><th>Ödenen / tahsil edilen</th><th>Kalan</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>
        @foreach($records as $record)
            @php($paid=(float)($record->payments_sum_amount ?? 0))
            @php($left=max(0,(float)$record->amount-$paid))
            <tr>
                <td><a href="{{ route('admin.debt-tracking.show',$record->id) }}">{{ $record->record_no }}</a></td>
                <td><span class="badge {{ $record->record_type==='payable'?'text-bg-warning':'text-bg-success' }}">{{ $record->record_type==='payable'?'Ödenecek':'Tahsil edilecek' }}</span></td>
                <td>{{ $record->party_name }}</td><td>{{ $record->title }}</td><td>{{ $record->document_no ?: '—' }}</td>
                <td data-order="{{ $record->due_date->format('Y-m-d') }}">{{ $record->due_date->format('d.m.Y') }} @if($left>0 && $record->due_date->isPast() && !$record->due_date->isToday())<span class="badge text-bg-danger">Gecikmiş</span>@endif</td>
                <td>{{ number_format((float)$record->amount,2,',','.') }} {{ $record->currency }}</td><td>{{ number_format($paid,2,',','.') }} {{ $record->currency }}</td><td class="fw-semibold">{{ number_format($left,2,',','.') }} {{ $record->currency }}</td>
                <td><span class="badge {{ $record->status==='paid'?'text-bg-secondary':($record->status==='partial'?'text-bg-info':'text-bg-primary') }}">{{ ['open'=>'Açık','partial'=>'Kısmi','paid'=>'Tamamlandı'][$record->status] ?? $record->status }}</span></td>
                <td class="text-nowrap"><a class="btn btn-sm btn-outline-primary" href="{{ route('admin.debt-tracking.show',$record->id) }}">Detay</a> @if($record->status!=='paid')<a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.debt-tracking.edit',$record->id) }}">Düzenle</a>@endif</td>
            </tr>
        @endforeach
        </tbody></table></div></div>
</div>
@endsection
@include('debttracking::partials.datatable',['tableId'=>'debtEntriesTable','title'=>'Borç ve alacak listesi'])

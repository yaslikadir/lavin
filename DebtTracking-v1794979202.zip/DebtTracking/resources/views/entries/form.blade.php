@extends('layouts.admin')
@include('debttracking::partials.styles')
@section('title', $record->exists ? 'Borç / Alacak Düzenle' : 'Yeni Borç / Alacak')
@section('content')
<div class="container-fluid px-3 px-lg-4 py-4 dt-shell">
    <div class="d-flex justify-content-between align-items-center mb-3"><div><h1 class="h3">{{ $record->exists ? 'Borç / Alacak Düzenle' : 'Yeni Borç / Alacak Kaydı' }}</h1><p class="text-muted mb-0">Tür, taraf ve vade bilgilerini girin. Tutar daha sonra kısmi ödemelerle kapatılabilir.</p></div><a class="btn btn-outline-secondary" href="{{ $record->exists ? route('admin.debt-tracking.show',$record->id) : route('admin.debt-tracking.index') }}">Geri dön</a></div>
    @if($errors->any())<div class="alert alert-danger"><strong>Bilgileri kontrol edin:</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
    <form method="POST" enctype="multipart/form-data" action="{{ $record->exists ? route('admin.debt-tracking.update',$record->id) : route('admin.debt-tracking.store') }}" class="card dt-card"><div class="card-body"><div class="row g-3">
        <div class="col-md-4"><label class="form-label">Kayıt türü <span class="text-danger">*</span></label><select class="form-select" name="record_type" required><option value="payable" @selected(old('record_type',$record->record_type)==='payable')>Ödenecek borç (bizim borcumuz)</option><option value="receivable" @selected(old('record_type',$record->record_type)==='receivable')>Tahsil edilecek alacak (bize olan borç)</option></select></div>
        <div class="col-md-4"><label class="form-label">Kişi / kurum adı <span class="text-danger">*</span></label><input class="form-control" name="party_name" maxlength="180" value="{{ old('party_name',$record->party_name) }}" required></div>
        <div class="col-md-4"><label class="form-label">İlgili kişi</label><input class="form-control" name="party_contact" value="{{ old('party_contact',$record->party_contact) }}"></div>
        <div class="col-md-4"><label class="form-label">Telefon</label><input class="form-control" name="party_phone" value="{{ old('party_phone',$record->party_phone) }}"></div>
        <div class="col-md-4"><label class="form-label">E-posta</label><input class="form-control" type="email" name="party_email" value="{{ old('party_email',$record->party_email) }}"></div>
        <div class="col-md-4"><label class="form-label">Kategori</label><input class="form-control" name="category" placeholder="Malzeme, kira, hizmet vb." value="{{ old('category',$record->category) }}"></div>
        <div class="col-md-8"><label class="form-label">Konu / açıklama kısa başlığı <span class="text-danger">*</span></label><input class="form-control" name="title" maxlength="180" value="{{ old('title',$record->title) }}" required></div>
        <div class="col-md-4"><label class="form-label">Fatura / belge numarası</label><input class="form-control" name="document_no" value="{{ old('document_no',$record->document_no) }}"></div>
        <div class="col-12"><label class="form-label">Detay</label><textarea class="form-control" name="description" rows="3">{{ old('description',$record->description) }}</textarea></div>
        <div class="col-md-4"><label class="form-label">Belge tarihi</label><input class="form-control" type="date" name="document_date" value="{{ old('document_date',$record->document_date?->format('Y-m-d')) }}"></div>
        <div class="col-md-4"><label class="form-label">Vade tarihi <span class="text-danger">*</span></label><input class="form-control" type="date" name="due_date" value="{{ old('due_date',$record->due_date?->format('Y-m-d')) }}" required></div>
        <div class="col-md-4"><label class="form-label">Tutar <span class="text-danger">*</span></label><input class="form-control" type="number" name="amount" min="0.01" step="0.01" value="{{ old('amount',$record->amount) }}" required></div>
        <div class="col-md-4"><label class="form-label">Para birimi</label><select class="form-select" name="currency">@foreach(['TRY'=>'Türk lirası (TRY)','USD'=>'ABD doları (USD)','EUR'=>'Avro (EUR)','GBP'=>'İngiliz sterlini (GBP)'] as $code=>$label)<option value="{{ $code }}" @selected(old('currency',$record->currency ?: 'TRY')===$code)>{{ $label }}</option>@endforeach</select></div>
        <div class="col-md-8"><label class="form-label">Belge eki</label><input class="form-control" type="file" name="attachment" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"><div class="form-text">PDF, görsel veya Office belgesi; en fazla 20 MB.@if($record->attachment_name) Mevcut: {{ $record->attachment_name }}@endif</div></div>
        <div class="col-12"><label class="form-label">İç not</label><textarea class="form-control" name="notes" rows="2">{{ old('notes',$record->notes) }}</textarea></div>
    </div></div><div class="card-footer bg-white text-end">@csrf @if($record->exists)@method('PUT')@endif<button class="btn btn-primary">{{ $record->exists ? 'Değişiklikleri kaydet' : 'Kaydı oluştur' }}</button></div></form>
</div>
@endsection

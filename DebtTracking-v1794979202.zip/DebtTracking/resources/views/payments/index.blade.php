@extends('layouts.admin')
@include('debttracking::partials.styles')
@section('title', 'Ödeme ve Tahsilatlar')
@section('content')
<div class="container-fluid px-3 px-lg-4 py-4 dt-shell"><div class="mb-3"><h1 class="h3">Ödeme ve Tahsilat Geçmişi</h1><p class="text-muted">Aktif şubedeki tüm borç ödeme ve alacak tahsilat hareketleri.</p></div>
<div class="card dt-card"><div class="table-responsive"><table id="debtPaymentsTable" class="table table-hover align-middle mb-0"><thead><tr><th>Tarih</th><th>Kayıt no</th><th>Tür</th><th>Kişi / kurum</th><th>Konu</th><th>Tutar</th><th>Yöntem</th><th>Banka</th><th>Referans</th><th>Dekont</th></tr></thead><tbody>
@foreach($records as $payment)<tr><td>{{ $payment->payment_date->format('d.m.Y') }}</td><td>@if($payment->entry)<a href="{{ route('admin.debt-tracking.show',$payment->entry->id) }}">{{ $payment->entry->record_no }}</a>@else—@endif</td><td>{{ $payment->entry?->record_type==='payable'?'Ödeme':'Tahsilat' }}</td><td>{{ $payment->entry?->party_name ?: '—' }}</td><td>{{ $payment->entry?->title ?: '—' }}</td><td>{{ number_format((float)$payment->amount,2,',','.') }} {{ $payment->currency }}</td><td>{{ ['bank_transfer'=>'Havale / EFT','cash'=>'Nakit','credit_card'=>'Kredi kartı','check'=>'Çek','other'=>'Diğer'][$payment->payment_method] ?? $payment->payment_method }}</td><td>{{ $payment->bank_name_snapshot ?: ($payment->bank_account_id?'Banka hesabı #'.$payment->bank_account_id:'Belirtilmedi') }}</td><td>{{ $payment->bank_reference ?: '—' }}</td><td>@if($payment->receipt_path)<a href="{{ route('admin.debt-tracking.payments.receipt',$payment->id) }}">İndir</a>@else—@endif</td></tr>@endforeach
</tbody></table></div></div></div>
@endsection
@include('debttracking::partials.datatable',['tableId'=>'debtPaymentsTable','title'=>'Ödeme ve tahsilatlar'])

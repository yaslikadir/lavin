@once
    @push('css')
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">
    @endpush
    @push('scripts')
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    @endpush
@endonce
@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    var table = document.getElementById(@json($tableId));
    if (!table || !window.jQuery || !jQuery.fn.DataTable) return;
    jQuery(table).DataTable({
        dom: 'Blfrtip', pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        buttons: [{ extend: 'excelHtml5', text: 'Excel\'e aktar', title: @json($title ?? 'Borç Alacak Takip'), exportOptions: { columns: ':not(:last-child)' } }],
        order: [],
        language: {
            emptyTable: 'Kayıt bulunmuyor', info: '_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor',
            infoEmpty: 'Kayıt yok', infoFiltered: '(_MAX_ kayıt içinden süzüldü)',
            lengthMenu: '_MENU_ kayıt göster', search: 'Tabloda ara:', zeroRecords: 'Eşleşen kayıt bulunamadı',
            paginate: { first: 'İlk', last: 'Son', next: 'Sonraki', previous: 'Önceki' }
        }
    });
});
</script>
@endpush

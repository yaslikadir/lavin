@once
@push('css')
<style>
.dt-shell{--dt-ink:#182230;--dt-muted:#64748b;--dt-line:#e2e8f0}.dt-shell .dt-card{border:1px solid var(--dt-line);border-radius:16px;box-shadow:0 8px 26px rgba(15,23,42,.05)}.dt-shell .dt-stat{border:0;border-radius:16px;color:#fff;overflow:hidden;min-height:130px}.dt-shell .dt-stat small{opacity:.83}.dt-shell .dt-stat .value{font-size:1.65rem;font-weight:750;letter-spacing:-.03em}.dt-shell .dt-stat .icon{font-size:1.8rem;opacity:.78}.dt-shell .dt-gradient-1{background:linear-gradient(135deg,#1d4ed8,#4f46e5)}.dt-shell .dt-gradient-2{background:linear-gradient(135deg,#059669,#0f766e)}.dt-shell .dt-gradient-3{background:linear-gradient(135deg,#d97706,#ea580c)}.dt-shell .dt-gradient-4{background:linear-gradient(135deg,#dc2626,#be123c)}.dt-shell .table thead th{white-space:nowrap;background:#f8fafc;color:#334155;font-size:.82rem}.dt-shell .badge{font-weight:600}.dt-shell .form-label{font-weight:600;color:#334155}
</style>
@endpush
@endonce

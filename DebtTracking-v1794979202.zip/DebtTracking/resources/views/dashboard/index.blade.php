@extends('layouts.admin')
@include('debttracking::partials.styles')
@section('title', 'Borç / Alacak Özeti')
@section('content')
@php
    $byCurrency = static function ($records) {
        return $records->groupBy('currency')->map(function ($items) {
            return $items->sum(fn ($item) => max(0, (float)$item->amount - (float)($item->payments_sum_amount ?? 0)));
        });
    };
    $receivableTotals = $byCurrency($receivables);
    $payableTotals = $byCurrency($payables);
@endphp
<div class="container-fluid px-3 px-lg-4 py-4 dt-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4"><div><h1 class="h3 mb-1">Borç / Alacak Özeti</h1><div class="text-muted">Aktif şubenizin tahsilat ve ödeme takvimi</div></div><div class="d-flex gap-2"><a class="btn btn-outline-primary" href="{{ route('admin.debt-tracking.payments.index') }}">Ödeme geçmişi</a><a class="btn btn-primary" href="{{ route('admin.debt-tracking.create') }}">+ Yeni kayıt</a></div></div>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6"><div class="card dt-stat dt-gradient-1"><div class="card-body"><div class="d-flex justify-content-between"><div><small>Açık alacak bakiyesi</small>@forelse($receivableTotals as $currency=>$amount)<div class="value">{{ number_format($amount,2,',','.') }} <small>{{ $currency }}</small></div>@empty<div class="value">0,00</div>@endforelse</div><div class="icon">↗</div></div><a class="text-white" href="{{ route('admin.debt-tracking.index',['type'=>'receivable','status'=>'open']) }}">Alacak listesini aç</a></div></div></div>
        <div class="col-xl-3 col-md-6"><div class="card dt-stat dt-gradient-2"><div class="card-body"><div class="d-flex justify-content-between"><div><small>Açık borç bakiyesi</small>@forelse($payableTotals as $currency=>$amount)<div class="value">{{ number_format($amount,2,',','.') }} <small>{{ $currency }}</small></div>@empty<div class="value">0,00</div>@endforelse</div><div class="icon">↘</div></div><a class="text-white" href="{{ route('admin.debt-tracking.index',['type'=>'payable','status'=>'open']) }}">Borç listesini aç</a></div></div></div>
        <div class="col-xl-3 col-md-6"><div class="card dt-stat dt-gradient-3"><div class="card-body"><div class="d-flex justify-content-between"><div><small>Önümüzdeki 15 gün vadesi</small><div class="value">{{ $upcoming->count() }} kayıt</div></div><div class="icon">◷</div></div><small>Ödenecek borç: {{ $upcomingPayables->count() }} · Tahsil edilecek alacak: {{ $upcomingReceivables->count() }}</small><br><small>{{ $today->format('d.m.Y') }} – {{ $until->format('d.m.Y') }}</small></div></div></div>
        <div class="col-xl-3 col-md-6"><div class="card dt-stat dt-gradient-4"><div class="card-body"><div class="d-flex justify-content-between"><div><small>Vadesi geçmiş açık kayıt</small><div class="value">{{ $overdue->count() }} kayıt</div></div><div class="icon">!</div></div><small>Öncelikli takip gerektirir</small></div></div></div>
    </div>
    <div class="row g-3">
        <div class="col-xl-7"><div class="card dt-card h-100"><div class="card-header d-flex justify-content-between align-items-center"><strong>Önümüzdeki 15 günün vade takvimi</strong><a href="{{ route('admin.debt-tracking.index',['from'=>$today->format('Y-m-d'),'to'=>$until->format('Y-m-d')]) }}">Tümünü gör</a></div><div class="table-responsive"><table id="dueSoonTable" class="table table-hover align-middle mb-0"><thead><tr><th>Vade</th><th>Tür</th><th>Kişi / kurum</th><th>Konu</th><th>Kalan</th><th></th></tr></thead><tbody>
            @foreach($upcoming as $item)@php($left=max(0,(float)$item->amount-(float)($item->payments_sum_amount??0)))<tr><td>{{ $item->due_date->format('d.m.Y') }}</td><td>{{ $item->record_type==='payable'?'Ödenecek':'Tahsil edilecek' }}</td><td>{{ $item->party_name }}</td><td>{{ $item->title }}</td><td class="fw-semibold">{{ number_format($left,2,',','.') }} {{ $item->currency }}</td><td><a class="btn btn-sm btn-outline-primary" href="{{ route('admin.debt-tracking.show',$item->id) }}">Aç</a></td></tr>@endforeach
        </tbody></table></div></div></div>
        <div class="col-xl-5"><div class="card dt-card h-100"><div class="card-header"><strong>Gecikmiş borç ve alacaklar</strong></div><div class="list-group list-group-flush">
            @forelse($overdue->take(8) as $item)@php($left=max(0,(float)$item->amount-(float)($item->payments_sum_amount??0)))<a class="list-group-item list-group-item-action" href="{{ route('admin.debt-tracking.show',$item->id) }}"><div class="d-flex justify-content-between gap-2"><div><span class="badge {{ $item->record_type==='payable'?'text-bg-warning':'text-bg-success' }}">{{ $item->record_type==='payable'?'Borç':'Alacak' }}</span> <strong>{{ $item->party_name }}</strong><div class="small text-muted">{{ $item->title }} · Vade {{ $item->due_date->format('d.m.Y') }}</div></div><span class="text-danger fw-semibold text-nowrap">{{ number_format($left,2,',','.') }} {{ $item->currency }}</span></div></a>@empty<div class="p-4 text-center text-muted">Vadesi geçmiş açık kayıt bulunmuyor.</div>@endforelse
        </div></div></div>
    </div>
    <div class="card dt-card mt-3"><div class="card-header d-flex justify-content-between align-items-center"><strong>Son eklenen kayıtlar</strong><a href="{{ route('admin.debt-tracking.index') }}">Tüm liste</a></div><div class="table-responsive"><table id="recentDebtTable" class="table table-hover align-middle mb-0"><thead><tr><th>Kayıt no</th><th>Tür</th><th>Kişi / kurum</th><th>Konu</th><th>Vade</th><th>Tutar</th><th>Durum</th></tr></thead><tbody>
        @foreach($recent as $item)@php($left=max(0,(float)$item->amount-(float)($item->payments_sum_amount??0)))<tr><td><a href="{{ route('admin.debt-tracking.show',$item->id) }}">{{ $item->record_no }}</a></td><td>{{ $item->record_type==='payable'?'Ödenecek borç':'Tahsil edilecek alacak' }}</td><td>{{ $item->party_name }}</td><td>{{ $item->title }}</td><td>{{ $item->due_date->format('d.m.Y') }}</td><td>{{ number_format((float)$item->amount,2,',','.') }} {{ $item->currency }} <small class="text-muted">(kalan {{ number_format($left,2,',','.') }})</small></td><td>{{ ['open'=>'Açık','partial'=>'Kısmi','paid'=>'Tamamlandı'][$item->status]??$item->status }}</td></tr>@endforeach
        </tbody></table></div></div>
</div>
@endsection
@include('debttracking::partials.datatable',['tableId'=>'dueSoonTable','title'=>'Önümüzdeki 15 gün vade takvimi'])
@include('debttracking::partials.datatable',['tableId'=>'recentDebtTable','title'=>'Son borç ve alacak kayıtları'])

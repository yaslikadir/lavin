<?php
namespace Modules\DebtTracking\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DebtPayment extends Model
{
    use SoftDeletes;

    protected $table = 'debt_tracking_payments';
    protected $guarded = ['id'];
    protected $casts = [
        'payment_date' => 'date',
        'amount' => 'decimal:2',
    ];

    public function entry()
    {
        return $this->belongsTo(DebtEntry::class, 'entry_id');
    }
}

<?php
namespace Modules\DebtTracking\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DebtEntry extends Model
{
    use SoftDeletes;

    protected $table = 'debt_tracking_entries';
    protected $guarded = ['id'];
    protected $casts = [
        'document_date' => 'date',
        'due_date' => 'date',
        'amount' => 'decimal:2',
    ];

    public function payments()
    {
        return $this->hasMany(DebtPayment::class, 'entry_id')->whereNull('deleted_at');
    }

    public function getPaidAmountAttribute(): float
    {
        return (float) ($this->payments_sum_amount ?? $this->payments()->sum('amount'));
    }

    public function getRemainingAmountAttribute(): float
    {
        return max(0, (float) $this->amount - $this->paid_amount);
    }
}

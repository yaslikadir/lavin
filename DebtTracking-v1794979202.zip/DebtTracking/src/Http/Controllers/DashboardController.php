<?php
namespace Modules\DebtTracking\Http\Controllers;

use Illuminate\Support\Carbon;
use Modules\DebtTracking\Models\DebtEntry;

class DashboardController extends BaseController
{
    public function index()
    {
        $this->authorizeModule();
        $base = $this->scoped(DebtEntry::class)->withSum('payments', 'amount');
        $open = (clone $base)->whereIn('status', ['open', 'partial']);
        $receivables = (clone $open)->where('record_type', 'receivable')->get();
        $payables = (clone $open)->where('record_type', 'payable')->get();
        $today = Carbon::today();
        $until = $today->copy()->addDays(15);
        $upcoming = (clone $open)->whereBetween('due_date', [$today, $until])->orderBy('due_date')->get();
        $upcomingPayables = $upcoming->where('record_type', 'payable');
        $upcomingReceivables = $upcoming->where('record_type', 'receivable');
        $overdue = (clone $open)->whereDate('due_date', '<', $today)->orderBy('due_date')->get();
        $recent = $this->scoped(DebtEntry::class)->withSum('payments', 'amount')->latest('id')->limit(8)->get();
        return view('debttracking::dashboard.index', compact('receivables', 'payables', 'upcoming', 'upcomingPayables', 'upcomingReceivables', 'overdue', 'recent', 'today', 'until'));
    }
}

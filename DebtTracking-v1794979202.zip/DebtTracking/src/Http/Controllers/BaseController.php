<?php
namespace Modules\DebtTracking\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Schema;

abstract class BaseController extends Controller
{
    protected function branch(): int
    {
        $id = (int) session('active_branch_id', 0);
        abort_if($id < 1, 403, 'Devam etmek için önce aktif şube seçilmelidir.');
        return $id;
    }

    protected function authorizeModule(): void
    {
        $user = auth()->user();
        $allowed = $user && (
            (method_exists($user, 'isAdmin') && $user->isAdmin()) ||
            (method_exists($user, 'hasRole') && $user->hasRole('admin')) ||
            (method_exists($user, 'hasModuleAccess') && ($user->hasModuleAccess('debt-tracking') || $user->hasModuleAccess('debt_tracking'))) ||
            (method_exists($user, 'hasPermissionToAccessModule') && ($user->hasPermissionToAccessModule('debt-tracking') || $user->hasPermissionToAccessModule('debt_tracking')))
        );
        abort_unless($allowed, 403, 'Borç Alacak Takip modülüne erişim yetkiniz yok.');
        $this->branch();
    }

    protected function scoped(string $model)
    {
        return $model::query()->where('branch_id', $this->branch());
    }

    protected function bankAccounts()
    {
        if (!Schema::hasTable('bank_accounts')) {
            return collect();
        }
        $query = \Illuminate\Support\Facades\DB::table('bank_accounts')
            ->where('branch_id', $this->branch());
        if (Schema::hasColumn('bank_accounts', 'deleted_at')) {
            $query->whereNull('deleted_at');
        }
        if (Schema::hasColumn('bank_accounts', 'is_active')) {
            $query->where('is_active', true);
        }
        return $query->orderBy(Schema::hasColumn('bank_accounts', 'bank_name') ? 'bank_name' : 'id')->get();
    }
}

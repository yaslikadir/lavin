<?php
namespace Modules\DebtTracking\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Modules\DebtTracking\Models\DebtEntry;

class EntryController extends BaseController
{
    public function index(Request $request)
    {
        $this->authorizeModule();
        $request->validate([
            'type' => 'nullable|in:payable,receivable',
            'status' => 'nullable|in:open,partial,paid',
            'from' => 'nullable|date',
            'to' => 'nullable|date|after_or_equal:from',
            'q' => 'nullable|string|max:180',
        ]);
        $query = $this->scoped(DebtEntry::class)->withSum('payments', 'amount');
        if (in_array($request->query('type'), ['payable', 'receivable'], true)) $query->where('record_type', $request->query('type'));
        if (in_array($request->query('status'), ['open', 'partial', 'paid'], true)) $query->where('status', $request->query('status'));
        if ($request->filled('from')) $query->whereDate('due_date', '>=', $request->date('from'));
        if ($request->filled('to')) $query->whereDate('due_date', '<=', $request->date('to'));
        if ($request->filled('q')) $query->where(function ($q) use ($request) {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $request->string('q')->toString()) . '%';
            $q->where('record_no', 'like', $term)->orWhere('party_name', 'like', $term)->orWhere('title', 'like', $term)->orWhere('document_no', 'like', $term);
        });
        $records = $query->orderByRaw("CASE WHEN status = 'paid' THEN 1 ELSE 0 END")
            ->orderBy('due_date')->get();
        return view('debttracking::entries.index', compact('records'));
    }

    public function create()
    {
        $this->authorizeModule();
        $record = new DebtEntry(['record_type' => 'payable', 'currency' => 'TRY', 'due_date' => now()->toDateString()]);
        return view('debttracking::entries.form', compact('record'));
    }

    public function store(Request $request)
    {
        $this->authorizeModule();
        $data = $this->validated($request);
        $file = $request->file('attachment');
        $branch = $this->branch();
        $record = DB::transaction(function () use ($data, $file, $branch) {
            $next = ((int) $this->scoped(DebtEntry::class)->withTrashed()->lockForUpdate()->count()) + 1;
            $recordNo = 'BA-' . str_pad((string) $next, 6, '0', STR_PAD_LEFT);
            $path = $file?->store('debt-tracking/' . $branch . '/documents', 'local');
            return DebtEntry::create($data + [
                'branch_id' => $branch,
                'record_no' => $recordNo,
                'status' => 'open',
                'attachment_path' => $path,
                'attachment_name' => $file?->getClientOriginalName(),
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
        });
        return redirect()->route('admin.debt-tracking.show', $record->id)->with('success', 'Borç/alacak kaydı oluşturuldu.');
    }

    public function show($id)
    {
        $this->authorizeModule();
        $record = $this->scoped(DebtEntry::class)->with(['payments' => fn ($q) => $q->orderByDesc('payment_date')])->findOrFail($id);
        $bankAccounts = $this->bankAccounts();
        return view('debttracking::entries.show', compact('record', 'bankAccounts'));
    }

    public function edit($id)
    {
        $this->authorizeModule();
        $record = $this->scoped(DebtEntry::class)->withSum('payments', 'amount')->findOrFail($id);
        abort_if($record->status === 'paid', 409, 'Tamamlanmış kayıt düzenlenemez.');
        return view('debttracking::entries.form', compact('record'));
    }

    public function update(Request $request, $id)
    {
        $this->authorizeModule();
        $record = $this->scoped(DebtEntry::class)->withSum('payments', 'amount')->findOrFail($id);
        abort_if($record->status === 'paid', 409, 'Tamamlanmış kayıt düzenlenemez.');
        $data = $this->validated($request, $record->id);
        abort_if((float) $data['amount'] + 0.005 < (float) $record->payments_sum_amount, 422, 'Tutar, kaydedilmiş ödemelerin toplamından az olamaz.');
        $file = $request->file('attachment');
        if ($file) {
            if ($record->attachment_path) Storage::disk('local')->delete($record->attachment_path);
            $data['attachment_path'] = $file->store('debt-tracking/' . $this->branch() . '/documents', 'local');
            $data['attachment_name'] = $file->getClientOriginalName();
        }
        $data['updated_by'] = auth()->id();
        $record->update($data);
        return redirect()->route('admin.debt-tracking.show', $record->id)->with('success', 'Kayıt güncellendi.');
    }

    public function destroy($id)
    {
        $this->authorizeModule();
        $record = $this->scoped(DebtEntry::class)->withSum('payments', 'amount')->findOrFail($id);
        abort_if((float) $record->payments_sum_amount > 0, 409, 'Ödemesi bulunan kayıt arşivlenemez. Önce ödeme düzeltmesi yapılmalıdır.');
        $record->delete();
        return redirect()->route('admin.debt-tracking.index')->with('success', 'Kayıt arşivlendi.');
    }

    public function attachment($id)
    {
        $this->authorizeModule();
        $record = $this->scoped(DebtEntry::class)->findOrFail($id);
        abort_unless($record->attachment_path && Storage::disk('local')->exists($record->attachment_path), 404);
        return Storage::disk('local')->download($record->attachment_path, $record->attachment_name ?: basename($record->attachment_path));
    }

    private function validated(Request $request, ?int $id = null): array
    {
        return $request->validate([
            'record_type' => ['required', Rule::in(['payable', 'receivable'])],
            'party_name' => 'required|string|max:180',
            'party_contact' => 'nullable|string|max:120',
            'party_phone' => 'nullable|string|max:40',
            'party_email' => 'nullable|email|max:150',
            'title' => 'required|string|max:180',
            'description' => 'nullable|string|max:10000',
            'document_date' => 'nullable|date',
            'document_no' => 'nullable|string|max:80',
            'due_date' => 'required|date',
            'amount' => 'required|numeric|gt:0|decimal:0,2',
            'currency' => 'required|string|size:3|regex:/^[A-Z]{3}$/',
            'category' => 'nullable|string|max:100',
            'attachment' => 'nullable|file|max:20480|mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx',
            'notes' => 'nullable|string|max:5000',
        ], [], [
            'record_type' => 'kayıt türü', 'party_name' => 'kişi/kurum adı', 'title' => 'konu',
            'due_date' => 'vade tarihi', 'amount' => 'tutar', 'currency' => 'para birimi', 'attachment' => 'belge',
        ]);
    }
}

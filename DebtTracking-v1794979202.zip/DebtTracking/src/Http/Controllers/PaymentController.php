<?php
namespace Modules\DebtTracking\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Modules\DebtTracking\Models\DebtEntry;
use Modules\DebtTracking\Models\DebtPayment;

class PaymentController extends BaseController
{
    public function index()
    {
        $this->authorizeModule();
        $records = $this->scoped(DebtPayment::class)->with('entry')->orderByDesc('payment_date')->get();
        return view('debttracking::payments.index', compact('records'));
    }

    public function store(Request $request, $entryId)
    {
        $this->authorizeModule();
        $data = $request->validate([
            'payment_date' => 'required|date',
            'amount' => 'required|numeric|gt:0|decimal:0,2',
            'bank_account_id' => 'nullable|integer',
            'bank_reference' => 'nullable|string|max:100',
            'payment_method' => 'required|in:bank_transfer,cash,credit_card,check,other',
            'receipt' => 'nullable|file|max:20480|mimes:pdf,jpg,jpeg,png',
            'notes' => 'nullable|string|max:3000',
        ], [], ['payment_date' => 'işlem tarihi', 'amount' => 'tutar', 'bank_account_id' => 'banka hesabı', 'receipt' => 'dekont']);

        $branch = $this->branch();
        $bank = null;
        if (!empty($data['bank_account_id'])) {
            abort_unless(Schema::hasTable('bank_accounts'), 422, 'Banka hesabı seçilebilmesi için Banka modülü kurulmuş olmalıdır.');
            $bankQuery = DB::table('bank_accounts')->where('id', $data['bank_account_id'])->where('branch_id', $branch);
            if (Schema::hasColumn('bank_accounts', 'deleted_at')) $bankQuery->whereNull('deleted_at');
            $bank = $bankQuery->first();
            abort_unless($bank, 422, 'Seçilen banka hesabı bu şubede bulunamadı.');
            if (Schema::hasColumn('bank_accounts', 'is_active')) abort_unless((bool) $bank->is_active, 422, 'Pasif banka hesabı seçilemez.');
        }

        $file = $request->file('receipt');
        $path = $file?->store('debt-tracking/' . $branch . '/receipts', 'local');
        try {
            DB::transaction(function () use ($data, $branch, $entryId, $bank, $file, $path) {
                $entry = DebtEntry::where('branch_id', $branch)->lockForUpdate()->findOrFail($entryId);
                abort_unless($entry->status !== 'paid', 409, 'Tamamlanmış borç/alacak kaydına yeni ödeme eklenemez.');
                if ($bank && Schema::hasColumn('bank_accounts', 'currency')) abort_unless($bank->currency === $entry->currency, 422, 'Banka hesabının para birimi kayıtla aynı olmalıdır.');
                $paid = (float) $entry->payments()->sum('amount');
                $remaining = max(0, (float) $entry->amount - $paid);
                abort_if((float) $data['amount'] > $remaining + 0.005, 422, 'Girilen tutar kalan bakiyeyi aşamaz. Kalan: ' . number_format($remaining, 2, ',', '.') . ' ' . $entry->currency);
                DebtPayment::create([
                    'branch_id' => $branch,
                    'entry_id' => $entry->id,
                    'payment_date' => $data['payment_date'],
                    'amount' => $data['amount'],
                    'currency' => $entry->currency,
                    'bank_account_id' => $bank->id ?? null,
                    'bank_name_snapshot' => $bank ? trim(($bank->bank_name ?? '') . ' ' . ($bank->account_name ?? '')) : null,
                    'bank_reference' => $data['bank_reference'] ?? null,
                    'payment_method' => $data['payment_method'],
                    'receipt_path' => $path,
                    'receipt_name' => $file?->getClientOriginalName(),
                    'notes' => $data['notes'] ?? null,
                    'recorded_by' => auth()->id(),
                ]);
                $newPaid = $paid + (float) $data['amount'];
                $entry->update(['status' => $newPaid + 0.005 >= (float) $entry->amount ? 'paid' : 'partial', 'updated_by' => auth()->id()]);
            });
        } catch (\Throwable $e) {
            if ($path) Storage::disk('local')->delete($path);
            throw $e;
        }
        return redirect()->route('admin.debt-tracking.show', $entryId)->with('success', 'Ödeme/tahsilat kaydedildi.');
    }

    public function receipt($id)
    {
        $this->authorizeModule();
        $payment = $this->scoped(DebtPayment::class)->findOrFail($id);
        abort_unless($payment->receipt_path && Storage::disk('local')->exists($payment->receipt_path), 404);
        return Storage::disk('local')->download($payment->receipt_path, $payment->receipt_name ?: basename($payment->receipt_path));
    }
}

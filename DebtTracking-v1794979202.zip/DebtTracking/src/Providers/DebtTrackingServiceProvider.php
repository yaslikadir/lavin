<?php
namespace Modules\DebtTracking\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class DebtTrackingServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'debttracking');
        Route::middleware(['web', 'auth', 'verified', 'active_user'])
            ->prefix('admin')
            ->name('admin.')
            ->group(__DIR__ . '/../../routes/web.php');
    }
}

# Çek Yönetimi Modülü

Alınan ve verilen çeklerin vade, banka, tahsilat ve ödeme durumlarının izlenmesi.

## Özellikler
- Alınan/verilen çek ayrımı
- çek no, keşideci/lehtar, banka/şube, proje, tutar ve vade
- portföy-ciro-ibraz-tahsil-ödendi-iade-iptal yaşam döngüsü
- çek olay/geçmiş kaydı
- çek ve olay kayıtları için arama, sayfalama ve CRUD ekranları.


## Kurulum
1. Bu klasörü uygulamanızdaki `modules/Checks` dizinine kopyalayın.
2. Composer PSR-4 autoload eşlemesini ana uygulamanın `composer.json` dosyasına ekleyin: `"Modules\Checks\\": "modules/Checks/src/"`, ardından `composer dump-autoload` çalıştırın.
3. `Modules\Checks\Providers\ChecksServiceProvider::class` sağlayıcısını Laravel'e kaydedin (Laravel package discovery açık ise composer autoload sonrası keşfedilir).
4. `php artisan migrate` çalıştırın. Geri alma: `php artisan migrate:rollback` yalnızca uygun migration batch için kullanın.
5. Sistemde `checks` anahtarlı modül yetkisini ve rol izinlerini tanımlayın. Rotalar ana uygulamadaki `check.module:checks` middleware'ini kullanır.
6. Oturumda `active_branch_id` bulunmalıdır. Kayıtlar şube bazında izole edilir ve aktif şube yoksa liste/oluşturma işlemi kapalı kalır.

> Bu modül ayrı ZIP olarak dağıtılır; başka bir paketin migration'ına veya model namespace'ine bağımlı değildir. `project_id`, `bank_account_id` gibi çapraz modül kayıtları gevşek bağlıdır; ilgili uygulama ilişkilendirmelerini ana uygulamadaki entegrasyon kurallarına göre doğrulayın.

## Menü ve rotalar
Modül anahtarı: `checks`. Yönetim URL'leri `/admin/...`, rota adları `admin.*` ile başlar. Modül ana menüsüne uygun bir link ekleyin.

| Kaynak | Rotalar |
|---|---|
| `checks` | CRUD listele/ekle/düzenle/sil |
| `check-events` | CRUD listele/ekle/düzenle/sil |

## Veritabanı
| Tablo | Amaç |
|---|---|
| `checks` | Çek |
| `check_events` | Çek Olayı |

Tutarlar `DECIMAL` olarak saklanır; para birimi kayda bağlıdır. CSV yükleme/Excel importu bu sürümde yoktur. Mevcut Excel verilerini içeri almadan önce proje/hesap eşlemesi, yinelenen kayıt ve tarih formatları temizlenmelidir.

## Güvenlik ve sınırlamalar
- Her kayıt `branch_id` ile ilişkilidir; controller sorguları aktif şube ile sınırlandırılır.
- `branch_id` istemciden güvenilir kabul edilmez; sunucu aktif şubeyi atar.
- Soft delete uygulanır; hareket/çek kayıtları fiziken silinmez.
- Migration tablolarda uygulama kurulumunda mevcut olması beklenen `branches` tablosuna FK kurmaz; böylece paketler farklı sırada kurulabilir.
- Bu modül ana ERP uygulaması, kullanıcı yetki tabloları ve gerçek veritabanı ile entegrasyon testine tabi tutulmalıdır.

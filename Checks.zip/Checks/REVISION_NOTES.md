# Çek Yönetimi — Uygulama Notları

- Bağımsız, içe aktarılabilir Laravel paket düzeninde oluşturuldu.
- Otomatik migration, view namespace, `admin.` route names ve `check.module:checks` middleware kullanır.
- Şube kapsamı `active_branch_id` session değerine göre fail-closed çalışır.
- Listeleme/oluşturma/güncelleme/silme CRUD ekranları eklendi; veriler request validation ve fillable yerine guarded listesiyle korunur.
- İlişkili modül ID'leri migration FK'siz tutuldu; kurulum sırasına bağımlılık yok.
- Üretim öncesi ana uygulamanın middleware, rol izinleri, route prefix ve view layout'uyla entegrasyon testi yapılmalıdır.

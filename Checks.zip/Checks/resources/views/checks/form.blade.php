@extends('layouts.admin')

@section('content')
@php
    $hasErrors = $errors->any();
    $bankAccountsList = $bankAccounts ?? collect();
    $projectsList = $projects ?? collect();
    $counterpartyItems = $dynamicOptions['counterparty'] ?? [];
    $hasFinanceOptionRoute = \Illuminate\Support\Facades\Route::has('admin.project-finance-options.index');
    $payersList = ['Rıdvan Sunar', 'Ferhat Sunar', 'Fecri Dalgıç'];
    $optionLabels = [
        'received' => 'Alınan Çek (Müşteri Çeki - Tahsil Edilecek)',
        'issued' => 'Verilen Çek (Kendi Çekimiz - Ödenecek)',
        'portfolio' => 'Portföyde (Kasada Bekliyor)',
        'endorsed' => 'Ciro Edildi (Başka Firmaya Verildi)',
        'presented' => 'Bankaya Tahsile Verildi / Sunuldu',
        'collected' => 'Tahsil Edildi (Bankaya Yattı)',
        'paid' => 'Ödendi (Bankadan Çekildi)',
        'returned' => 'İade Edildi / Karşılıksız',
        'cancelled' => 'İptal Edildi',
    ];
    $currencyOptions = [
        'TRY' => 'TL (₺)',
        'USD' => '$ (USD)',
        'EUR' => '€ (EUR)',
    ];
    $placeholders = [
        'check_no' => 'Örn. ÇK-2026-00412',
        'bank_name' => 'Örn. Garanti BBVA, İş Bankası, Yapı Kredi',
        'branch_name' => 'Örn. Kadıköy Ticari Şube',
        'account_no' => 'Hesap numarası veya IBAN',
        'drawer_name' => 'Çeki kesen / imzalayan kişi veya firma',
        'payee_name' => 'Çekin lehtarı veya ciro edildiği firma',
        'amount' => 'Örn. 250.000',
        'related_document' => 'Örn. Sözleşme No / Fatura veya Bordro No',
        'notes' => 'Çek ile ilgili özel notlarınız...',
    ];
@endphp

<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h3 class="mb-0">{{ $record->exists ? 'Çeki Düzenle' : 'Yeni Çek Kaydı' }}</h3>
            <div class="text-muted small">Alınan ve verilen çeklerin vade, banka, proje, ciro ve tahsilat/ödeme takibi.</div>
        </div>
        <a class="btn btn-outline-secondary" href="{{ route('admin.checks.index') }}">Listeye Dön</a>
    </div>

    @if($hasErrors)
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form class="card card-body border-0 shadow-sm" method="POST" action="{{ $record->exists ? route('admin.checks.update', $record->id) : route('admin.checks.store') }}">
        @csrf
        @if($record->exists)
            @method('PUT')
        @endif

        <div class="row g-3">
            @foreach($fields as $field)
                @php
                    $name = $field['name'];
                    $type = $field['type'];
                    $isNullable = (bool) $field['nullable'];
                    $value = old($name, $record->{$name});
                    $isEnumType = str_starts_with($type, 'enum');
                    $enumOptionsList = $isEnumType ? explode(',', substr($type, 5, -1)) : [];
                @endphp
                <div class="{{ $type === 'text' ? 'col-12' : 'col-md-6' }}">
                    @if($type === 'dynamic_counterparty')
                        @php
                            $hasSelectedParty = false;
                            $hasNonEmptyParty = ((string) $value !== '');
                        @endphp
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="form-label mb-0" for="f_{{ $name }}">
                                {{ $field['label'] }}
                            </label>
                            @if($hasFinanceOptionRoute)
                                <button type="button"
                                        class="btn btn-sm btn-outline-primary py-0 px-2"
                                        id="btnOpenCounterpartyModal">
                                    + Kişi / Firma Ekle
                                </button>
                            @endif
                        </div>
                        <select class="form-select" id="f_{{ $name }}" name="{{ $name }}">
                            <option value="">İlgili kişi veya firma seçiniz</option>
                            @foreach($counterpartyItems as $cItem)
                                @php
                                    $isSel = ($hasNonEmptyParty && (string) $value === (string) $cItem['name']);
                                    if ($isSel) {
                                        $hasSelectedParty = true;
                                    }
                                @endphp
                                <option value="{{ $cItem['name'] }}" {{ $isSel ? 'selected' : '' }}>{{ $cItem['name'] }}</option>
                            @endforeach
                            @if($hasNonEmptyParty && !$hasSelectedParty)
                                <option value="{{ $value }}" selected>{{ $value }}</option>
                            @endif
                        </select>
                    @else
                        <label class="form-label" for="f_{{ $name }}">
                            {{ $field['label'] }}
                            @if(!$isNullable)
                                <span class="text-danger">*</span>
                            @endif
                        </label>

                        @if($type === 'bank_account')
                            <select class="form-select border-primary-subtle" id="f_{{ $name }}" name="{{ $name }}">
                                <option value="">Kendi banka hesabımızdan seçiniz (İsteğe bağlı)</option>
                                @foreach($bankAccountsList as $bankAccount)
                                    @php
                                        $accLabel = trim(($bankAccount->bank_name ?: 'Banka') . ' — ' . ($bankAccount->account_name ?: 'Hesap'));
                                        if ($bankAccount->iban || $bankAccount->account_no) {
                                            $accLabel .= ' (' . ($bankAccount->iban ?: $bankAccount->account_no) . ')';
                                        }
                                    @endphp
                                    <option value="{{ $bankAccount->id }}"
                                            data-bank-name="{{ $bankAccount->bank_name }}"
                                            data-branch-name="{{ $bankAccount->branch_name }}"
                                            data-account-no="{{ $bankAccount->iban ?: $bankAccount->account_no }}"
                                            data-currency="{{ $bankAccount->currency }}"
                                            {{ (string) $value === (string) $bankAccount->id ? 'selected' : '' }}>
                                        {{ $accLabel }}
                                    </option>
                                @endforeach
                            </select>
                            <div class="form-text small">Seçildiğinde Banka Adı, Şube ve IBAN/Hesap No alanlarını otomatik doldurur; çek "Tahsil Edildi" veya "Ödendi" olduğunda banka bakiyesine otomatik yansır.</div>
                        @elseif($type === 'project')
                            <select class="form-select" id="f_{{ $name }}" name="{{ $name }}">
                                <option value="">Proje seçiniz</option>
                                @foreach($projectsList as $project)
                                    <option value="{{ $project->id }}" {{ (string) $value === (string) $project->id ? 'selected' : '' }}>
                                        {{ $project->project_code }} — {{ $project->name }}
                                    </option>
                                @endforeach
                            </select>
                        @elseif($type === 'payer_select')
                            <select class="form-select" id="f_{{ $name }}" name="{{ $name }}">
                                <option value="">Ödeyen kişiyi seçiniz (İsteğe bağlı)</option>
                                @foreach($payersList as $payer)
                                    <option value="{{ $payer }}" {{ (string) $value === (string) $payer ? 'selected' : '' }}>
                                        {{ $payer }}
                                    </option>
                                @endforeach
                            </select>
                        @elseif($isEnumType)
                            <select class="form-select" id="f_{{ $name }}" name="{{ $name }}" {{ !$isNullable ? 'required' : '' }}>
                                @foreach($enumOptionsList as $option)
                                    @php $option = str_replace("'", '', trim($option)); @endphp
                                    <option value="{{ $option }}" {{ (string) ($value ?: ($name === 'status' ? 'portfolio' : 'received')) === (string) $option ? 'selected' : '' }}>
                                        {{ $optionLabels[$option] ?? $option }}
                                    </option>
                                @endforeach
                            </select>
                        @elseif($type === 'currency')
                            @php
                                $currVal = strtoupper((string) ($value ?: 'TRY'));
                                $currVal = $currVal === 'TL' ? 'TRY' : $currVal;
                            @endphp
                            <select class="form-select" id="f_{{ $name }}" name="{{ $name }}" required>
                                @foreach($currencyOptions as $code => $label)
                                    <option value="{{ $code }}" {{ $currVal === $code ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                        @elseif($type === 'money')
                            @php
                                $displayMoney = '';
                                if ($value !== null && $value !== '') {
                                    if (is_numeric($value)) {
                                        $floatVal = (float) $value;
                                        $displayMoney = ($floatVal == (int) $floatVal)
                                            ? number_format($floatVal, 0, ',', '.')
                                            : number_format($floatVal, 2, ',', '.');
                                    } else {
                                        $displayMoney = $value;
                                    }
                                }
                            @endphp
                            <input class="form-control js-money-input"
                                   type="text"
                                   inputmode="decimal"
                                   autocomplete="off"
                                   id="f_{{ $name }}"
                                   name="{{ $name }}"
                                   value="{{ $displayMoney }}"
                                   placeholder="{{ $placeholders[$name] ?? '0' }}"
                                   {{ !$isNullable ? 'required' : '' }}>
                        @elseif($type === 'date')
                            @php
                                $dateVal = $record->{$name} ? \Carbon\Carbon::parse($record->{$name})->format('Y-m-d') : '';
                            @endphp
                            <input class="form-control" type="date" id="f_{{ $name }}" name="{{ $name }}" value="{{ old($name, $dateVal) }}" {{ !$isNullable ? 'required' : '' }}>
                        @elseif($type === 'text' || $type === 'longText')
                            <textarea class="form-control" rows="3" id="f_{{ $name }}" name="{{ $name }}" placeholder="{{ $placeholders[$name] ?? '' }}">{{ $value }}</textarea>
                        @else
                            <input class="form-control" type="text" id="f_{{ $name }}" name="{{ $name }}" value="{{ $value }}" placeholder="{{ $placeholders[$name] ?? '' }}" {{ !$isNullable ? 'required' : '' }}>
                        @endif
                    @endif
                </div>
            @endforeach
        </div>

        <div class="mt-4 d-flex gap-2">
            <button class="btn btn-primary" type="submit">Kaydet</button>
            <a class="btn btn-light" href="{{ route('admin.checks.index') }}">Vazgeç</a>
        </div>
    </form>
</div>

@if($hasFinanceOptionRoute)
<div class="modal fade" id="checkPartyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-semibold">Hızlı İlgili Kişi / Firma Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body">
                <div id="checkPartyAlert" class="alert d-none py-2 px-3 mb-2"></div>
                <label class="form-label">Kişi veya Firma Adı</label>
                <div class="input-group">
                    <input type="text" id="checkPartyNameInput" class="form-control" placeholder="Örn. ABC Beton A.Ş.">
                    <button type="button" id="checkPartySaveBtn" class="btn btn-primary">Ekle ve Seç</button>
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    function formatTurkishCurrency(rawVal) {
        if (rawVal === null || rawVal === undefined) return '';
        let val = String(rawVal);

        if (!val.includes(',') && /^\d+\.\d{1,2}$/.test(val.trim())) {
            let parts = val.trim().split('.');
            let intFormatted = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            if (parseInt(parts[1], 10) === 0) {
                return intFormatted;
            }
            return intFormatted + ',' + parts[1];
        }

        val = val.replace(/[^0-9,]/g, '');
        if (!val) return '';

        let parts = val.split(',');
        let intPart = parts[0].replace(/^0+(?=\d)/, '');
        if (intPart === '' && parts.length > 1) intPart = '0';

        let formattedInt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        if (parts.length > 1) {
            let decPart = parts.slice(1).join('').substring(0, 2);
            return formattedInt + ',' + decPart;
        }
        return formattedInt;
    }

    document.querySelectorAll('.js-money-input').forEach(function (input) {
        if (input.value) {
            input.value = formatTurkishCurrency(input.value);
        }
        input.addEventListener('input', function () {
            const oldLen = this.value.length;
            const cursor = this.selectionStart || 0;
            const formatted = formatTurkishCurrency(this.value);
            this.value = formatted;
            const newLen = formatted.length;
            const newCursor = Math.max(0, cursor + (newLen - oldLen));
            try {
                this.setSelectionRange(newCursor, newCursor);
            } catch (e) {}
        });
    });

    const bankAccSelect = document.getElementById('f_bank_account_id');
    const bankNameInput = document.getElementById('f_bank_name');
    const branchNameInput = document.getElementById('f_branch_name');
    const accountNoInput = document.getElementById('f_account_no');
    const currencySelect = document.getElementById('f_currency');

    if (bankAccSelect) {
        bankAccSelect.addEventListener('change', function () {
            const opt = this.options[this.selectedIndex];
            if (!opt || !opt.value) return;
            if (bankNameInput && opt.dataset.bankName) {
                bankNameInput.value = opt.dataset.bankName;
            }
            if (branchNameInput && opt.dataset.branchName) {
                branchNameInput.value = opt.dataset.branchName;
            }
            if (accountNoInput && opt.dataset.accountNo) {
                accountNoInput.value = opt.dataset.accountNo;
            }
            if (currencySelect && opt.dataset.currency) {
                currencySelect.value = opt.dataset.currency;
            }
        });
    }

    const openBtn = document.getElementById('btnOpenCounterpartyModal');
    const modalEl = document.getElementById('checkPartyModal');
    if (openBtn && modalEl) {
        let bsModal = null;
        openBtn.addEventListener('click', function () {
            if (!bsModal && window.bootstrap && window.bootstrap.Modal) {
                bsModal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
            }
            if (bsModal) bsModal.show();
        });

        const saveBtn = document.getElementById('checkPartySaveBtn');
        const nameInput = document.getElementById('checkPartyNameInput');
        const partySelect = document.getElementById('f_related_party');
        const drawerInput = document.getElementById('f_drawer_name');

        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const nameVal = (nameInput.value || '').trim();
                if (!nameVal) return;
                saveBtn.disabled = true;
                fetch(@json($hasFinanceOptionRoute ? route('admin.project-finance-options.store') : ''), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ group_key: 'counterparty', name: nameVal })
                })
                .then(r => r.json())
                .then(res => {
                    if (res.status === 'ok' && partySelect) {
                        const newOpt = document.createElement('option');
                        newOpt.value = nameVal;
                        newOpt.textContent = nameVal;
                        newOpt.selected = true;
                        partySelect.appendChild(newOpt);
                        if (drawerInput && !drawerInput.value) {
                            drawerInput.value = nameVal;
                        }
                        nameInput.value = '';
                        if (bsModal) bsModal.hide();
                    }
                })
                .finally(() => { saveBtn.disabled = false; });
            });
        }
    }
});
</script>
@endpush
@endsection
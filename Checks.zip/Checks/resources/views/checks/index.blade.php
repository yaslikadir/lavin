@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<style>
    #checksTable_wrapper .dataTables_filter { float: right; }
    #checksTable_wrapper .dataTables_length { float: left; }
    .dt-buttons { margin-bottom: .5rem; }
    .due-warning-badge {
        background-color: #fff5f5;
        color: #dc3545;
        border: 1px solid #f5c2c7;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 8px;
        border-radius: 6px;
        font-size: 0.78rem;
    }
    .check-stat-card {
        border-left: 4px solid #0d6efd !important;
    }
</style>
@endpush

@section('content')
@php
    $records = $records ?? collect();
    $projectsList = $projects ?? collect();
    $bankAccountsList = $bankAccounts ?? collect();
    $yearsList = $years ?? range((int) date('Y') + 1, (int) date('Y') - 2);
    $payersList = ['Rıdvan Sunar', 'Ferhat Sunar', 'Fecri Dalgıç'];
    $sum = $checkSummary ?? [
        'received_total' => 0.0, 'received_collected' => 0.0, 'received_pending' => 0.0, 'received_count' => 0,
        'issued_total' => 0.0, 'issued_paid' => 0.0, 'issued_pending' => 0.0, 'issued_count' => 0,
        'upcoming_10days_amount' => 0.0, 'upcoming_10days_count' => 0,
    ];
    $hasSuccess = session()->has('success');
    $today = \Carbon\Carbon::today();

    $directionLabels = [
        'received' => 'Alınan Çek (+)',
        'issued' => 'Verilen Çek (-)',
    ];
    $statusLabels = [
        'portfolio' => 'Portföyde',
        'endorsed' => 'Ciro Edildi',
        'presented' => 'Bankaya Sunuldu',
        'collected' => 'Tahsil Edildi',
        'paid' => 'Ödendi',
        'returned' => 'İade / Karşılıksız',
        'cancelled' => 'İptal Edildi',
    ];
    $statusBadges = [
        'portfolio' => 'bg-warning text-dark',
        'endorsed' => 'bg-info text-dark',
        'presented' => 'bg-primary',
        'collected' => 'bg-success',
        'paid' => 'bg-success',
        'returned' => 'bg-danger',
        'cancelled' => 'bg-secondary',
    ];
    $currencySymbols = [
        'TRY' => 'TL (₺)',
        'TL'  => 'TL (₺)',
        'USD' => '$ (USD)',
        'EUR' => '€ (EUR)',
    ];
    $months = [
        1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
        5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
        9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık',
    ];
    $hasActiveFilters = request()->filled('direction')
        || request()->filled('status')
        || request()->filled('paid_by')
        || request()->filled('project_id')
        || request()->filled('bank_account_id')
        || request()->filled('year')
        || request()->filled('month')
        || request()->filled('start_date')
        || request()->filled('end_date');
@endphp

<div class="container-fluid px-4 py-4">
    <!-- Üst Başlık -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div>
            <h3 class="mb-1">Çek Yönetimi</h3>
            <div class="text-muted">Alınan ve verilen çeklerin vade, tahsilat, ciro, banka ve proje bazlı takibi.</div>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.check-events.index') }}" class="btn btn-outline-dark">📋 Çek Hareket / Ciro Geçmişi</a>
            <a href="{{ route('admin.checks.create') }}" class="btn btn-primary">+ Yeni Çek Kaydı</a>
        </div>
    </div>

    @if($hasSuccess)
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <!-- Üst Filtre Alanı -->
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('admin.checks.index') }}">
                <div class="row g-2 align-items-end">
                    <div class="col-6 col-md-1">
                        <label class="form-label small fw-semibold mb-1">Vade Yılı</label>
                        <select name="year" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            @foreach($yearsList as $yr)
                                <option value="{{ $yr }}" {{ (string) request('year') === (string) $yr ? 'selected' : '' }}>{{ $yr }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-6 col-md-1">
                        <label class="form-label small fw-semibold mb-1">Vade Ayı</label>
                        <select name="month" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            @foreach($months as $mNum => $mName)
                                <option value="{{ $mNum }}" {{ (string) request('month') === (string) $mNum ? 'selected' : '' }}>{{ $mName }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-6 col-md-2">
                        <label class="form-label small fw-semibold mb-1">Vade Başlangıç</label>
                        <input type="date" name="start_date" class="form-control form-control-sm" value="{{ request('start_date') }}">
                    </div>

                    <div class="col-6 col-md-2">
                        <label class="form-label small fw-semibold mb-1">Vade Bitiş</label>
                        <input type="date" name="end_date" class="form-control form-control-sm" value="{{ request('end_date') }}">
                    </div>

                    <div class="col-6 col-md-1">
                        <label class="form-label small fw-semibold mb-1">Çek Yönü</label>
                        <select name="direction" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            <option value="received" {{ request('direction') === 'received' ? 'selected' : '' }}>Alınan</option>
                            <option value="issued" {{ request('direction') === 'issued' ? 'selected' : '' }}>Verilen</option>
                        </select>
                    </div>

                    <div class="col-6 col-md-1">
                        <label class="form-label small fw-semibold mb-1">Durum</label>
                        <select name="status" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            @foreach($statusLabels as $sKey => $sLabel)
                                <option value="{{ $sKey }}" {{ request('status') === $sKey ? 'selected' : '' }}>{{ $sLabel }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-6 col-md-2">
                        <label class="form-label small fw-semibold mb-1">Kim Ödedi</label>
                        <select name="paid_by" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            @foreach($payersList as $payer)
                                <option value="{{ $payer }}" {{ request('paid_by') === $payer ? 'selected' : '' }}>{{ $payer }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-6 col-md-2">
                        <label class="form-label small fw-semibold mb-1">Proje</label>
                        <select name="project_id" class="form-select form-select-sm">
                            <option value="">Tüm Projeler</option>
                            @foreach($projectsList as $proj)
                                <option value="{{ $proj->id }}" {{ (string) request('project_id') === (string) $proj->id ? 'selected' : '' }}>
                                    {{ $proj->project_code }} — {{ $proj->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12 d-flex justify-content-end gap-2 mt-2 pt-2 border-top">
                        <button type="submit" class="btn btn-sm btn-primary px-3">🔍 Filtrele</button>
                        @if($hasActiveFilters)
                            <a href="{{ route('admin.checks.index') }}" class="btn btn-sm btn-outline-secondary">Filtreyi Temizle</a>
                        @endif
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- 4'lü Özet Kartları -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm h-100 check-stat-card" style="border-left-color: #198754 !important;">
                <div class="card-body py-2 px-3">
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-1 mb-2">
                        <span class="fw-bold text-dark">📥 Alınan Çekler (Portföy & Tahsil)</span>
                        <span class="badge bg-light text-dark border">{{ $sum['received_count'] }} Çek</span>
                    </div>
                    <div class="fs-5 fw-bold text-success">{{ number_format((float) $sum['received_total'], 2, ',', '.') }} ₺</div>
                    <div class="d-flex justify-content-between small text-muted mt-1" style="font-size: 0.74rem;">
                        <span>Tahsil: <strong>{{ number_format((float) $sum['received_collected'], 2, ',', '.') }} ₺</strong></span>
                        <span>Bekleyen: <strong>{{ number_format((float) $sum['received_pending'], 2, ',', '.') }} ₺</strong></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm h-100 check-stat-card" style="border-left-color: #dc3545 !important;">
                <div class="card-body py-2 px-3">
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-1 mb-2">
                        <span class="fw-bold text-dark">📤 Verilen Çekler (Kendi Çekimiz)</span>
                        <span class="badge bg-light text-dark border">{{ $sum['issued_count'] }} Çek</span>
                    </div>
                    <div class="fs-5 fw-bold text-danger">{{ number_format((float) $sum['issued_total'], 2, ',', '.') }} ₺</div>
                    <div class="d-flex justify-content-between small text-muted mt-1" style="font-size: 0.74rem;">
                        <span>Ödenen: <strong>{{ number_format((float) $sum['issued_paid'], 2, ',', '.') }} ₺</strong></span>
                        <span>Bekleyen: <strong>{{ number_format((float) $sum['issued_pending'], 2, ',', '.') }} ₺</strong></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm h-100 check-stat-card" style="border-left-color: #0d6efd !important;">
                <div class="card-body py-2 px-3">
                    @php
                        $netPending = (float) $sum['received_pending'] - (float) $sum['issued_pending'];
                        $netClass = $netPending >= 0 ? 'text-primary' : 'text-danger';
                    @endphp
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-1 mb-2">
                        <span class="fw-bold text-dark">⚖️ Bekleyen Çek Dengesi (Net)</span>
                        <span class="badge bg-light text-dark border">Aktif Risk</span>
                    </div>
                    <div class="fs-5 fw-bold {{ $netClass }}">{{ number_format($netPending, 2, ',', '.') }} ₺</div>
                    <div class="small text-muted mt-1" style="font-size: 0.74rem;">
                        Bekleyen Alacak Çeki - Bekleyen Borç Çeki
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm h-100 check-stat-card" style="border-left-color: #fd7e14 !important;">
                <div class="card-body py-2 px-3">
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-1 mb-2">
                        <span class="fw-bold text-danger">⚠️ Vadesi Yaklaşan / Geçen (≤10 Gün)</span>
                        <span class="badge bg-danger">{{ $sum['upcoming_10days_count'] }} Çek</span>
                    </div>
                    <div class="fs-5 fw-bold text-danger">{{ number_format((float) $sum['upcoming_10days_amount'], 2, ',', '.') }} ₺</div>
                    <div class="small text-muted mt-1" style="font-size: 0.74rem;">
                        10 gün içinde tahsil edilecek / ödenecek çekler
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tablo -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm align-middle mb-0" id="checksTable" style="width:100%">
                    <thead class="table-light">
                        <tr>
                            <th>Yön</th>
                            <th>Çek No</th>
                            <th>Banka & Hesap</th>
                            <th>Proje</th>
                            <th>İlgili Kişi/Firma (Keşideci / Lehtar)</th>
                            <th class="text-end">Tutar</th>
                            <th>Birim</th>
                            <th>Keşide Tarihi</th>
                            <th>Vade Tarihi & Kalan Gün</th>
                            <th>Durum</th>
                            <th>Kim Ödedi</th>
                            <th>Kaydı Yapan</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($records as $record)
                            @php
                                $bankAccount = $record->bankAccount;
                                $project = $record->project;
                                $bankAccountLabel = $bankAccount
                                    ? ($bankAccount->bank_name . ' — ' . $bankAccount->account_name)
                                    : ($record->branch_name ? $record->branch_name : 'Hesap bağlanmamış');
                                $projectLabel = $project
                                    ? ($project->project_code . ' — ' . $project->name)
                                    : ($record->project_name ?: ($record->project_code ?: '—'));

                                $dirBadge = $record->direction === 'received' ? 'bg-success' : 'bg-danger';
                                $dirText = $directionLabels[$record->direction] ?? 'Tanımsız';

                                $stBadge = $statusBadges[$record->status] ?? 'bg-secondary';
                                $stText = $statusLabels[$record->status] ?? 'Tanımsız';

                                $c = strtoupper((string) $record->currency);
                                $currLabel = $currencySymbols[$c] ?? $c;

                                $issueObj = $record->issue_date ? \Carbon\Carbon::parse($record->issue_date) : null;
                                $issueOrder = $issueObj ? $issueObj->format('Y-m-d') : '';
                                $issueStr = $issueObj ? $issueObj->format('d.m.Y') : '—';

                                $dueObj = $record->due_date ? \Carbon\Carbon::parse($record->due_date)->startOfDay() : null;
                                $dueOrder = $dueObj ? $dueObj->format('Y-m-d') : '9999-12-31';
                                $isSettled = in_array($record->status, ['collected', 'paid', 'cancelled', 'returned'], true);

                                $dueHtml = '—';
                                if ($dueObj) {
                                    $daysRemaining = (int) $today->diffInDays($dueObj, false);
                                    $dueDateStr = e($dueObj->format('d.m.Y'));
                                    if ($isSettled) {
                                        $dueHtml = '<div>' . $dueDateStr . '</div><div class="small text-success mt-1">✓ ' . e($stText) . '</div>';
                                    } elseif ($daysRemaining < 0) {
                                        $dueHtml = '<div>' . $dueDateStr . '</div><div class="due-warning-badge mt-1">⚠️ Vadesi ' . abs($daysRemaining) . ' gün geçti!</div>';
                                    } elseif ($daysRemaining === 0) {
                                        $dueHtml = '<div>' . $dueDateStr . '</div><div class="due-warning-badge mt-1">⚠️ Bugün vade günü! — Çek vadesi geldi</div>';
                                    } elseif ($daysRemaining <= 10) {
                                        $dueHtml = '<div>' . $dueDateStr . '</div><div class="due-warning-badge mt-1">⚠️ ' . $daysRemaining . ' gün kaldı — Çek vadesi yaklaşıyor</div>';
                                    } else {
                                        $dueHtml = '<div>' . $dueDateStr . '</div><div class="small text-muted mt-1">' . $daysRemaining . ' gün kaldı</div>';
                                    }
                                }

                                $partyLines = [];
                                if ($record->related_party) {
                                    $partyLines[] = '<div class="fw-semibold">' . e($record->related_party) . '</div>';
                                }
                                if ($record->drawer_name) {
                                    $partyLines[] = '<div class="small text-muted">Keşideci: ' . e($record->drawer_name) . '</div>';
                                }
                                if ($record->payee_name) {
                                    $partyLines[] = '<div class="small text-muted">Lehtar: ' . e($record->payee_name) . '</div>';
                                }
                                $partyHtml = count($partyLines) > 0 ? implode('', $partyLines) : '—';

                                $creator = $record->creator ?? null;
                                $creatorFullName = '—';
                                if ($creator) {
                                    $full = trim(($creator->name ?? '') . ' ' . ($creator->surname ?? $creator->last_name ?? ''));
                                    $creatorFullName = $full !== '' ? $full : ($creator->email ?? '—');
                                } elseif (!empty($record->created_by)) {
                                    $creatorFullName = 'Kullanıcı #' . $record->created_by;
                                }
                            @endphp
                            <tr>
                                <td><span class="badge {{ $dirBadge }}">{{ $dirText }}</span></td>
                                <td class="fw-bold font-monospace">{{ $record->check_no }}</td>
                                <td>
                                    <div class="fw-semibold">{{ $record->bank_name }}</div>
                                    <div class="small text-muted">{{ $bankAccountLabel }}</div>
                                </td>
                                <td>{{ $projectLabel }}</td>
                                <td>{!! $partyHtml !!}</td>
                                <td class="text-end fw-bold" data-order="{{ (float) $record->amount }}">
                                    {{ number_format((float) $record->amount, 2, ',', '.') }}
                                </td>
                                <td class="text-nowrap">{{ $currLabel }}</td>
                                <td data-order="{{ $issueOrder }}" class="text-nowrap">{{ $issueStr }}</td>
                                <td data-order="{{ $dueOrder }}" class="text-nowrap">{!! $dueHtml !!}</td>
                                <td><span class="badge {{ $stBadge }}">{{ $stText }}</span></td>
                                <td class="fw-semibold text-nowrap">{{ $record->paid_by ?: '—' }}</td>
                                <td>{{ $creatorFullName }}</td>
                                <td class="text-nowrap">
                                    <a class="btn btn-sm btn-info text-white" href="{{ route('admin.checks.show', $record->id) }}" title="Çek Röntgeni ve Geçmişi">
                                        👁️ Detay
                                    </a>
                                    <a class="btn btn-sm btn-outline-primary" href="{{ route('admin.checks.edit', $record->id) }}">Düzenle</a>
                                    <form class="d-inline" method="POST" action="{{ route('admin.checks.destroy', $record->id) }}" onsubmit="return confirm('Bu çek silinsin mi?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Sil</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script>
$(function () {
    $('#checksTable').DataTable({
        dom: '<"row align-items-center mb-2"<"col-md-4"l><"col-md-4 text-center"B><"col-md-4"f>>rtip',
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        order: [[8, 'asc']],
        columnDefs: [{ targets: -1, orderable: false, searchable: false }],
        language: {
            decimal: ',',
            thousands: '.',
            emptyTable: 'Tabloda kayıt bulunmuyor',
            info: '_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor',
            infoEmpty: 'Kayıt bulunmuyor',
            infoFiltered: '(_MAX_ kayıt içinden filtrelendi)',
            lengthMenu: 'Sayfada _MENU_ kayıt göster',
            loadingRecords: 'Yükleniyor...',
            processing: 'İşleniyor...',
            search: 'Ara:',
            zeroRecords: 'Eşleşen kayıt bulunamadı',
            paginate: { first: 'İlk', last: 'Son', next: 'Sonraki', previous: 'Önceki' },
            aria: { sortAscending: ': artan sıralamak için etkinleştir', sortDescending: ': azalan sıralamak için etkinleştir' }
        },
        buttons: [{
            extend: 'excelHtml5',
            text: "Excel'e Aktar",
            className: 'btn btn-success btn-sm',
            title: 'Çek Listesi',
            exportOptions: { columns: ':not(:last-child)' }
        }]
    });
});
</script>
@endpush
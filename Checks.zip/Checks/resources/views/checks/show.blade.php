@extends('layouts.admin')

@section('content')
@php
    $hasSuccess = session()->has('success');
    $payersList = ['Rıdvan Sunar', 'Ferhat Sunar', 'Fecri Dalgıç'];
    $directionLabels = [
        'received' => 'Alınan Çek (Müşteri Çeki)',
        'issued' => 'Verilen Çek (Kendi Çekimiz)',
    ];
    $statusLabels = [
        'portfolio' => 'Portföyde',
        'endorsed' => 'Ciro Edildi',
        'presented' => 'Bankaya Sunuldu',
        'collected' => 'Tahsil Edildi',
        'paid' => 'Ödendi',
        'returned' => 'İade / Karşılıksız',
        'cancelled' => 'İptal Edildi',
    ];
    $statusBadges = [
        'portfolio' => 'bg-warning text-dark',
        'endorsed' => 'bg-info text-dark',
        'presented' => 'bg-primary',
        'collected' => 'bg-success',
        'paid' => 'bg-success',
        'returned' => 'bg-danger',
        'cancelled' => 'bg-secondary',
    ];
    $currencySymbols = [
        'TRY' => 'TL (₺)',
        'TL'  => 'TL (₺)',
        'USD' => '$ (USD)',
        'EUR' => '€ (EUR)',
    ];
    $c = strtoupper((string) $record->currency);
    $currLabel = $currencySymbols[$c] ?? $c;
    $eventsList = $record->events ?? collect();
    $dueStr = $record->due_date ? \Carbon\Carbon::parse($record->due_date)->format('d.m.Y') : '—';
    $issueStr = $record->issue_date ? \Carbon\Carbon::parse($record->issue_date)->format('d.m.Y') : '—';
@endphp

<div class="container-fluid px-4 py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div>
            <h3 class="mb-1">🧾 Çek Detayı & Röntgeni — #{{ $record->check_no }}</h3>
            <div class="text-muted">
                {{ $directionLabels[$record->direction] ?? '' }} |
                Banka: <strong>{{ $record->bank_name }}</strong> |
                Vade: <strong>{{ $dueStr }}</strong>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.checks.edit', $record->id) }}" class="btn btn-primary btn-sm">Çeki Düzenle</a>
            <a href="{{ route('admin.checks.index') }}" class="btn btn-outline-secondary btn-sm">← Çek Listesine Dön</a>
        </div>
    </div>

    @if($hasSuccess)
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="row g-4">
        <!-- Sol: Çek Künyesi -->
        <div class="col-12 col-xl-5">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">Çek Künyesi</h5>
                    <span class="badge {{ $statusBadges[$record->status] ?? 'bg-secondary' }} fs-6">
                        {{ $statusLabels[$record->status] ?? $record->status }}
                    </span>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <th class="text-muted w-40">Çek Numarası:</th>
                            <td class="fw-bold font-monospace">{{ $record->check_no }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Çek Tutarı:</th>
                            <td class="fs-5 fw-bold text-primary">{{ number_format((float) $record->amount, 2, ',', '.') }} {{ $currLabel }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Çek Yönü:</th>
                            <td>{{ $directionLabels[$record->direction] ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Kim Ödedi:</th>
                            <td class="fw-bold text-success">{{ $record->paid_by ?: '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Vade Tarihi:</th>
                            <td class="fw-bold">{{ $dueStr }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Keşide Tarihi:</th>
                            <td>{{ $issueStr }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Banka / Şube:</th>
                            <td>{{ $record->bank_name }} {{ $record->branch_name ? ' / ' . $record->branch_name : '' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Bağlı Banka Hesabı:</th>
                            <td>{{ $record->bankAccount ? ($record->bankAccount->bank_name . ' — ' . $record->bankAccount->account_name) : '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Proje:</th>
                            <td>{{ $record->project ? ($record->project->project_code . ' — ' . $record->project->name) : ($record->project_name ?: '—') }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">İlgili Kişi / Firma:</th>
                            <td class="fw-semibold">{{ $record->related_party ?: '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Keşideci:</th>
                            <td>{{ $record->drawer_name ?: '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Lehtar:</th>
                            <td>{{ $record->payee_name ?: '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">İlgili Belge No:</th>
                            <td>{{ $record->related_document ?: '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Notlar:</th>
                            <td>{{ $record->notes ?: '—' }}</td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Hızlı Çek Hareketi / Ciro / Tahsilat Ekle -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-light py-3">
                    <h6 class="mb-0 fw-bold">⚡ Hızlı Çek İşlemi / Ciro / Durum Hareketi Ekle</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.check-events.store') }}">
                        @csrf
                        <input type="hidden" name="check_id" value="{{ $record->id }}">
                        <input type="hidden" name="from_check_show" value="1">
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">İşlem / Olay Türü *</label>
                            <select name="event_type" class="form-select form-select-sm" required>
                                <option value="Portföye Alındı">Portföye Alındı</option>
                                <option value="Ciro Edildi (Başka Firmaya Verildi)">Ciro Edildi (Başka Firmaya Verildi)</option>
                                <option value="Bankaya Tahsile Verildi">Bankaya Tahsile Verildi</option>
                                <option value="Tahsil Edildi">Tahsil Edildi</option>
                                <option value="Ödendi">Ödendi</option>
                                <option value="Karşılıksız Çıktı / İade Edildi">Karşılıksız Çıktı / İade Edildi</option>
                            </select>
                        </div>
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <label class="form-label small fw-semibold mb-1">İşlem Tarihi *</label>
                                <input type="date" name="event_date" class="form-control form-control-sm" value="{{ now()->format('Y-m-d') }}" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-semibold mb-1">Çek Durumunu da Güncelle</label>
                                <select name="update_check_status" class="form-select form-select-sm">
                                    <option value="">Mevcut Durumu Koru</option>
                                    @foreach($statusLabels as $sKey => $sLabel)
                                        <option value="{{ $sKey }}">{{ $sLabel }} Yap</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Kim Ödedi</label>
                            <select name="paid_by" class="form-select form-select-sm">
                                <option value="">Seçiniz / Mevcut Kalsın ({{ $record->paid_by ?: 'Belirtilmemiş' }})</option>
                                @foreach($payersList as $payer)
                                    <option value="{{ $payer }}" {{ $record->paid_by === $payer ? 'selected' : '' }}>{{ $payer }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Banka / Bordro Referansı</label>
                            <input type="text" name="bank_reference" class="form-control form-control-sm" placeholder="Dekont veya ciro bordro no">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold mb-1">Açıklama / Ciro Edilen Firma</label>
                            <textarea name="description" rows="2" class="form-control form-control-sm" placeholder="Örn. X firmasına hakediş karşılığı ciro edildi..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary w-100">Hareketi Kaydet</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sağ: Çek Hareket / Ciro / Tahsilat Tarihçesi -->
        <div class="col-12 col-xl-7">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0 fw-bold">📋 Çek Yaşam Döngüsü & İşlem Geçmişi</h5>
                        <small class="text-muted">Bu çeke ait tüm durum değişiklikleri, ciro, bankaya ibraz ve tahsilat hareketleri.</small>
                    </div>
                    <span class="badge bg-primary">{{ $eventsList->count() }} Kayıt</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Olay / İşlem Türü</th>
                                    <th>Açıklama</th>
                                    <th>Referans</th>
                                    <th>Kaydı Yapan</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($eventsList as $ev)
                                    @php
                                        $evDate = $ev->event_date ? \Carbon\Carbon::parse($ev->event_date)->format('d.m.Y') : '—';
                                        $evCreator = $ev->creator ? trim(($ev->creator->name ?? '') . ' ' . ($ev->creator->surname ?? '')) : '—';
                                    @endphp
                                    <tr>
                                        <td class="text-nowrap fw-semibold">{{ $evDate }}</td>
                                        <td><span class="badge bg-light text-dark border">{{ $ev->event_type }}</span></td>
                                        <td>{{ $ev->description ?: '—' }}</td>
                                        <td>{{ $ev->bank_reference ?: '—' }}</td>
                                        <td>{{ $evCreator ?: '—' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@extends('layouts.admin')

@push('css')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
@endpush

@section('content')
@php
    $records = $records ?? collect();
    $hasSuccess = session()->has('success');
@endphp

<div class="container-fluid px-4 py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div>
            <h3 class="mb-1">Çek Olayı & Ciro Geçmişi Yönetimi</h3>
            <div class="text-muted">Çeklerin portföy, ciro, bankaya ibraz ve tahsilat/ödeme hareket geçmişi.</div>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.checks.index') }}" class="btn btn-outline-secondary">← Çek Listesine Dön</a>
            <a href="{{ route('admin.check-events.create') }}" class="btn btn-primary">+ Yeni Çek Olayı</a>
        </div>
    </div>

    @if($hasSuccess)
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm align-middle mb-0" id="checkEventsTable" style="width:100%">
                    <thead class="table-light">
                        <tr>
                            <th>Çek No & Banka</th>
                            <th>İşlem / Olay Türü</th>
                            <th>Olay Tarihi</th>
                            <th>Açıklama</th>
                            <th>Banka Referansı</th>
                            <th>Kaydı Yapan</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($records as $record)
                            @php
                                $check = $record->check;
                                $evDateObj = $record->event_date ? \Carbon\Carbon::parse($record->event_date) : null;
                                $evOrder = $evDateObj ? $evDateObj->format('Y-m-d') : '';
                                $evStr = $evDateObj ? $evDateObj->format('d.m.Y') : '—';
                                $creator = $record->creator ?? null;
                                $creatorName = $creator ? trim(($creator->name ?? '') . ' ' . ($creator->surname ?? '')) : '—';
                            @endphp
                            <tr>
                                <td>
                                    @if($check)
                                        <a href="{{ route('admin.checks.show', $check->id) }}" class="fw-bold text-decoration-none">
                                            #{{ $check->check_no }} — {{ $check->bank_name }}
                                        </a>
                                    @else
                                        Çek bağlantısı bulunmuyor
                                    @endif
                                </td>
                                <td><span class="badge bg-light text-dark border">{{ $record->event_type }}</span></td>
                                <td data-order="{{ $evOrder }}" class="text-nowrap">{{ $evStr }}</td>
                                <td>{{ $record->description ?: '—' }}</td>
                                <td>{{ $record->bank_reference ?: '—' }}</td>
                                <td>{{ $creatorName ?: '—' }}</td>
                                <td class="text-nowrap">
                                    <a class="btn btn-sm btn-outline-primary" href="{{ route('admin.check-events.edit', $record->id) }}">Düzenle</a>
                                    <form class="d-inline" method="POST" action="{{ route('admin.check-events.destroy', $record->id) }}" onsubmit="return confirm('Bu çek olayı silinsin mi?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Sil</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script>
$(function () {
    $('#checkEventsTable').DataTable({
        dom: '<"row align-items-center mb-2"<"col-md-4"l><"col-md-4 text-center"B><"col-md-4"f>>rtip',
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        order: [[2, 'desc']],
        columnDefs: [{ targets: -1, orderable: false, searchable: false }],
        language: {
            decimal: ',',
            thousands: '.',
            emptyTable: 'Tabloda kayıt bulunmuyor',
            info: '_TOTAL_ kayıttan _START_ - _END_ arası gösteriliyor',
            infoEmpty: 'Kayıt bulunmuyor',
            infoFiltered: '(_MAX_ kayıt içinden filtrelendi)',
            lengthMenu: 'Sayfada _MENU_ kayıt göster',
            loadingRecords: 'Yükleniyor...',
            processing: 'İşleniyor...',
            search: 'Ara:',
            zeroRecords: 'Eşleşen kayıt bulunamadı',
            paginate: { first: 'İlk', last: 'Son', next: 'Sonraki', previous: 'Önceki' },
            aria: { sortAscending: ': artan sıralamak için etkinleştir', sortDescending: ': azalan sıralamak için etkinleştir' }
        },
        buttons: [{
            extend: 'excelHtml5',
            text: "Excel'e Aktar",
            className: 'btn btn-success btn-sm',
            title: 'Çek Hareketleri',
            exportOptions: { columns: ':not(:last-child)' }
        }]
    });
});
</script>
@endpush

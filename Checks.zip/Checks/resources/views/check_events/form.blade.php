@extends('layouts.admin')

@section('content')
@php
    $hasErrors = $errors->any();
    $checksList = $checks ?? collect();
    $eventTypePresets = [
        'Portföye Alındı',
        'Ciro Edildi (Başka Firmaya Verildi)',
        'Bankaya Tahsile Verildi / İbraz Edildi',
        'Tahsil Edildi',
        'Ödendi',
        'Karşılıksız Çıktı / Protesto',
        'İade Edildi',
        'İptal Edildi',
    ];
@endphp

<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>{{ $record->exists ? 'Çek Hareketini Düzenle' : 'Yeni Çek Hareketi / Olayı' }}</h3>
        <a class="btn btn-outline-secondary" href="{{ route('admin.check-events.index') }}">Listeye Dön</a>
    </div>

    @if($hasErrors)
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form class="card card-body border-0 shadow-sm" method="POST" action="{{ $record->exists ? route('admin.check-events.update', $record->id) : route('admin.check-events.store') }}">
        @csrf
        @if($record->exists)
            @method('PUT')
        @endif

        <div class="row g-3">
            @foreach($fields as $field)
                @php
                    $name = $field['name'];
                    $type = $field['type'];
                    $isNullable = (bool) $field['nullable'];
                    $value = old($name, $record->{$name});
                    if ($name === 'event_date' && !$value) {
                        $value = now()->format('Y-m-d');
                    }
                @endphp
                <div class="{{ $type === 'text' ? 'col-12' : 'col-md-6' }}">
                    <label class="form-label" for="f_{{ $name }}">
                        {{ $field['label'] }}
                        @if(!$isNullable)
                            <span class="text-danger">*</span>
                        @endif
                    </label>

                    @if($name === 'check_id')
                        <select class="form-select" id="f_{{ $name }}" name="{{ $name }}" required>
                            <option value="">Çek seçiniz</option>
                            @foreach($checksList as $check)
                                @php
                                    $checkLabel = '#' . $check->check_no . ' — ' . $check->bank_name . ' (' . number_format((float) $check->amount, 2, ',', '.') . ' ' . $check->currency . ')';
                                @endphp
                                <option value="{{ $check->id }}" {{ (string) $value === (string) $check->id ? 'selected' : '' }}>
                                    {{ $checkLabel }}
                                </option>
                            @endforeach
                        </select>
                    @elseif($type === 'event_type_select')
                        @php
                            $inPreset = in_array((string) $value, $eventTypePresets, true);
                        @endphp
                        <select class="form-select" id="f_{{ $name }}" name="{{ $name }}" required>
                            <option value="">İşlem türü seçiniz</option>
                            @foreach($eventTypePresets as $preset)
                                <option value="{{ $preset }}" {{ (string) $value === (string) $preset ? 'selected' : '' }}>{{ $preset }}</option>
                            @endforeach
                            @if($value && !$inPreset)
                                <option value="{{ $value }}" selected>{{ $value }}</option>
                            @endif
                        </select>
                    @elseif($type === 'date')
                        @php
                            $dateVal = $record->{$name} ? \Carbon\Carbon::parse($record->{$name})->format('Y-m-d') : $value;
                        @endphp
                        <input class="form-control" type="date" id="f_{{ $name }}" name="{{ $name }}" value="{{ old($name, $dateVal) }}" required>
                    @elseif($type === 'text' || $type === 'longText')
                        <textarea class="form-control" rows="3" id="f_{{ $name }}" name="{{ $name }}" placeholder="Açıklama veya ciro edilen firma bilgisi girin">{{ $value }}</textarea>
                    @else
                        <input class="form-control" type="text" id="f_{{ $name }}" name="{{ $name }}" value="{{ $value }}" placeholder="Banka / dekont / bordro referansı" {{ !$isNullable ? 'required' : '' }}>
                    @endif
                </div>
            @endforeach
        </div>

        <div class="mt-4 d-flex gap-2">
            <button class="btn btn-primary" type="submit">Kaydet</button>
            <a class="btn btn-light" href="{{ route('admin.check-events.index') }}">Vazgeç</a>
        </div>
    </form>
</div>
@endsection

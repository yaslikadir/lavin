<?php
use Illuminate\Support\Facades\Route;
use Modules\Checks\Http\Controllers\CheckController;
use Modules\Checks\Http\Controllers\CheckEventController;

Route::middleware(['check.module:checks'])->group(function () {
    Route::resource('checks', CheckController::class);
    Route::resource('check-events', CheckEventController::class)->except(['show']);
});

<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
        Schema::create('checks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('branch_id')->nullable()->index();
            $table->enum('direction', ['received', 'issued']);
            $table->string('check_no');
            $table->string('bank_name');
            $table->string('branch_name')->nullable();
            $table->string('account_no')->nullable();
            $table->string('drawer_name')->nullable();
            $table->string('payee_name')->nullable();
            $table->unsignedBigInteger('project_id')->nullable();
            $table->string('project_code')->nullable();
            $table->string('project_name')->nullable();
            $table->decimal('amount', 15,2);
            $table->string('currency', 3)->default('TRY');
            $table->date('issue_date')->nullable();
            $table->date('due_date');
            $table->date('received_issued_date')->nullable();
            $table->enum('status', ['portfolio', 'endorsed', 'presented', 'collected', 'paid', 'returned', 'cancelled'])->default('portfolio');
            $table->string('related_party')->nullable();
            $table->string('related_document')->nullable();
            $table->unsignedBigInteger('bank_account_id')->nullable();
            $table->text('notes')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['branch_id','direction','status','due_date'], 'checks_branch_direction_status_due_idx');
            $table->unique(['branch_id','direction','check_no'], 'checks_branch_direction_no_uq');
        });
        Schema::create('check_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('branch_id')->nullable()->index();
            $table->unsignedBigInteger('check_id');
            $table->string('event_type');
            $table->date('event_date');
            $table->text('description')->nullable();
            $table->string('bank_reference')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
    public function down(): void {
        Schema::dropIfExists('check_events');
        Schema::dropIfExists('checks');
    }
};

<?php
namespace Modules\Checks\Providers;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
class ChecksServiceProvider extends ServiceProvider {
 public function boot(): void {
  $this->loadMigrationsFrom(__DIR__.'/../../database/migrations');
  $this->loadViewsFrom(__DIR__.'/../../resources/views','checks');
  Route::middleware(['web','auth','verified','active_user'])->prefix('admin')->name('admin.')->group(__DIR__.'/../../routes/web.php');
 }
}

<?php

namespace Modules\Checks\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Modules\Checks\Models\Check;
use Modules\Checks\Models\CheckEvent;

class CheckEventController extends Controller
{
    private function branch(): int
    {
        $id = (int) session('active_branch_id', 0);
        abort_if(!$id, 403, 'Önce aktif şube seçilmelidir.');

        return $id;
    }

    private function rules(): array
    {
        $branchId = $this->branch();

        return [
            'check_id' => [
                'required',
                'integer',
                'min:1',
                Rule::exists('checks', 'id')->where(fn ($query) => $query->where('branch_id', $branchId)->whereNull('deleted_at')),
            ],
            'event_type' => 'required|string|max:255',
            'event_date' => 'required|date',
            'description' => 'nullable|string',
            'bank_reference' => 'nullable|string|max:255',
        ];
    }

    private function scoped()
    {
        return CheckEvent::query()->where('branch_id', $this->branch());
    }

    public function index(Request $request)
    {
        $query = $this->scoped()->with(['check.bankAccount', 'check.project', 'creator']);

        if ($request->filled('check_id')) {
            $query->where('check_id', (int) $request->check_id);
        }

        if ($request->filled('q')) {
            $term = '%' . $request->q . '%';
            $query->where(function ($q) use ($term): void {
                foreach (['event_type', 'description', 'bank_reference'] as $field) {
                    $q->orWhere($field, 'like', $term);
                }
                $q->orWhereHas('check', function ($checkQuery) use ($term): void {
                    $checkQuery->where(function ($nested) use ($term): void {
                        $nested->where('check_no', 'like', $term)
                            ->orWhere('bank_name', 'like', $term)
                            ->orWhere('project_code', 'like', $term)
                            ->orWhere('project_name', 'like', $term);
                    });
                });
            });
        }

        $records = $query->orderBy('event_date', 'desc')->orderBy('id', 'desc')->get();

        return view('checks::check_events.index', compact('records'));
    }

    public function create()
    {
        $record = new CheckEvent;
        $fields = $this->fieldMeta();
        $checks = $this->availableChecks();

        return view('checks::check_events.form', compact('record', 'fields', 'checks'));
    }

   public function store(Request $request)
    {
        $data = $request->validate($this->rules());
        $data['branch_id'] = $this->branch();
        $data['created_by'] = Auth::id();

        if ($request->filled('paid_by') && in_array($request->input('paid_by'), CheckController::PAYERS, true)) {
            $payer = $request->input('paid_by');
            $data['description'] = trim(($data['description'] ?? '') . ' [Kim Ödedi: ' . $payer . ']');
        }

        $event = $this->scoped()->create($data);

        $checkUpdates = [];
        if ($request->filled('update_check_status')) {
            $newSt = $request->input('update_check_status');
            if (array_key_exists($newSt, CheckController::STATUS_LABELS)) {
                $checkUpdates['status'] = $newSt;
            }
        }
        if ($request->filled('paid_by') && in_array($request->input('paid_by'), CheckController::PAYERS, true)) {
            $checkUpdates['paid_by'] = $request->input('paid_by');
        }

        if (!empty($checkUpdates)) {
            Check::query()
                ->where('branch_id', $this->branch())
                ->where('id', $event->check_id)
                ->update($checkUpdates);
        }

        if ($request->boolean('from_check_show')) {
            return redirect()->route('admin.checks.show', $event->check_id)->with('success', 'Çek hareketi kaydedildi.');
        }

        return redirect()->route('admin.check-events.index')->with('success', 'Çek olayı kaydedildi.');
    }

    public function edit($id)
    {
        $record = $this->scoped()->with('check')->findOrFail($id);
        $fields = $this->fieldMeta();
        $checks = $this->availableChecks();

        return view('checks::check_events.form', compact('record', 'fields', 'checks'));
    }

    public function update(Request $request, $id)
    {
        $record = $this->scoped()->findOrFail($id);
        $data = $request->validate($this->rules());
        $record->update($data);

        return redirect()->route('admin.check-events.index')->with('success', 'Çek olayı güncellendi.');
    }

    public function destroy($id)
    {
        $this->scoped()->findOrFail($id)->delete();

        return back()->with('success', 'Çek olayı silindi.');
    }

    private function availableChecks()
    {
        return Check::query()
            ->with(['bankAccount', 'project'])
            ->where('branch_id', $this->branch())
            ->orderBy('check_no')
            ->get();
    }

    private function fieldMeta(): array
    {
        return [
            ['name' => 'check_id', 'label' => 'İlgili Çek', 'type' => 'relation', 'nullable' => false],
            ['name' => 'event_type', 'label' => 'İşlem / Olay Türü', 'type' => 'event_type_select', 'nullable' => false],
            ['name' => 'event_date', 'label' => 'İşlem Tarihi', 'type' => 'date', 'nullable' => false],
            ['name' => 'bank_reference', 'label' => 'Banka Referansı / Dekont / Bordro No', 'type' => 'string', 'nullable' => true],
            ['name' => 'description', 'label' => 'Açıklama / Ciro Edilen Firma Notu', 'type' => 'text', 'nullable' => true],
        ];
    }
}

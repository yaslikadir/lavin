<?php

namespace Modules\Checks\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Modules\Banking\Models\BankAccount;
use Modules\Checks\Models\Check;
use Modules\Checks\Models\CheckEvent;
use Modules\ConstructionProjects\Models\ConstructionProject;
use Modules\ProjectFinance\Http\Controllers\ProjectFinanceOptionController;

class CheckController extends Controller
{
    public const STATUS_LABELS = [
        'portfolio' => 'Portföyde',
        'endorsed' => 'Ciro Edildi',
        'presented' => 'Bankaya Sunuldu',
        'collected' => 'Tahsil Edildi',
        'paid' => 'Ödendi',
        'returned' => 'İade / Karşılıksız',
        'cancelled' => 'İptal Edildi',
    ];

    public const PAYERS = [
        'Rıdvan Sunar',
        'Ferhat Sunar',
        'Fecri Dalgıç',
    ];

    private function branch(): int
    {
        $id = (int) session('active_branch_id', 0);
        abort_if(!$id, 403, 'Önce aktif şube seçilmelidir.');

        return $id;
    }

    public static function sanitizeMoney($value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        $str = trim((string) $value);
        if (str_contains($str, ',')) {
            $str = str_replace('.', '', $str);
            $str = str_replace(',', '.', $str);
        } elseif (substr_count($str, '.') > 1) {
            $str = str_replace('.', '', $str);
        } elseif (preg_match('/^\d{1,3}(\.\d{3})+$/', $str)) {
            $str = str_replace('.', '', $str);
        }
        $str = preg_replace('/[^0-9.-]/', '', $str);

        return $str === '' ? '0' : $str;
    }

    public static function normalizeCurrency(?string $currency): string
    {
        $val = strtoupper(trim((string) $currency));
        return match ($val) {
            'TL', 'TRY', '₺' => 'TRY',
            'USD', '$', 'DOLAR' => 'USD',
            'EUR', '€', 'EURO' => 'EUR',
            default => in_array($val, ['TRY', 'USD', 'EUR'], true) ? $val : 'TRY',
        };
    }

    private function prepareInput(Request $request): void
    {
        $merge = [];
        if ($request->has('amount')) {
            $sanitized = self::sanitizeMoney($request->input('amount'));
            $merge['amount'] = ($sanitized === null || $sanitized === '') ? '0' : $sanitized;
        }
        if ($request->has('currency')) {
            $merge['currency'] = self::normalizeCurrency($request->input('currency'));
        }
        if (!$request->filled('project_id')) {
            $merge['project_id'] = null;
        }
        if (!$request->filled('bank_account_id')) {
            $merge['bank_account_id'] = null;
        }
        if (!$request->filled('paid_by')) {
            $merge['paid_by'] = null;
        }
        if (!empty($merge)) {
            $request->merge($merge);
        }
    }

    private function rules(?int $ignoreId = null): array
    {
        $branchId = $this->branch();

        $uniqueCheckRule = Rule::unique('checks', 'check_no')
            ->where(fn ($q) => $q->where('branch_id', $branchId)->where('direction', request('direction')));
        if ($ignoreId) {
            $uniqueCheckRule->ignore($ignoreId);
        }

        return [
            'direction' => 'required|in:received,issued',
            'check_no' => ['required', 'string', 'max:255', $uniqueCheckRule],
            'bank_account_id' => [
                'nullable',
                'integer',
                'min:1',
                Rule::exists('bank_accounts', 'id')->where(fn ($query) => $query->where('branch_id', $branchId)->whereNull('deleted_at')),
            ],
            'bank_name' => 'required|string|max:255',
            'branch_name' => 'nullable|string|max:255',
            'account_no' => 'nullable|string|max:255',
            'drawer_name' => 'nullable|string|max:255',
            'payee_name' => 'nullable|string|max:255',
            'related_party' => 'nullable|string|max:255',
            'project_id' => [
                'nullable',
                'integer',
                'min:1',
                Rule::exists('construction_projects', 'id')->where(fn ($query) => $query->where('branch_id', $branchId)->whereNull('deleted_at')),
            ],
            'amount' => 'required|numeric|min:0',
            'currency' => 'required|string|in:TRY,USD,EUR',
            'issue_date' => 'nullable|date',
            'due_date' => 'required|date',
            'received_issued_date' => 'nullable|date',
            'status' => 'required|in:portfolio,endorsed,presented,collected,paid,returned,cancelled',
            'paid_by' => ['nullable', 'string', Rule::in(self::PAYERS)],
            'related_document' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ];
    }

    private function validationMessages(): array
    {
        return [
            'required' => ':attribute alanı zorunludur.',
            'numeric' => ':attribute sayısal bir değer olmalıdır.',
            'date' => ':attribute geçerli bir tarih olmalıdır.',
            'check_no.unique' => 'Bu çek numarası aynı yönde zaten kayıtlıdır.',
        ];
    }

    private function validationAttributes(): array
    {
        return [
            'direction' => 'Çek yönü',
            'check_no' => 'Çek numarası',
            'bank_account_id' => 'Banka hesabı',
            'bank_name' => 'Banka adı',
            'branch_name' => 'Şube adı',
            'account_no' => 'Hesap numarası / IBAN',
            'drawer_name' => 'Keşideci (Çeki Düzenleyen)',
            'payee_name' => 'Lehtar (Alacaklı)',
            'related_party' => 'İlgili kişi / firma',
            'project_id' => 'Proje',
            'amount' => 'Çek tutarı',
            'currency' => 'Para birimi',
            'issue_date' => 'Keşide (Düzenleme) tarihi',
            'due_date' => 'Vade tarihi',
            'received_issued_date' => 'Alınma / verilme tarihi',
            'status' => 'Çek durumu',
            'paid_by' => 'Kim Ödedi',
            'related_document' => 'İlgili belge / sözleşme no',
            'notes' => 'Notlar',
        ];
    }

    private function scoped()
    {
        return Check::query()->where('branch_id', $this->branch());
    }

    private function availableYears(): array
    {
        $dates = $this->scoped()
            ->whereNotNull('due_date')
            ->pluck('due_date');

        $years = [];
        foreach ($dates as $dt) {
            if ($dt) {
                $years[] = (int) \Carbon\Carbon::parse($dt)->format('Y');
            }
        }

        $currentYear = (int) now()->format('Y');
        for ($y = $currentYear - 2; $y <= $currentYear + 1; $y++) {
            $years[] = $y;
        }

        $years = array_values(array_unique($years));
        rsort($years);

        return $years;
    }

    private function applyFilters($query, Request $request): void
    {
        if ($request->filled('direction') && in_array($request->direction, ['received', 'issued'], true)) {
            $query->where('direction', $request->direction);
        }
        if ($request->filled('status') && array_key_exists($request->status, self::STATUS_LABELS)) {
            $query->where('status', $request->status);
        }
        if ($request->filled('paid_by') && in_array($request->paid_by, self::PAYERS, true)) {
            $query->where('paid_by', $request->paid_by);
        }
        if ($request->filled('project_id')) {
            $query->where('project_id', (int) $request->project_id);
        }
        if ($request->filled('bank_account_id')) {
            $query->where('bank_account_id', (int) $request->bank_account_id);
        }
        if ($request->filled('year')) {
            $query->whereYear('due_date', (int) $request->year);
        }
        if ($request->filled('month')) {
            $query->whereMonth('due_date', (int) $request->month);
        }
        if ($request->filled('start_date')) {
            $query->whereDate('due_date', '>=', $request->start_date);
        }
        if ($request->filled('end_date')) {
            $query->whereDate('due_date', '<=', $request->end_date);
        }
        if ($request->filled('q')) {
            $term = '%' . $request->q . '%';
            $query->where(function ($q) use ($term): void {
                foreach (['check_no', 'bank_name', 'branch_name', 'account_no', 'drawer_name', 'payee_name', 'project_code', 'project_name', 'currency', 'related_party', 'paid_by', 'related_document', 'notes'] as $field) {
                    $q->orWhere($field, 'like', $term);
                }
            });
        }
    }

    private function calculateCheckSummary($collection): array
    {
        $summary = [
            'received_total' => 0.0,
            'received_collected' => 0.0,
            'received_pending' => 0.0,
            'received_count' => 0,
            'issued_total' => 0.0,
            'issued_paid' => 0.0,
            'issued_pending' => 0.0,
            'issued_count' => 0,
            'upcoming_10days_amount' => 0.0,
            'upcoming_10days_count' => 0,
        ];

        $today = \Carbon\Carbon::today();

        foreach ($collection as $chk) {
            if (in_array($chk->status, ['cancelled', 'returned'], true)) {
                continue;
            }
            $amt = (float) $chk->amount;
            $isSettled = in_array($chk->status, ['collected', 'paid'], true);

            if ($chk->direction === 'received') {
                $summary['received_total'] += $amt;
                $summary['received_count']++;
                if ($isSettled) {
                    $summary['received_collected'] += $amt;
                } else {
                    $summary['received_pending'] += $amt;
                }
            } else {
                $summary['issued_total'] += $amt;
                $summary['issued_count']++;
                if ($isSettled) {
                    $summary['issued_paid'] += $amt;
                } else {
                    $summary['issued_pending'] += $amt;
                }
            }

            if (!$isSettled && $chk->due_date) {
                $dueObj = \Carbon\Carbon::parse($chk->due_date)->startOfDay();
                $daysRem = (int) $today->diffInDays($dueObj, false);
                if ($daysRem <= 10) {
                    $summary['upcoming_10days_amount'] += $amt;
                    $summary['upcoming_10days_count']++;
                }
            }
        }

        return $summary;
    }

    private function logCheckLifecycleEvent(Check $check, string $eventType, string $description): void
    {
        CheckEvent::withoutGlobalScopes()->create([
            'branch_id' => $this->branch(),
            'check_id' => $check->id,
            'event_type' => $eventType,
            'event_date' => now()->format('Y-m-d'),
            'description' => $description,
            'bank_reference' => $check->related_document,
            'created_by' => Auth::id(),
        ]);
    }

    private function syncCheckWithBankTransaction(Check $check): void
    {
        if (!Schema::hasTable('bank_transactions')) {
            return;
        }
        $branchId = $this->branch();
        $refTag = 'CEK-' . $check->id . '-' . $check->check_no;

        $isSettledInBank = in_array($check->status, ['collected', 'paid'], true) && !empty($check->bank_account_id);

        if (!$isSettledInBank) {
            DB::table('bank_transactions')
                ->where('branch_id', $branchId)
                ->where('reference_no', $refTag)
                ->delete();
            return;
        }

        $txType = $check->direction === 'received' ? 'deposit' : 'withdrawal';
        $dirText = $check->direction === 'received' ? 'Alınan Çek Tahsilatı' : 'Verilen Çek Ödemesi';
        $payerSuffix = $check->paid_by ? ' - Ödeyen: ' . $check->paid_by : '';
        $desc = '[' . $dirText . '] Çek No: #' . $check->check_no . ' (' . ($check->related_party ?: ($check->drawer_name ?: $check->payee_name)) . ')' . $payerSuffix;
        $txDate = $check->due_date ? \Carbon\Carbon::parse($check->due_date)->format('Y-m-d') : now()->format('Y-m-d');

        $existing = DB::table('bank_transactions')
            ->where('branch_id', $branchId)
            ->where('reference_no', $refTag)
            ->whereNull('deleted_at')
            ->first();

        $payload = [
            'branch_id' => $branchId,
            'bank_account_id' => (int) $check->bank_account_id,
            'transaction_type' => $txType,
            'transaction_date' => $txDate,
            'value_date' => $txDate,
            'description' => $desc,
            'reference_no' => $refTag,
            'counterparty' => $check->related_party ?: ($check->drawer_name ?: $check->payee_name),
            'project_id' => $check->project_id,
            'project_code' => $check->project_code,
            'amount' => (float) $check->amount,
            'currency' => self::normalizeCurrency($check->currency),
            'reconciled' => 1,
            'updated_at' => now(),
        ];

        if ($existing) {
            DB::table('bank_transactions')->where('id', $existing->id)->update($payload);
        } else {
            $payload['created_by'] = Auth::id();
            $payload['created_at'] = now();
            DB::table('bank_transactions')->insert($payload);
        }
    }

    public function index(Request $request)
    {
        $query = $this->scoped()->with(['bankAccount', 'project', 'creator']);
        $this->applyFilters($query, $request);

        $records = $query->orderBy('due_date', 'asc')->orderBy('id', 'desc')->get();
        ['bankAccounts' => $bankAccounts, 'projects' => $projects] = $this->formOptions();
        $years = $this->availableYears();
        $checkSummary = $this->calculateCheckSummary($records);

        return view('checks::checks.index', compact(
            'records',
            'bankAccounts',
            'projects',
            'years',
            'checkSummary'
        ));
    }

    public function show($id)
    {
        $record = $this->scoped()->with(['bankAccount', 'project', 'creator', 'events.creator'])->findOrFail($id);

        return view('checks::checks.show', compact('record'));
    }

    public function create()
    {
        $record = new Check;
        $fields = $this->fieldMeta();
        ['bankAccounts' => $bankAccounts, 'projects' => $projects, 'dynamicOptions' => $dynamicOptions] = $this->formOptions();

        return view('checks::checks.form', compact('record', 'fields', 'bankAccounts', 'projects', 'dynamicOptions'));
    }

    public function store(Request $request)
    {
        $this->prepareInput($request);
        $data = $request->validate($this->rules(), $this->validationMessages(), $this->validationAttributes());
        $this->syncProjectSnapshot($data);
        $data['branch_id'] = $this->branch();
        $data['created_by'] = Auth::id();

        $check = $this->scoped()->create($data);

        $statusLabel = self::STATUS_LABELS[$check->status] ?? $check->status;
        $payerNote = $check->paid_by ? ' (Kim Ödedi: ' . $check->paid_by . ')' : '';
        $this->logCheckLifecycleEvent($check, 'Çek Kaydı Oluşturuldu (' . $statusLabel . ')', 'Çek sisteme kaydedildi.' . $payerNote);
        $this->syncCheckWithBankTransaction($check);

        return redirect()->route('admin.checks.index')->with('success', 'Çek başarıyla kaydedildi.');
    }

    public function edit($id)
    {
        $record = $this->scoped()->with(['bankAccount', 'project'])->findOrFail($id);
        $fields = $this->fieldMeta();
        ['bankAccounts' => $bankAccounts, 'projects' => $projects, 'dynamicOptions' => $dynamicOptions] = $this->formOptions();

        return view('checks::checks.form', compact('record', 'fields', 'bankAccounts', 'projects', 'dynamicOptions'));
    }

    public function update(Request $request, $id)
    {
        $record = $this->scoped()->findOrFail($id);
        $oldStatus = $record->status;

        $this->prepareInput($request);
        $data = $request->validate($this->rules((int) $record->id), $this->validationMessages(), $this->validationAttributes());
        $this->syncProjectSnapshot($data);
        unset($data['branch_id'], $data['created_by']);
        $record->update($data);

        if ($oldStatus !== $record->status) {
            $oldLabel = self::STATUS_LABELS[$oldStatus] ?? $oldStatus;
            $newLabel = self::STATUS_LABELS[$record->status] ?? $record->status;
            $payerInfo = $record->paid_by ? ' | Kim Ödedi: ' . $record->paid_by : '';
            $this->logCheckLifecycleEvent($record, 'Durum Güncellendi: ' . $newLabel, 'Çek durumu "' . $oldLabel . '" iken "' . $newLabel . '" olarak değiştirildi.' . $payerInfo);
        }

        $this->syncCheckWithBankTransaction($record);

        return redirect()->route('admin.checks.index')->with('success', 'Çek güncellendi.');
    }

    public function destroy($id)
    {
        $record = $this->scoped()->findOrFail($id);
        if (Schema::hasTable('bank_transactions')) {
            $refTag = 'CEK-' . $record->id . '-' . $record->check_no;
            DB::table('bank_transactions')
                ->where('branch_id', $this->branch())
                ->where('reference_no', $refTag)
                ->delete();
        }
        $record->delete();

        return back()->with('success', 'Çek silindi.');
    }

    private function formOptions(): array
    {
        $branchId = $this->branch();
        $dynamicOptions = ['category' => [], 'counterparty' => [], 'payment_method' => []];
        if (class_exists(ProjectFinanceOptionController::class)) {
            $dynamicOptions = ProjectFinanceOptionController::groupedOptionsForBranch($branchId);
        }

        return [
            'bankAccounts' => BankAccount::query()
                ->where('branch_id', $branchId)
                ->orderBy('bank_name')
                ->orderBy('account_name')
                ->get(),
            'projects' => ConstructionProject::query()
                ->where('branch_id', $branchId)
                ->orderBy('project_code')
                ->orderBy('name')
                ->get(),
            'dynamicOptions' => $dynamicOptions,
        ];
    }

    private function syncProjectSnapshot(array &$data): void
    {
        if (!empty($data['project_id'])) {
            $project = ConstructionProject::query()
                ->where('branch_id', $this->branch())
                ->findOrFail((int) $data['project_id']);
            $data['project_code'] = $project->project_code;
            $data['project_name'] = $project->name;
        } else {
            $data['project_code'] = null;
            $data['project_name'] = null;
        }
    }

    private function fieldMeta(): array
    {
        return [
            ['name' => 'direction', 'label' => 'Çek Yönü', 'type' => "enum('received','issued')", 'nullable' => false],
            ['name' => 'check_no', 'label' => 'Çek Numarası / Seri No', 'type' => 'string', 'nullable' => false],
            ['name' => 'project_id', 'label' => 'İnşaat Projesi', 'type' => 'project', 'nullable' => true],
            ['name' => 'bank_account_id', 'label' => 'Kendi Banka Hesabımız (Seçilirse Bilgiler Otomatik Dolar)', 'type' => 'bank_account', 'nullable' => true],
            ['name' => 'bank_name', 'label' => 'Çekin Ait Olduğu Banka Adı', 'type' => 'string', 'nullable' => false],
            ['name' => 'branch_name', 'label' => 'Banka Şube Adı / Kodu', 'type' => 'string', 'nullable' => true],
            ['name' => 'account_no', 'label' => 'Çek Hesap No / IBAN', 'type' => 'string', 'nullable' => true],
            ['name' => 'related_party', 'label' => 'İlgili Kişi / Firma (Cari)', 'type' => 'dynamic_counterparty', 'nullable' => true],
            ['name' => 'drawer_name', 'label' => 'Keşideci (Çeki Düzenleyen)', 'type' => 'string', 'nullable' => true],
            ['name' => 'payee_name', 'label' => 'Lehtar (Çek Alacaklısı / Ciro Edilen)', 'type' => 'string', 'nullable' => true],
            ['name' => 'amount', 'label' => 'Çek Tutarı', 'type' => 'money', 'nullable' => false],
            ['name' => 'currency', 'label' => 'Para Birimi', 'type' => 'currency', 'nullable' => false],
            ['name' => 'issue_date', 'label' => 'Keşide (Düzenleme) Tarihi', 'type' => 'date', 'nullable' => true],
            ['name' => 'due_date', 'label' => 'Vade Tarihi', 'type' => 'date', 'nullable' => false],
            ['name' => 'received_issued_date', 'label' => 'Alınma / Verilme Tarihi', 'type' => 'date', 'nullable' => true],
            ['name' => 'status', 'label' => 'Çek Durumu', 'type' => "enum('portfolio','endorsed','presented','collected','paid','returned','cancelled')", 'nullable' => false],
            ['name' => 'paid_by', 'label' => 'Kim Ödedi', 'type' => 'payer_select', 'nullable' => true],
            ['name' => 'related_document', 'label' => 'İlgili Belge / Sözleşme / Bordro No', 'type' => 'string', 'nullable' => true],
            ['name' => 'notes', 'label' => 'Notlar & Açıklama', 'type' => 'text', 'nullable' => true],
        ];
    }
}
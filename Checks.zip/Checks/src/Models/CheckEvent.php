<?php

namespace Modules\Checks\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class CheckEvent extends Model
{
    use SoftDeletes;

    protected $table = 'check_events';
    protected $guarded = ['id', 'created_at', 'updated_at', 'deleted_at'];
    protected $casts = [
        'event_date' => 'date:Y-m-d',
        'branch_id' => 'integer',
        'check_id' => 'integer',
        'created_by' => 'integer',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('module_branch', function ($query): void {
            if (!app()->runningInConsole()) {
                $branchId = session('active_branch_id');
                if ($branchId === null || $branchId === '') {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->where($query->getModel()->getTable() . '.branch_id', (int) $branchId);
                }
            }
        });
        static::creating(function ($model): void {
            if (!$model->branch_id) {
                $model->branch_id = session('active_branch_id');
            }
        });
    }

    public function check(): BelongsTo
    {
        return $this->belongsTo(Check::class, 'check_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}

<?php

namespace Modules\Checks\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\Banking\Models\BankAccount;
use Modules\ConstructionProjects\Models\ConstructionProject;

class Check extends Model
{
    use SoftDeletes;

    protected $table = 'checks';
    protected $guarded = ['id', 'created_at', 'updated_at', 'deleted_at'];
    protected $casts = [
        'amount' => 'decimal:2',
        'issue_date' => 'date:Y-m-d',
        'due_date' => 'date:Y-m-d',
        'received_issued_date' => 'date:Y-m-d',
        'branch_id' => 'integer',
        'project_id' => 'integer',
        'bank_account_id' => 'integer',
        'created_by' => 'integer',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('module_branch', function ($query): void {
            if (!app()->runningInConsole()) {
                $branchId = session('active_branch_id');
                if ($branchId === null || $branchId === '') {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->where($query->getModel()->getTable() . '.branch_id', (int) $branchId);
                }
            }
        });
        static::creating(function ($model): void {
            if (!$model->branch_id) {
                $model->branch_id = session('active_branch_id');
            }
        });
    }

    public function bankAccount(): BelongsTo
    {
        return $this->belongsTo(BankAccount::class, 'bank_account_id');
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(ConstructionProject::class, 'project_id');
    }

    public function events(): HasMany
    {
        return $this->hasMany(CheckEvent::class, 'check_id')->orderBy('event_date', 'desc')->orderBy('id', 'desc');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}

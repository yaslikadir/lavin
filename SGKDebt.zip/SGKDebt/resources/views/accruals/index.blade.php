@extends('layouts.admin')
@include('sgk_debt::partials.styles')
@section('title', 'SGK Tahakkuk Fişleri')

@section('content')
@php
    $amountColumns = [
        'premium_debt' => 'Prim Borcu',
        'premium_late_charge' => 'Prim GZ',
    ];
    $payers = ['Rıdvan Sunar', 'Ferhat Sunar', 'Fecri Dalgıç'];
@endphp
<div class="container-fluid px-3 px-lg-4 py-4 sgk-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h1 class="h3 mb-1">SGK Tahakkuk Fişleri</h1>
            <div class="text-muted">Paylaşılan SGK dökümündeki borç ve gecikme kalemleri ayrı ayrı izlenir.</div>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-outline-dark" href="{{ route('admin.sgk-payments.index') }}">Ödeme ve mahsup</a>
            <a class="btn btn-outline-secondary" href="{{ route('admin.sgk-accruals.export') }}">CSV dışa aktar</a>
            <a class="btn btn-outline-primary" href="{{ route('admin.sgk-accruals.import') }}">Dosyadan aktar</a>
            <a class="btn btn-primary" href="{{ route('admin.sgk-accruals.create') }}">+ Yeni tahakkuk fişi</a>
        </div>
    </div>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif

    <form class="row g-2 mb-3" method="GET">
        <div class="col-md-5"><input name="q" value="{{ request('q') }}" class="form-control" placeholder="Şirket, şantiye, sicil veya dönem ara"></div>
        <div class="col-md-3">
            <select name="due" class="form-select">
                <option value="">Tüm vadeler</option>
                <option value="overdue" @selected(request('due') === 'overdue')>Vadesi geçmiş</option>
                <option value="soon" @selected(request('due') === 'soon')>14 gün içinde</option>
            </select>
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="">Tüm işlem durumları</option>
                @foreach(['draft'=>'Taslak','pending_approval'=>'Onay bekliyor','payable'=>'Ödenecek','partial'=>'Kısmi ödendi','paid'=>'Ödendi','overdue'=>'Gecikmiş','disputed'=>'İhtilaflı'] as $value=>$label)
                    <option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-1"><button class="btn btn-dark w-100">Filtrele</button></div>
    </form>

    <div class="alert alert-warning py-2">Gecikme zammı ve vadeler fişteki/resmî kayıttaki değerlerdir; uygulama mevzuat hesabı üretmez. Ödeme kaydı, SGK mahsup teyidi verilene kadar borcu kapatmaz.</div>

    <div class="card sgk-card">
        <div class="table-responsive">
            <table id="sgkAccrualsTable" class="table sgk-table table-hover table-sm align-middle mb-0 w-100">
                <thead>
                    <tr>
                        <th>Dönem</th>
                        <th>Şirket</th>
                        <th>İşyeri sicili</th>
                        <th>Şantiye</th>
                        <th>GZ esas tarihi</th>
                        @foreach($amountColumns as $label)
                            <th class="text-end">{{ $label }} (₺)</th>
                        @endforeach
                        <th>Geçerli vade</th>
                        <th class="text-end">Kalan Bakiye (₺)</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($records as $record)
                    @php
                        $isLocked = (float) $record->paid_amount > 0
                            || (bool) ($record->has_active_payment ?? false)
                            || in_array($record->status, ['paid', 'cancelled'], true);
                    @endphp
                    <tr>
                        <td class="text-nowrap fw-semibold">{{ $record->period ?: sprintf('%04d-%02d', $record->period_year, $record->period_month) }}</td>
                        <td>{{ $record->company?->title ?: '—' }}</td>
                        <td class="text-nowrap">{{ $record->workplace?->registration_no ?: '—' }}</td>
                        <td>{{ $record->site?->name ?: '—' }}</td>
                        <td class="text-nowrap">{{ $record->late_charge_as_of?->format('d.m.Y') ?: '—' }}</td>
                        @foreach($amountColumns as $field => $label)
                            <td class="text-end text-nowrap">{{ number_format((float) ($record->{$field} ?? 0), 2, ',', '.') }}</td>
                        @endforeach
                        <td class="text-nowrap">
                            {{ $record->effective_due_date?->format('d.m.Y') ?: '—' }}
                            @if(!$record->due_date_verified)
                                <span class="sgk-pill sgk-pill-amber">Kontrol et</span>
                            @endif
                        </td>
                        <td class="text-end text-nowrap fw-bold">{{ number_format((float) $record->remaining, 2, ',', '.') }}</td>
                        <td>
                            <span class="sgk-pill">{{ ['draft'=>'Taslak','pending_approval'=>'Onay bekliyor','payable'=>'Ödenecek','partial'=>'Kısmi ödeme','paid'=>'Ödendi','overdue'=>'Gecikmiş','disputed'=>'İhtilaflı','cancelled'=>'İptal'][$record->status] ?? 'Bilinmiyor' }}</span>
                        </td>
                        <td class="text-nowrap text-end">
                            @if(!$isLocked)
                                <a class="btn btn-sm btn-outline-primary" href="{{ route('admin.sgk-accruals.edit', $record->id) }}" title="Tahakkuku Düzenle">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-pencil-square me-1" viewBox="0 0 16 16">
                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                    </svg>Düzenle
                                </a>
                            @else
                                <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="Ödeme girilen veya kapatılan kayıt düzenlenemez">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-lock-fill me-1" viewBox="0 0 16 16">
                                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2"/>
                                    </svg>Kilitli
                                </button>
                            @endif

                            @if($record->status === 'draft')
                                <form method="POST" action="{{ route('admin.sgk-accruals.submit', $record->id) }}" class="d-inline">@csrf<button class="btn btn-sm btn-outline-warning">Onaya gönder</button></form>
                            @elseif($record->status === 'pending_approval')
                                <form method="POST" action="{{ route('admin.sgk-accruals.approve', $record->id) }}" class="d-inline">@csrf<button class="btn btn-sm btn-success">Onayla</button></form>
                            @elseif(!in_array($record->status, ['paid','cancelled'], true))
                                <button class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#pay{{ $record->id }}">Ödeme gir</button>
                            @endif
                            @if($record->document_path)
                                <a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.sgk-accruals.document', $record->id) }}">Fiş</a>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>

    @foreach($records as $record)
        @if(!in_array($record->status, ['draft','pending_approval','paid','cancelled'], true))
            <div class="modal fade" id="pay{{ $record->id }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <form method="POST" enctype="multipart/form-data" action="{{ route('admin.sgk-accruals.payments.store', $record->id) }}" class="modal-content">
                        @csrf
                        <div class="modal-header">
                            <h5 class="modal-title">Ödeme kaydı · {{ $record->period }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-info">Ödeme, SGK'ya mahsup edildiği doğrulanana kadar kalan borçta mahsup edilmez.</div>
                            
                            <label class="form-label">Kim Ödedi</label>
                            <select class="form-select mb-3" name="paid_by" required>
                                <option value="">Ödeyen kişiyi seçin</option>
                                @foreach($payers as $payer)
                                    <option value="{{ $payer }}">{{ $payer }}</option>
                                @endforeach
                            </select>

                            <label class="form-label">Ödeme tarihi</label>
                            <input class="form-control mb-3" type="date" name="payment_date" required value="{{ today()->format('Y-m-d') }}">
                            
                            <label class="form-label">Tutar (kalan {{ number_format((float) $record->remaining, 2, ',', '.') }} ₺)</label>
                            <input class="form-control mb-3" type="number" name="amount" step="0.01" min="0.01" max="{{ $record->remaining }}" required>
                            
                            <label class="form-label">Ödeme yöntemi</label>
                            <select class="form-select mb-3" name="payment_method">
                                <option value="bank">Banka</option>
                                <option value="online">Çevrim içi</option>
                                <option value="other">Diğer</option>
                            </select>
                            
                            <label class="form-label">Banka referansı</label>
                            <input class="form-control mb-3" name="bank_reference">
                            
                            <label class="form-label">Dekont</label>
                            <input class="form-control" type="file" name="receipt" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary">Ödemeyi kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        @endif
    @endforeach
</div>
@endsection
@include('sgk_debt::partials.datatable', ['tableId' => 'sgkAccrualsTable', 'title' => 'SGK Tahakkuk Fişleri'])
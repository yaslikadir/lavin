@extends('layouts.admin')
@include('sgk_debt::partials.styles')
@section('title', 'SGK Fişlerini İçe Aktar')
@section('content')
<div class="container px-3 py-4 sgk-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div><h1 class="h3 mb-1">SGK tahakkuk fişlerini CSV'den aktar</h1><p class="text-muted mb-0">SGK dökümündeki borç ve gecikme zammı sütunları taslak kayıt olarak içe alınır.</p></div>
        <a class="btn btn-outline-secondary" href="{{ route('admin.sgk-accruals.index') }}">Tahakkuk listesine dön</a>
    </div>
    @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif
    <form method="POST" enctype="multipart/form-data" action="{{ route('admin.sgk-accruals.import.store') }}" class="card sgk-card">
        @csrf
        <div class="card-body">
            <div class="alert alert-info">
                <div class="fw-semibold mb-1">CSV sütunları</div>
                Şablon, PDF fişindeki dönem, durum, gecikme zammı esas tarihi, her borç/GZ kalemi ve iki toplam alanını içerir. İlk sütun başlıklarını değiştirmeyin; şablonu indirip doldurun.
                <div class="mt-2"><a class="btn btn-sm btn-outline-primary" href="{{ route('admin.sgk-accruals.import-template') }}">CSV şablonunu indir</a></div>
            </div>
            <label class="form-label" for="workplace_id">SGK işyeri sicili</label>
            <select id="workplace_id" class="form-select mb-3" name="workplace_id" required>
                <option value="">Sicil seçin</option>
                @foreach($workplaces as $workplace)<option value="{{ $workplace->id }}" @selected(old('workplace_id') == $workplace->id)>{{ $workplace->registration_no }} · {{ $workplace->company?->title }}</option>@endforeach
            </select>
            <label class="form-label" for="file">CSV dosyası</label>
            <input id="file" type="file" class="form-control" name="file" required accept=".csv,.txt">
            <div class="form-text">Virgül veya noktalı virgül ayraçlı CSV kabul edilir. Yüklenen satırlar taslak olur; ödeme öncesinde fiş ve vadeler kontrol edilmelidir.</div>
        </div>
        <div class="card-footer bg-white text-end"><button class="btn btn-primary">Taslak fişleri içe aktar</button></div>
    </form>
</div>
@endsection

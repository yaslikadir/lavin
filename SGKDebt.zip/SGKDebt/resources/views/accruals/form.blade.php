@extends('layouts.admin')
@include('sgk_debt::partials.styles')

@section('title', $record->exists ? 'SGK Tahakkuk Fişini Düzenle' : 'Yeni SGK Tahakkuk Fişi')

@section('content')
@php
    $periodYear = old('period_year', $record->period_year ?: (int) substr((string) $record->period, 0, 4));
    $periodMonth = old('period_month', $record->period_month ?: (int) substr((string) $record->period, 5, 2));
    $moneyFields = [
        'premium_debt' => 'Prim Borcu',
        'premium_late_charge' => 'Prim Borcu Gecikme Zammı',
    ];
@endphp
<div class="container-fluid px-3 px-lg-4 py-4 sgk-shell">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h1 class="h3 mb-1">{{ $record->exists ? 'SGK Tahakkuk Fişini Düzenle' : 'Yeni SGK Tahakkuk Fişi' }}</h1>
            <div class="text-muted">Sadeleştirilmiş SGK tahakkuk ve gecikme zammı giriş ekranı.</div>
        </div>
        <a class="btn btn-outline-secondary" href="{{ route('admin.sgk-accruals.index') }}">Tahakkuk listesine dön</a>
    </div>

    @if($errors->any())
        <div class="alert alert-danger"><strong>Kayıt tamamlanamadı.</strong><ul class="mb-0 mt-2">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif

    <form method="POST" enctype="multipart/form-data" action="{{ $record->exists ? route('admin.sgk-accruals.update', $record->id) : route('admin.sgk-accruals.store') }}" class="card sgk-card">
        @csrf
        @if($record->exists) @method('PUT') @endif
        <div class="card-body p-3 p-lg-4">
            <h2 class="h5 mb-3">İşyeri ve dönem bilgileri</h2>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Şirket</label>
                    <select class="form-select" name="company_id" required>
                        <option value="">Şirket seçin</option>
                        @foreach($companies as $company)
                            <option value="{{ $company->id }}" @selected(old('company_id', $record->company_id) == $company->id)>{{ $company->title }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Şantiye</label>
                    <select class="form-select" name="site_id">
                        <option value="">Şantiye seçilmedi</option>
                        @foreach($sites as $site)
                            <option value="{{ $site->id }}" @selected(old('site_id', $record->site_id) == $site->id)>{{ $site->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">İşyeri sicil numarası</label>
                    <select class="form-select" name="workplace_id" required>
                        <option value="">SGK sicili seçin</option>
                        @foreach($workplaces as $workplace)
                            <option value="{{ $workplace->id }}" @selected(old('workplace_id', $record->workplace_id) == $workplace->id)>{{ $workplace->registration_no }} · {{ $workplace->company?->title }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Dönem yılı</label>
                    <input class="form-control" type="number" name="period_year" min="2000" max="2100" required value="{{ $periodYear }}">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Dönem ayı</label>
                    <select class="form-select" name="period_month" required>
                        <option value="">Ay seçin</option>
                        @foreach(range(1, 12) as $month)
                            <option value="{{ $month }}" @selected((int) $periodMonth === $month)>{{ sprintf('%02d', $month) }} · {{ \Carbon\Carbon::create()->month($month)->translatedFormat('F') }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-5">
                    <label class="form-label">Gecikme zammı esas tarihi</label>
                    <input class="form-control" type="date" name="late_charge_as_of" value="{{ old('late_charge_as_of', $record->late_charge_as_of?->format('Y-m-d')) }}">
                </div>
            </div>

            <div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
                <div>
                    <h2 class="h5 mb-1">Tahakkuk fişi tutar sütunları</h2>
                    <div class="small text-muted">Ana borç ve gecikme zammı toplamları otomatik hesaplanır.</div>
                </div>
                <span class="badge text-bg-light">Türk lirası (₺)</span>
            </div>
            <div class="row g-3">
                @foreach($moneyFields as $field => $label)
                    <div class="col-md-6">
                        <label class="form-label fw-semibold" for="{{ $field }}_display">{{ $label }}</label>
                        @php $amountValue = old($field, $record->{$field} ?? ''); @endphp
                        <div class="input-group">
                            <input id="{{ $field }}_display" class="form-control sgk-money-input" type="text" inputmode="decimal" autocomplete="off" data-money-display="{{ $field }}" aria-label="{{ $label }} tutarı" placeholder="0.00" value="{{ $amountValue }}">
                            <span class="input-group-text">₺</span>
                            <input type="hidden" name="{{ $field }}" id="{{ $field }}" value="{{ $amountValue }}">
                        </div>
                    </div>
                @endforeach
            </div>

            <hr class="my-4">
            <h2 class="h5 mb-3">Vade ve fiş arşivi</h2>
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Geçerli son vade</label>
                    <input class="form-control" type="date" name="effective_due_date" value="{{ old('effective_due_date', $record->effective_due_date?->format('Y-m-d')) }}">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Kaynak</label>
                    <select class="form-select" name="source">
                        <option value="manual" @selected(old('source', $record->source ?: 'manual') === 'manual')>Elle girildi</option>
                        <option value="import" @selected(old('source', $record->source) === 'import')>Dosyadan aktarıldı</option>
                        <option value="official_portal" @selected(old('source', $record->source) === 'official_portal')>Resmî portaldan kontrol edildi</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Fiş eki (PDF / görsel / tablo)</label>
                    <input class="form-control" type="file" name="document" accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.csv">
                </div>
                <div class="col-md-3">
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="due_date_verified" value="1" id="dueVerified" @checked(old('due_date_verified', $record->due_date_verified))>
                        <label class="form-check-label" for="dueVerified">Geçerli son vadeyi doğruladım</label>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label">Açıklama</label>
                    <textarea class="form-control" name="description" rows="2">{{ old('description', $record->description) }}</textarea>
                </div>
            </div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
            <div class="small text-muted">
                Otomatik Genel Toplam: <strong id="liveGrandTotal" class="text-dark">0,00 ₺</strong>
            </div>
            <button class="btn btn-primary">{{ $record->exists ? 'Değişiklikleri kaydet' : 'Tahakkuk fişini kaydet' }}</button>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const displays = document.querySelectorAll('[data-money-display]');
    const liveTotalEl = document.getElementById('liveGrandTotal');

    function parseAmount(value) {
        let text = String(value || '').replace(/[^0-9.,]/g, '');
        if (!text) return { display: '', raw: '' };

        const dot = text.lastIndexOf('.');
        const comma = text.lastIndexOf(',');
        const separatorIndex = Math.max(dot, comma);
        const separator = separatorIndex >= 0 ? text[separatorIndex] : '';
        const decimals = separatorIndex >= 0 ? text.length - separatorIndex - 1 : 0;
        const hasDecimal = separator && (decimals === 0 || decimals <= 2);

        let integerPart;
        let fractionPart = '';
        if (hasDecimal) {
            integerPart = text.slice(0, separatorIndex).replace(/[.,]/g, '');
            fractionPart = text.slice(separatorIndex + 1).replace(/[.,]/g, '').slice(0, 2);
        } else {
            integerPart = text.replace(/[.,]/g, '');
        }

        integerPart = integerPart.replace(/^0+(?=\d)/, '');
        if (!integerPart) integerPart = '0';
        const grouped = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        const display = grouped + (hasDecimal ? '.' + fractionPart : '');
        const raw = integerPart + (hasDecimal && fractionPart ? '.' + fractionPart : '');
        return { display, raw };
    }

    function updateLiveTotal() {
        if (!liveTotalEl) return;
        let sum = 0;
        displays.forEach(function (input) {
            const hidden = document.getElementById(input.dataset.moneyDisplay);
            const val = parseFloat(hidden?.value || '0');
            if (!isNaN(val)) sum += val;
        });
        liveTotalEl.textContent = sum.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₺';
    }

    function placeCaretAfterDigitCount(input, digitCount) {
        if (!digitCount) { input.setSelectionRange(input.value.length, input.value.length); return; }
        let seen = 0;
        for (let index = 0; index < input.value.length; index++) {
            if (/\d/.test(input.value[index])) seen++;
            if (seen >= digitCount) { input.setSelectionRange(index + 1, index + 1); return; }
        }
        input.setSelectionRange(input.value.length, input.value.length);
    }

    displays.forEach(function (input) {
        const hidden = document.getElementById(input.dataset.moneyDisplay);
        if (!hidden) return;

        const initial = parseAmount(input.value || hidden.value);
        input.value = initial.display;
        hidden.value = initial.raw;

        input.addEventListener('input', function () {
            const caret = input.selectionStart ?? input.value.length;
            const digitsBeforeCaret = (input.value.slice(0, caret).match(/\d/g) || []).length;
            const parsed = parseAmount(input.value);
            input.value = parsed.display;
            hidden.value = parsed.raw;
            placeCaretAfterDigitCount(input, digitsBeforeCaret);
            updateLiveTotal();
        });

        input.addEventListener('blur', function () {
            const parsed = parseAmount(input.value);
            input.value = parsed.display.replace(/\.$/, '');
            hidden.value = parsed.raw.replace(/\.$/, '');
            updateLiveTotal();
        });
    });

    updateLiveTotal();

    const form = document.querySelector('form.sgk-card');
    if (form) {
        form.addEventListener('submit', function () {
            displays.forEach(function (input) {
                const parsed = parseAmount(input.value);
                const hidden = document.getElementById(input.dataset.moneyDisplay);
                if (hidden) hidden.value = parsed.raw.replace(/\.$/, '');
            });
        });
    }
});
</script>
@endpush
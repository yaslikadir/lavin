@once
@push('css')
<style>
.sgk-shell{color:#172b4d}.sgk-hero{border:0;border-radius:1rem;background:linear-gradient(120deg,#122b45,#176b72);color:#fff;box-shadow:0 12px 35px #18374a22}.sgk-card{border:1px solid #e7edf3;border-radius:.9rem;box-shadow:0 4px 15px #18374a0b}.sgk-stat{height:100%;padding:1.1rem;border:1px solid #e7edf3;border-radius:.85rem;background:#fff}.sgk-stat-label{font-size:.72rem;font-weight:700;letter-spacing:.06em;color:#728197;text-transform:uppercase}.sgk-stat-value{font-size:1.55rem;font-weight:750;margin-top:.35rem;color:#162b46}.sgk-stat-note{font-size:.75rem;color:#7d8999;margin-top:.25rem}.sgk-table th{font-size:.72rem;white-space:nowrap;color:#66778c;background:#f7f9fb}.sgk-table td{font-size:.82rem;vertical-align:middle}.sgk-pill{display:inline-block;padding:.27rem .55rem;border-radius:99px;font-size:.7rem;font-weight:700;background:#eef2f6;color:#526174}.sgk-pill-red{background:#ffeaed;color:#b83245}.sgk-pill-green{background:#e6f7ed;color:#207849}.sgk-pill-amber{background:#fff3dd;color:#a95f09}.sgk-note{font-size:.8rem;color:#617187}
</style>
@endpush
@endonce

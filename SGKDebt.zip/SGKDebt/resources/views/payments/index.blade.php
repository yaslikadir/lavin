@extends('layouts.admin')
@include('sgk_debt::partials.styles')
@section('title','Ödeme ve Mahsup Takibi')
@section('content')
<div class="container-fluid px-3 px-lg-4 py-4 sgk-shell">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div><h1 class="h3 mb-1">Ödemeler ve Mahsup Kontrolü</h1><div class="text-muted">Ödeme kaydı, ödeyen kişi, dekont ve SGK borcuna mahsup durumu ayrı izlenir.</div></div>
        <a class="btn btn-outline-secondary" href="{{route('admin.sgk-accruals.index')}}">Tahakkuklara dön</a>
    </div>
    @if(session('success'))<div class="alert alert-success">{{session('success')}}</div>@endif
    <div class="card sgk-card"><div class="table-responsive"><table id="sgkPaymentsTable" class="table sgk-table table-hover mb-0">
        <thead><tr><th>Ödeme tarihi</th><th>Şirket / sicil</th><th>Dönem</th><th>Kim Ödedi</th><th>Tutar</th><th>Yöntem</th><th>Dekont</th><th>Mahsup</th><th>Durum / İşlem</th></tr></thead>
        <tbody>@foreach($records as $p)
        <tr>
            <td>{{$p->payment_date?->format('d.m.Y')}}</td>
            <td>{{$p->accrual?->company?->title}}<br><small>{{$p->accrual?->workplace?->registration_no}}</small></td>
            <td>{{$p->accrual?->period}}</td>
            <td class="fw-semibold">{{$p->paid_by ?: '—'}}</td>
            <td class="fw-semibold">{{number_format((float)$p->amount,2,',','.')}} ₺</td>
            <td>{{['bank'=>'Banka','online'=>'Çevrim içi','other'=>'Diğer'][$p->payment_method]??'—'}}</td>
            <td>@if($p->receipt_path)<a href="{{route('admin.sgk-payments.receipt',$p->id)}}">Dekontu indir</a>@else—@endif</td>
            <td><span class="sgk-pill {{$p->allocation_status==='confirmed'?'sgk-pill-green':'sgk-pill-amber'}}">{{$p->allocation_status==='confirmed'?'Mahsup doğrulandı':'Doğrulama bekliyor'}}</span></td>
            <td>
                @if($p->status==='recorded' && $p->allocation_status==='unconfirmed')
                    <form method="POST" action="{{route('admin.sgk-payments.confirm-allocation',$p->id)}}" class="d-inline" onsubmit="return confirm('Dekont ve resmî borç kaydını kontrol ederek mahsup edildiğini doğruladınız mı?')">@csrf<button class="btn btn-sm btn-success">Mahsup doğrula</button></form>
                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#reverse{{$p->id}}">Ters kayıt</button>
                @elseif($p->status==='reversed')
                    <span class="sgk-pill sgk-pill-red">Ters kayıt</span>
                @else
                    <span class="sgk-pill">Kaydedildi</span>
                @endif
            </td>
        </tr>
        @endforeach</tbody>
    </table></div></div>
    @foreach($records as $p)@if($p->status==='recorded')<div class="modal fade" id="reverse{{$p->id}}" tabindex="-1"><div class="modal-dialog"><form method="POST" action="{{route('admin.sgk-payments.reverse',$p->id)}}" class="modal-content">@csrf<div class="modal-header"><h5 class="modal-title">Gerekçeli ters ödeme kaydı</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><label class="form-label">Düzeltme nedeni (en az 10 karakter)</label><textarea class="form-control" name="reason" minlength="10" required></textarea><div class="small text-muted mt-2">Ödeme geçmişten silinmez. Tutarın borca mahsup edildiği doğrulanmışsa bakiye ters kayıtla geri açılır.</div></div><div class="modal-footer"><button class="btn btn-danger">Ters kayıt oluştur</button></div></form></div></div>@endif @endforeach
</div>
@endsection
@include('sgk_debt::partials.datatable',['tableId'=>'sgkPaymentsTable','title'=>'SGK Ödeme ve Mahsup Takibi'])
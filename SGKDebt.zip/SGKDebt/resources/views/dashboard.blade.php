@extends('layouts.admin')
@include('sgk_debt::partials.styles')
@section('title','SGK Borç ve Prim Takibi')
@push('css')
<style>
.sgk-dash .sgk-hero{position:relative;overflow:hidden}
.sgk-dash .sgk-hero:after{content:'₺';position:absolute;right:4%;top:-42px;font-size:240px;font-weight:800;opacity:.05;line-height:1}
.sgk-dash .sgk-hero>*{position:relative;z-index:1}
.sgk-dash .sgk-stat-icon{float:right;width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:#e9f3f6;color:#187b85}
.sgk-dash .due-row-overdue{background:#fff9f9}
</style>
@endpush

@section('content')
<div class="container-fluid px-3 px-lg-4 py-4 sgk-shell sgk-dash">
    @if(session('success'))<div class="alert alert-success">{{session('success')}}</div>@endif

    <div class="sgk-hero p-4 p-lg-5 mb-4">
        <div class="d-flex flex-wrap justify-content-between gap-3">
            <div>
                <span class="sgk-pill" style="background:#ffffff24;color:#fff">SGK BORÇ VE PRİM YÖNETİMİ</span>
                <h1 class="h2 mt-3 mb-2">Şirket, şantiye ve sicil bazında tek görünüm</h1>
                <p class="mb-0" style="color:#d5e6ec">Prim borçları, gecikme zamları, ödeme kayıtları ve mahsup kontrolünü birlikte yönetin.</p>
                <div class="small mt-3" style="color:#d5e6ec">{{session('active_branch_name','Aktif şube')}} · {{now()->translatedFormat('d F Y')}}</div>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <a class="btn btn-light" href="{{route('admin.sgk-accruals.create')}}">+ Tahakkuk gir</a>
                <a class="btn btn-outline-light" href="{{route('admin.sgk-accruals.index')}}">Tahakkuk listesi</a>
                <a class="btn btn-outline-light" href="{{route('admin.sgk-accruals.import')}}">Dosyadan aktar</a>
            </div>
        </div>
    </div>

    @if(!(int)session('active_branch_id'))
        <div class="alert alert-warning">Devam etmek için önce aktif şube seçin. Veriler şube kapsamı olmadan gösterilmez.</div>
    @endif

    <div class="row g-3 mb-4">
        @foreach([
            ['Şirketler','admin.sgk-companies.index','building'],
            ['Şantiyeler','admin.sgk-sites.index','map-pin'],
            ['SGK sicilleri','admin.sgk-workplaces.index','file-text'],
            ['Ödeme ve mahsup','admin.sgk-payments.index','credit-card']
        ] as [$label,$routeName,$icon])
            <div class="col-6 col-lg-3">
                <a href="{{route($routeName)}}" class="card sgk-card text-decoration-none text-dark h-100">
                    <div class="card-body d-flex align-items-center gap-3">
                        <span class="sgk-stat-icon"><i data-feather="{{$icon}}" style="width:17px"></i></span>
                        <div class="fw-semibold">{{$label}}</div>
                        <span class="ms-auto">›</span>
                    </div>
                </a>
            </div>
        @endforeach
    </div>

    <div class="row g-3 mb-4">
        @foreach([
            ['Şirket','companies','building'],
            ['Şantiye','sites','map-pin'],
            ['Aktif SGK sicili','workplaces','file-text'],
            ['Toplam kalan borç','open_balance','wallet'],
            ['14 günde vadesi gelen','due_14_count','calendar'],
            ['Vadesi geçmiş','overdue_count','alert-triangle'],
            ['Gecikmiş bakiye','overdue_balance','alert-circle'],
            ['Vadesi doğrulanmamış','unverified_due','help-circle'],
            ['Onay bekleyen','approval_count','check-square'],
            ['Bu ay kaydedilen ödeme','month_paid','credit-card']
        ] as [$label,$key,$icon])
            <div class="col-6 col-xl-2">
                <div class="sgk-stat">
                    <div class="sgk-stat-icon"><i data-feather="{{$icon}}" style="width:17px"></i></div>
                    <div class="sgk-stat-label">{{$label}}</div>
                    <div class="sgk-stat-value">
                        @if(in_array($key,['open_balance','overdue_balance','month_paid']))
                            {{number_format($stats[$key],0,',','.')}} ₺
                        @else
                            {{number_format($stats[$key])}}
                        @endif
                    </div>
                    <div class="sgk-stat-note">Seçili şube toplamı</div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-8">
            <div class="card sgk-card h-100">
                <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                    <div>
                        <strong>Vade takvimi</strong>
                        <div class="sgk-note">Geçmiş 30 gün ve gelecek 14 gün · geçerli son vade tarihi</div>
                    </div>
                    <a class="btn btn-sm btn-outline-primary" href="{{route('admin.sgk-accruals.index',['due'=>'soon'])}}">Tüm vadeler</a>
                </div>
                <div class="table-responsive">
                    <table id="sgkDueTable" class="table sgk-table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Şirket / sicil</th>
                                <th>Dönem</th>
                                <th>Geçerli vade</th>
                                <th class="text-end">Kalan bakiye</th>
                                <th>Vade durumu</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($due as $a)
                            @php($remaining = $a->remaining)
                            <tr class="{{$a->display_due_date && $a->display_due_date->isPast()?'due-row-overdue':''}}">
                                <td>
                                    <div class="fw-semibold">{{$a->company?->title}}</div>
                                    <small class="text-muted">{{$a->workplace?->registration_no}} · {{$a->site?->name}}</small>
                                </td>
                                <td class="fw-semibold">{{$a->period}}</td>
                                <td>
                                    {{$a->display_due_date?->format('d.m.Y') ?? '—'}}
                                    @if(!$a->due_date_verified)<span class="sgk-pill sgk-pill-amber">Kontrol et</span>@endif
                                </td>
                                <td class="text-end fw-semibold">{{number_format($remaining,2,',','.')}} ₺</td>
                                <td>{{$a->display_due_date && $a->display_due_date->isPast() ? 'Gecikmiş' : 'Yaklaşan'}}</td>
                                <td><span class="sgk-pill">{{['draft'=>'Taslak','pending_approval'=>'Onay bekliyor','payable'=>'Ödenecek','partial'=>'Kısmi ödeme','paid'=>'Ödendi','overdue'=>'Gecikmiş','disputed'=>'İhtilaflı'][$a->status] ?? 'Bilinmiyor'}}</span></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-xl-4 d-flex flex-column gap-3">
            <div class="card sgk-card">
                <div class="card-header bg-white border-0 pt-3">
                    <strong>Şantiye bazlı açık borç</strong>
                    <div class="sgk-note">Prim borcu + GZ kalan bakiyesi · TRY</div>
                </div>
                <div class="table-responsive">
                    <table class="table sgk-table mb-0">
                        <thead><tr><th>Şantiye</th><th>Fiş</th><th class="text-end">Bakiye</th></tr></thead>
                        <tbody>
                        @forelse($sites as $s)
                            <tr>
                                <td>{{$s->name}}<br><small class="text-muted">{{$s->code}}</small></td>
                                <td>{{$s->debt_count}}</td>
                                <td class="text-end fw-semibold">{{number_format((float)$s->balance,2,',','.')}} ₺</td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="text-center text-muted py-3">Kayıt bulunamadı</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card sgk-card">
                <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                    <div>
                        <strong>Kişi bazlı ödemeler</strong>
                        <div class="sgk-note">Ödeyen kişilere göre dağılım</div>
                    </div>
                    <a class="btn btn-sm btn-outline-secondary" href="{{route('admin.sgk-payments.index')}}">Tümü</a>
                </div>
                <div class="table-responsive">
                    <table class="table sgk-table mb-0">
                        <thead><tr><th>Kim Ödedi</th><th>İşlem</th><th class="text-end">Toplam Ödenen</th></tr></thead>
                        <tbody>
                        @forelse($payerStats ?? [] as $ps)
                            <tr>
                                <td class="fw-semibold">{{$ps->paid_by}}</td>
                                <td>{{$ps->tx_count}}</td>
                                <td class="text-end fw-semibold">{{number_format((float)$ps->total_paid,2,',','.')}} ₺</td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="text-center text-muted py-3">Henüz kişi bazlı ödeme girilmedi</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card sgk-card">
        <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
            <div>
                <strong>Son tahakkuklar</strong>
                <div class="sgk-note">Prim borcu, gecikme zammı ve kalan bakiye özeti</div>
            </div>
            <a class="btn btn-sm btn-primary" href="{{route('admin.sgk-accruals.index')}}">Tahakkuk listesi</a>
        </div>
        <div class="table-responsive">
            <table class="table sgk-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Dönem</th>
                        <th>Şirket</th>
                        <th>İşyeri sicili</th>
                        <th>Şantiye</th>
                        <th class="text-end">Prim Borcu (₺)</th>
                        <th class="text-end">Prim GZ (₺)</th>
                        <th class="text-end">Kalan Bakiye (₺)</th>
                        <th>Durum</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($recent as $a)
                    @php
                        $isLocked = (float) $a->paid_amount > 0
                            || (bool) ($a->has_active_payment ?? false)
                            || in_array($a->status, ['paid', 'cancelled'], true);
                    @endphp
                    <tr>
                        <td class="fw-semibold text-nowrap">{{$a->period}}</td>
                        <td>{{$a->company?->title ?: '—'}}</td>
                        <td class="text-nowrap">{{$a->workplace?->registration_no ?: '—'}}</td>
                        <td>{{$a->site?->name ?: '—'}}</td>
                        <td class="text-end text-nowrap">{{number_format((float)$a->premium_debt,2,',','.')}}</td>
                        <td class="text-end text-nowrap">{{number_format((float)$a->premium_late_charge,2,',','.')}}</td>
                        <td class="text-end text-nowrap fw-bold">{{number_format($a->remaining,2,',','.')}} ₺</td>
                        <td><span class="sgk-pill">{{['draft'=>'Taslak','pending_approval'=>'Onay bekliyor','payable'=>'Ödenecek','partial'=>'Kısmi ödeme','paid'=>'Ödendi','overdue'=>'Gecikmiş','disputed'=>'İhtilaflı'][$a->status] ?? 'Bilinmiyor'}}</span></td>
                        <td class="text-end text-nowrap">
                            @if(!$isLocked)
                                <a class="btn btn-sm btn-outline-primary" href="{{route('admin.sgk-accruals.edit', $a->id)}}">Düzenle</a>
                            @else
                                <span class="badge text-bg-secondary">Kilitli</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
@include('sgk_debt::partials.datatable',['tableId'=>'sgkDueTable','title'=>'SGK Vade Takvimi'])
<?php
use Illuminate\Support\Facades\Route;
use Modules\SGKDebt\Http\Controllers\DashboardController;
use Modules\SGKDebt\Http\Controllers\CompanyController;
use Modules\SGKDebt\Http\Controllers\SiteController;
use Modules\SGKDebt\Http\Controllers\WorkplaceController;
use Modules\SGKDebt\Http\Controllers\AccrualController;
use Modules\SGKDebt\Http\Controllers\PaymentController;
Route::middleware(['check.module:sgk_debt'])->group(function () {
    Route::get('sgk-debt', [DashboardController::class,'index'])->name('sgk-debt.dashboard');
    Route::resource('sgk-companies', CompanyController::class)->except(['show']);
    Route::resource('sgk-sites', SiteController::class)->except(['show']);
    Route::resource('sgk-workplaces', WorkplaceController::class)->except(['show']);
    Route::get('sgk-accruals/import', [AccrualController::class,'importForm'])->name('sgk-accruals.import');
    Route::get('sgk-accruals/import-template', [AccrualController::class,'importTemplate'])->name('sgk-accruals.import-template');
    Route::post('sgk-accruals/import', [AccrualController::class,'import'])->name('sgk-accruals.import.store');
    Route::get('sgk-accruals/export', [AccrualController::class,'export'])->name('sgk-accruals.export');
    Route::get('sgk-accruals/{id}/document', [AccrualController::class,'document'])->name('sgk-accruals.document');
    Route::get('sgk-payments', [PaymentController::class,'index'])->name('sgk-payments.index');
    Route::resource('sgk-accruals', AccrualController::class)->except(['show']);
    Route::post('sgk-accruals/{id}/submit', [AccrualController::class,'submit'])->name('sgk-accruals.submit');
    Route::post('sgk-accruals/{id}/approve', [AccrualController::class,'approve'])->name('sgk-accruals.approve');
    Route::post('sgk-accruals/{id}/payments', [PaymentController::class,'store'])->name('sgk-accruals.payments.store');
    Route::get('sgk-payments/{id}/receipt', [PaymentController::class,'receipt'])->name('sgk-payments.receipt');
    Route::post('sgk-payments/{id}/confirm-allocation', [PaymentController::class,'confirmAllocation'])->name('sgk-payments.confirm-allocation');
    Route::post('sgk-payments/{id}/reverse', [PaymentController::class,'reverse'])->name('sgk-payments.reverse');
});

<?php
namespace Modules\SGKDebt\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
abstract class BaseController extends Controller
{
    protected function branch(): int { $id=(int)session('active_branch_id',0); abort_if(!$id,403,'Önce aktif şube seçilmelidir.'); return $id; }
    protected function scope(string $model) { return $model::query()->where('branch_id',$this->branch()); }
    protected function authorizeModule(): void { $u=auth()->user(); $allowed=$u && ((method_exists($u,'isAdmin') && $u->isAdmin()) || (method_exists($u,'hasRole') && $u->hasRole('admin')) || (method_exists($u,'hasModuleAccess') && $u->hasModuleAccess('sgk_debt')) || (method_exists($u,'hasPermissionToAccessModule') && $u->hasPermissionToAccessModule('sgk_debt'))); abort_unless($allowed,403,'SGK borç modülüne erişim yetkiniz yok.'); }
    protected function existsInBranch(string $table, int $id): bool { return Schema::hasTable($table) && DB::table($table)->where('id',$id)->where('branch_id',$this->branch())->when(Schema::hasColumn($table,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->exists(); }
}

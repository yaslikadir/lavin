<?php
namespace Modules\SGKDebt\Http\Controllers;
use Illuminate\Http\Request; use Illuminate\Validation\Rule; use Modules\SGKDebt\Models\Company;
class CompanyController extends BaseController
{
 public function index(){ $this->authorizeModule(); $records=$this->scope(Company::class)->withCount(['sites','workplaces','accruals'])->latest()->get(); return view('sgk_debt::companies.index',compact('records')); }
 public function create(){ $this->authorizeModule(); $record=new Company; return view('sgk_debt::companies.form',compact('record')); }
 public function store(Request $r){ $this->authorizeModule(); $b=$this->branch(); $d=$r->validate(['code'=>['required','string','max:50',Rule::unique('sgk_companies','code')->where('branch_id',$b)],'title'=>'required|string|max:255','tax_number'=>'nullable|string|max:30','tax_office'=>'nullable|string|max:100','email'=>'nullable|email|max:255','phone'=>'nullable|string|max:50','address'=>'nullable|string','status'=>'required|in:active,inactive,closing','notes'=>'nullable|string']); $d['branch_id']=$b; $this->scope(Company::class)->create($d); return redirect()->route('admin.sgk-companies.index')->with('success','Şirket kaydedildi.'); }
 public function edit($id){$this->authorizeModule();$record=$this->scope(Company::class)->findOrFail($id);return view('sgk_debt::companies.form',compact('record'));}
 public function update(Request $r,$id){$this->authorizeModule();$b=$this->branch();$record=$this->scope(Company::class)->findOrFail($id);$d=$r->validate(['code'=>['required','string','max:50',Rule::unique('sgk_companies','code')->where('branch_id',$b)->ignore($record->id)],'title'=>'required|string|max:255','tax_number'=>'nullable|string|max:30','tax_office'=>'nullable|string|max:100','email'=>'nullable|email|max:255','phone'=>'nullable|string|max:50','address'=>'nullable|string','status'=>'required|in:active,inactive,closing','notes'=>'nullable|string']);$record->update($d);return redirect()->route('admin.sgk-companies.index')->with('success','Şirket güncellendi.');}
 public function destroy($id){$this->authorizeModule();$r=$this->scope(Company::class)->findOrFail($id);abort_if($r->sites()->exists()||$r->workplaces()->exists()||$r->accruals()->exists(),409,'İlişkili kayıt bulunduğu için şirket silinemez.');$r->delete();return back()->with('success','Şirket silindi.');}
}

<?php

namespace Modules\SGKDebt\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Modules\SGKDebt\Models\Accrual;
use Modules\SGKDebt\Models\Company;
use Modules\SGKDebt\Models\Payment;
use Modules\SGKDebt\Models\Site;
use Modules\SGKDebt\Models\Workplace;

class DashboardController extends BaseController
{
    public function index()
    {
        $this->authorizeModule();
        $b = $this->branch();
        $today = Carbon::today();
        $end = $today->copy()->addDays(14);

        $a = $this->scope(Accrual::class);
        $base = $a->clone();

        // Prim Borcu + Prim GZ toplamını baz alan dinamik kalan borç formülü
        $calcTotalSql = 'CASE WHEN (premium_debt + premium_late_charge) > 0 THEN (premium_debt + premium_late_charge) ELSE principal_amount END';
        $remaining = fn ($q) => $q->selectRaw("COALESCE(SUM(GREATEST(({$calcTotalSql}) - incentive_amount + adjustment_amount - paid_amount, 0)), 0) AS aggregate");
        $open = fn ($q) => $q->whereNotIn('status', ['paid', 'cancelled', 'disputed']);

        $stats = [
            'companies' => $this->scope(Company::class)->count(),
            'sites' => $this->scope(Site::class)->count(),
            'workplaces' => $this->scope(Workplace::class)->where('status', 'active')->count(),
            'open_balance' => (float) $remaining($open(clone $base))->value('aggregate'),
            'due_14_count' => (clone $open(clone $base))->whereNotNull('effective_due_date')->whereBetween('effective_due_date', [$today, $end])->count(),
            'overdue_count' => (clone $open(clone $base))->whereNotNull('effective_due_date')->where('effective_due_date', '<', $today)->count(),
            'overdue_balance' => (float) $remaining((clone $open(clone $base))->whereNotNull('effective_due_date')->where('effective_due_date', '<', $today))->value('aggregate'),
            'unverified_due' => (clone $open(clone $base))->where('due_date_verified', false)->count(),
            'approval_count' => (clone $base)->where('status', 'pending_approval')->count(),
            'month_paid' => (float) $this->scope(Payment::class)
                ->where('status', 'recorded')
                ->whereBetween('payment_date', [$today->copy()->startOfMonth(), $today->copy()->endOfMonth()])
                ->sum('amount'),
        ];

        $due = $this->scope(Accrual::class)
            ->with(['company', 'site', 'workplace'])
            ->whereNotIn('status', ['paid', 'cancelled', 'disputed'])
            ->whereNotNull('effective_due_date')
            ->whereBetween('effective_due_date', [$today->copy()->subDays(30), $end])
            ->orderBy('effective_due_date')
            ->limit(15)
            ->get();

        $recent = $this->scope(Accrual::class)
            ->with(['company', 'site', 'workplace'])
            ->withExists(['payments as has_active_payment' => function ($q) {
                $q->where('status', 'recorded');
            }])
            ->latest('id')
            ->limit(8)
            ->get();

        $siteCalcSql = 'CASE WHEN (a.premium_debt + a.premium_late_charge) > 0 THEN (a.premium_debt + a.premium_late_charge) ELSE a.principal_amount END';
        $sites = Schema::hasTable('sgk_sites')
            ? DB::table('sgk_sites as s')
                ->leftJoin('sgk_accruals as a', function ($j) use ($b) {
                    $j->on('a.site_id', '=', 's.id')
                        ->where('a.branch_id', '=', $b)
                        ->whereNull('a.deleted_at')
                        ->whereNotIn('a.status', ['paid', 'cancelled', 'disputed']);
                })
                ->where('s.branch_id', $b)
                ->whereNull('s.deleted_at')
                ->groupBy('s.id', 's.name', 's.code')
                ->select(
                    's.id',
                    's.name',
                    's.code',
                    DB::raw('COUNT(a.id) as debt_count'),
                    DB::raw("COALESCE(SUM(GREATEST(({$siteCalcSql}) - a.incentive_amount + a.adjustment_amount - a.paid_amount, 0)), 0) as balance")
                )
                ->orderByDesc('balance')
                ->limit(8)
                ->get()
            : collect();

        // Kişi bazlı (Kim Ödedi) toplam ödeme dağılımı
        $payerStats = Schema::hasColumn('sgk_payments', 'paid_by')
            ? $this->scope(Payment::class)
                ->where('status', 'recorded')
                ->whereNotNull('paid_by')
                ->select('paid_by', DB::raw('COUNT(id) as tx_count'), DB::raw('SUM(amount) as total_paid'))
                ->groupBy('paid_by')
                ->orderByDesc('total_paid')
                ->get()
            : collect();

        return view('sgk_debt::dashboard', compact('stats', 'due', 'recent', 'sites', 'payerStats'));
    }
}
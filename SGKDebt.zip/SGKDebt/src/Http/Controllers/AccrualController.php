<?php

namespace Modules\SGKDebt\Http\Controllers;

use DateTimeImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Modules\SGKDebt\Models\Accrual;
use Modules\SGKDebt\Models\Company;
use Modules\SGKDebt\Models\Site;
use Modules\SGKDebt\Models\Workplace;

class AccrualController extends BaseController
{
    /** Sadeleştirilmiş aktif SGK tutar sütunları. */
    private const AMOUNT_FIELDS = [
        'premium_debt',
        'premium_late_charge',
    ];

    /** Kaldırılan ve 0 olarak sabitlenecek eski sütunlar. */
    private const REMOVED_AMOUNT_FIELDS = [
        'administrative_penalty_debt',
        'administrative_penalty_late_charge',
        'education_contribution_debt',
        'education_contribution_late_charge',
        'special_transaction_tax_debt',
        'special_transaction_tax_late_charge',
        'unemployment_debt',
        'unemployment_late_charge',
        'stamp_tax_debt',
        'frozen_premium_late_debt',
        'frozen_unemployment_debt',
        'frozen_unemployment_late_charge',
    ];

    private function options(): array
    {
        return [
            'companies' => $this->scope(Company::class)->orderBy('title')->get(),
            'sites' => $this->scope(Site::class)->orderBy('name')->get(),
            'workplaces' => $this->scope(Workplace::class)->orderBy('registration_no')->get(),
        ];
    }

    private function assertRelations(array $data): void
    {
        $branchId = $this->branch();
        $workplace = Workplace::query()->where('branch_id', $branchId)->findOrFail((int) $data['workplace_id']);

        abort_unless(
            (int) $workplace->company_id === (int) $data['company_id'],
            422,
            'Seçilen işyeri sicili bu şirkete bağlı değil.'
        );

        if (!empty($data['site_id'])) {
            abort_unless(
                (int) $workplace->site_id === (int) $data['site_id'],
                422,
                'Seçilen şantiye, SGK sicilinin bağlı olduğu şantiye değil.'
            );
        }
    }

    private function validationRules(int $branchId): array
    {
        $amountRules = [];
        foreach (self::AMOUNT_FIELDS as $field) {
            $amountRules[$field] = ['nullable', 'numeric', 'min:0', 'decimal:0,2'];
        }

        return array_merge([
            'company_id' => ['required', 'integer', Rule::exists('sgk_companies', 'id')->where('branch_id', $branchId)],
            'site_id' => ['nullable', 'integer', Rule::exists('sgk_sites', 'id')->where('branch_id', $branchId)],
            'workplace_id' => ['required', 'integer', Rule::exists('sgk_workplaces', 'id')->where('branch_id', $branchId)],
            'period_year' => ['required', 'integer', 'between:2000,2100'],
            'period_month' => ['required', 'integer', 'between:1,12'],
            'late_charge_as_of' => ['nullable', 'date'],
            'effective_due_date' => ['nullable', 'date'],
            'due_date_verified' => ['nullable', 'boolean'],
            'source' => ['required', Rule::in(['manual', 'import', 'official_portal'])],
            'description' => ['nullable', 'string', 'max:10000'],
            'document' => ['nullable', 'file', 'max:20480', 'mimes:pdf,jpg,jpeg,png,xlsx,xls,csv'],
        ], $amountRules);
    }

    private function normalizedAmounts(array $data): array
    {
        foreach (self::AMOUNT_FIELDS as $field) {
            $data[$field] = (float) ($data[$field] ?? 0);
        }

        foreach (self::REMOVED_AMOUNT_FIELDS as $removedField) {
            $data[$removedField] = 0.0;
        }

        $data['debt_only_total'] = round($data['premium_debt'], 2);
        $data['late_charge_total'] = round($data['premium_late_charge'], 2);
        $data['principal_amount'] = round($data['debt_only_total'] + $data['late_charge_total'], 2);
        $data['incentive_amount'] = 0;
        $data['adjustment_amount'] = 0;
        $data['late_cost_estimate'] = $data['late_charge_total'];
        $data['currency'] = 'TRY';
        $data['period'] = sprintf('%04d-%02d', (int) $data['period_year'], (int) $data['period_month']);
        $data['accrual_type'] = 'premium';

        $data['statement_status'] = null;
        $data['accrual_no'] = null;
        $data['accrued_at'] = null;
        $data['normal_due_date'] = null;
        $data['external_reference'] = null;

        return $data;
    }

    private function isLockedForEdit(Accrual $record): bool
    {
        return (float) $record->paid_amount > 0
            || $record->payments()->where('status', 'recorded')->exists()
            || in_array($record->status, ['paid', 'cancelled'], true);
    }

    public function index(Request $request)
    {
        $this->authorizeModule();
        $query = $this->scope(Accrual::class)
            ->with(['company', 'site', 'workplace'])
            ->withExists(['payments as has_active_payment' => function ($q) {
                $q->where('status', 'recorded');
            }]);

        if ($request->filled('status')) {
            $query->where('status', $request->string('status')->toString());
        }
        if ($request->filled('due')) {
            if ($request->input('due') === 'overdue') {
                $query->where('effective_due_date', '<', today())->whereNotIn('status', ['paid', 'cancelled']);
            } elseif ($request->input('due') === 'soon') {
                $query->whereBetween('effective_due_date', [today(), today()->copy()->addDays(14)])
                    ->whereNotIn('status', ['paid', 'cancelled']);
            }
        }
        if ($request->filled('q')) {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $request->string('q')->toString()) . '%';
            $query->where(function ($sub) use ($term): void {
                $sub->where('period', 'like', $term)
                    ->orWhereHas('company', fn ($company) => $company->where('title', 'like', $term))
                    ->orWhereHas('site', fn ($site) => $site->where('name', 'like', $term))
                    ->orWhereHas('workplace', fn ($workplace) => $workplace->where('registration_no', 'like', $term));
            });
        }

        $records = $query->latest('effective_due_date')->latest('id')->get();
        return view('sgk_debt::accruals.index', compact('records'));
    }

    public function create()
    {
        $this->authorizeModule();
        $now = now();
        $record = new Accrual([
            'status' => 'draft',
            'source' => 'manual',
            'currency' => 'TRY',
            'period_year' => (int) $now->format('Y'),
            'period_month' => (int) $now->format('n'),
        ]);
        ['companies' => $companies, 'sites' => $sites, 'workplaces' => $workplaces] = $this->options();
        return view('sgk_debt::accruals.form', compact('record', 'companies', 'sites', 'workplaces'));
    }

    public function store(Request $request)
    {
        $this->authorizeModule();
        $branchId = $this->branch();
        $data = $request->validate($this->validationRules($branchId));
        $this->assertRelations($data);
        $data = $this->normalizedAmounts($data);
        $file = $request->file('document');
        $data['branch_id'] = $branchId;
        $data['status'] = 'draft';
        $data['created_by'] = auth()->id();
        $data['due_date_verified'] = $request->boolean('due_date_verified');
        $data['due_date_verified_at'] = $data['due_date_verified'] ? now() : null;

        if ($file) {
            $data['document_path'] = $file->store('sgk-debt/' . $branchId . '/accruals', 'public');
            $data['document_name'] = $file->getClientOriginalName();
        }
        unset($data['document']);

        $this->scope(Accrual::class)->create($data);
        return redirect()->route('admin.sgk-accruals.index')->with('success', 'SGK tahakkuk fişi kaydedildi.');
    }

    public function edit($id)
    {
        $this->authorizeModule();
        $record = $this->scope(Accrual::class)->findOrFail($id);

        if ($this->isLockedForEdit($record)) {
            return redirect()->route('admin.sgk-accruals.index')
                ->withErrors(['lock' => 'Ödeme girilen veya kapatılan tahakkuk kaydı kilitlidir, düzenlenemez.']);
        }

        ['companies' => $companies, 'sites' => $sites, 'workplaces' => $workplaces] = $this->options();
        return view('sgk_debt::accruals.form', compact('record', 'companies', 'sites', 'workplaces'));
    }

    public function update(Request $request, $id)
    {
        $this->authorizeModule();
        $branchId = $this->branch();
        $record = $this->scope(Accrual::class)->findOrFail($id);

        if ($this->isLockedForEdit($record)) {
            return redirect()->route('admin.sgk-accruals.index')
                ->withErrors(['lock' => 'Ödeme girilen veya kapatılan tahakkuk kaydı kilitlidir, güncellenemez.']);
        }

        $data = $request->validate($this->validationRules($branchId));
        $this->assertRelations($data);
        $data = $this->normalizedAmounts($data);
        $data['due_date_verified'] = $request->boolean('due_date_verified');
        $data['due_date_verified_at'] = $data['due_date_verified'] ? now() : null;

        $file = $request->file('document');
        if ($file) {
            if ($record->document_path) {
                Storage::disk('public')->delete($record->document_path);
            }
            $data['document_path'] = $file->store('sgk-debt/' . $branchId . '/accruals', 'public');
            $data['document_name'] = $file->getClientOriginalName();
        }
        unset($data['document'], $data['branch_id']);
        $record->update($data);

        return redirect()->route('admin.sgk-accruals.index')->with('success', 'SGK tahakkuk fişi güncellendi.');
    }

    public function destroy($id)
    {
        $this->authorizeModule();
        $record = $this->scope(Accrual::class)->findOrFail($id);
        abort_if($record->payments()->exists(), 409, 'Ödeme geçmişi bulunan tahakkuk silinemez.');
        abort_if($record->status !== 'draft', 409, 'Yalnızca taslak tahakkuk arşivlenebilir.');
        $record->delete();
        return back()->with('success', 'Taslak tahakkuk arşivlendi.');
    }

    public function submit($id)
    {
        $this->authorizeModule();
        $record = $this->scope(Accrual::class)->findOrFail($id);
        abort_unless($record->status === 'draft', 409);
        $record->update(['status' => 'pending_approval']);
        return back()->with('success', 'Tahakkuk onaya gönderildi.');
    }

    public function approve($id)
    {
        $this->authorizeModule();
        $user = auth()->user();
        abort_unless($user && ((method_exists($user, 'hasRole') && $user->hasRole('admin')) || (method_exists($user, 'can') && $user->can('sgk_debt_approve'))), 403, 'Tahakkuk onaylama yetkiniz yok.');
        $record = $this->scope(Accrual::class)->findOrFail($id);
        abort_unless($record->status === 'pending_approval', 409);
        $record->update(['status' => 'payable', 'approved_by' => auth()->id(), 'approved_at' => now()]);
        return back()->with('success', 'Tahakkuk onaylandı.');
    }

    public function importTemplate()
    {
        $this->authorizeModule();
        $headers = array_merge(
            ['period_year', 'period_month', 'late_charge_as_of', 'effective_due_date'],
            self::AMOUNT_FIELDS
        );
        $sample = array_fill_keys($headers, '0.00');
        $sample['period_year'] = now()->format('Y');
        $sample['period_month'] = now()->format('m');
        $sample['late_charge_as_of'] = '';
        $sample['effective_due_date'] = '';
        $csv = implode(';', $headers) . "\r\n" . implode(';', array_map(fn ($key) => $sample[$key], $headers)) . "\r\n";
        return response("\xEF\xBB\xBF" . $csv, 200, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename=sgk-tahakkuk-sablonu.csv',
        ]);
    }

    public function document($id)
    {
        $this->authorizeModule();
        $record = $this->scope(Accrual::class)->findOrFail($id);
        abort_unless($record->document_path && Storage::disk('public')->exists($record->document_path), 404);
        return Storage::disk('public')->download($record->document_path, $record->document_name ?: basename($record->document_path));
    }

    public function importForm()
    {
        $this->authorizeModule();
        $workplaces = $this->scope(Workplace::class)->orderBy('registration_no')->get();
        return view('sgk_debt::accruals.import', compact('workplaces'));
    }

    public function import(Request $request)
    {
        $this->authorizeModule();
        $branchId = $this->branch();
        $data = $request->validate([
            'workplace_id' => ['required', 'integer', Rule::exists('sgk_workplaces', 'id')->where('branch_id', $branchId)],
            'file' => 'required|file|max:20480|mimes:csv,txt',
        ]);

        $handle = fopen($request->file('file')->getRealPath(), 'r');
        if (!$handle) {
            return back()->withErrors(['file' => 'Dosya okunamadı.']);
        }
        $firstLine = fgets($handle);
        if ($firstLine === false) {
            fclose($handle);
            return back()->withErrors(['file' => 'Dosya boş.']);
        }
        $delimiter = substr_count($firstLine, ';') > substr_count($firstLine, ',') ? ';' : ',';
        rewind($handle);
        $headers = fgetcsv($handle, 0, $delimiter);
        $headers = array_map(fn ($value) => strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', (string) $value))), (array) $headers);

        $required = ['period_year', 'period_month'];
        if (array_diff($required, $headers)) {
            fclose($handle);
            return back()->withErrors(['file' => 'CSV başlıklarında period_year ve period_month bulunmalıdır.']);
        }

        $workplace = $this->scope(Workplace::class)->findOrFail((int) $data['workplace_id']);
        $made = 0;
        $badRows = [];
        $lineNumber = 1;
        while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
            $lineNumber++;
            if (count($row) === 1 && trim((string) $row[0]) === '') {
                continue;
            }
            if (count($row) !== count($headers)) {
                $badRows[] = "Satır {$lineNumber}: sütun sayısı hatalı";
                continue;
            }
            $rowData = array_combine($headers, $row);
            $year = filter_var($rowData['period_year'] ?? null, FILTER_VALIDATE_INT);
            $month = filter_var($rowData['period_month'] ?? null, FILTER_VALIDATE_INT);
            if (!$year || $year < 2000 || $year > 2100 || !$month || $month < 1 || $month > 12) {
                $badRows[] = "Satır {$lineNumber}: yıl veya ay geçersiz";
                continue;
            }

            $amounts = [];
            foreach (self::AMOUNT_FIELDS as $field) {
                $text = trim((string) ($rowData[$field] ?? '0'));
                $text = str_replace(' ', '', $text);
                if (str_contains($text, ',') && str_contains($text, '.')) {
                    $text = str_replace('.', '', $text);
                }
                $text = str_replace(',', '.', $text);
                if ($text === '') {
                    $text = '0';
                }
                if (!is_numeric($text) || (float) $text < 0) {
                    $amounts = [];
                    break;
                }
                $amounts[$field] = (float) $text;
            }
            if (!$amounts) {
                $badRows[] = "Satır {$lineNumber}: tutar sütunlarından biri geçersiz";
                continue;
            }

            $debtOnlyTotal = round($amounts['premium_debt'], 2);
            $lateChargeTotal = round($amounts['premium_late_charge'], 2);

            $accrual = array_merge($amounts, [
                'branch_id' => $branchId,
                'company_id' => $workplace->company_id,
                'site_id' => $workplace->site_id,
                'workplace_id' => $workplace->id,
                'period_year' => $year,
                'period_month' => $month,
                'period' => sprintf('%04d-%02d', $year, $month),
                'late_charge_as_of' => $this->validCsvDate($rowData['late_charge_as_of'] ?? null),
                'effective_due_date' => $this->validCsvDate($rowData['effective_due_date'] ?? null),
                'debt_only_total' => $debtOnlyTotal,
                'late_charge_total' => $lateChargeTotal,
                'principal_amount' => round($debtOnlyTotal + $lateChargeTotal, 2),
                'incentive_amount' => 0,
                'adjustment_amount' => 0,
                'late_cost_estimate' => $lateChargeTotal,
                'paid_amount' => 0,
                'currency' => 'TRY',
                'accrual_type' => 'premium',
                'status' => 'draft',
                'source' => 'import',
                'due_date_verified' => false,
                'description' => 'SGK fiş CSV dosyasından içe aktarıldı.',
                'created_by' => auth()->id(),
            ]);
            Accrual::query()->create($accrual);
            $made++;
        }
        fclose($handle);

        $message = "{$made} taslak SGK fişi içe aktarıldı.";
        if ($badRows) {
            $message .= ' Hatalı satırlar atlandı: ' . implode('; ', array_slice($badRows, 0, 10));
        }
        return redirect()->route('admin.sgk-accruals.index')->with('success', $message);
    }

    private function validCsvDate($value): ?string
    {
        $date = trim((string) $value);
        if ($date === '') {
            return null;
        }
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        return $parsed && $parsed->format('Y-m-d') === $date ? $date : null;
    }

    public function export()
    {
        $this->authorizeModule();
        $records = $this->scope(Accrual::class)->with(['company', 'site', 'workplace'])->orderBy('period', 'desc')->get();
        $headers = [
            'Dönem',
            'Şirket',
            'İşyeri Sicil No',
            'Şantiye',
            'GZ Esas Tarihi',
            'Prim Borcu',
            'Prim GZ',
            'Geçerli Vade',
            'Kalan Bakiye',
            'İşlem Durumu',
        ];
        $filename = 'sgk-tahakkuk-fisleri-' . now()->format('Ymd-His') . '.csv';

        return response()->streamDownload(function () use ($records, $headers): void {
            $output = fopen('php://output', 'w');
            fwrite($output, "\xEF\xBB\xBF");
            fputcsv($output, $headers, ';');
            foreach ($records as $record) {
                $row = [
                    $record->period ?: sprintf('%04d-%02d', $record->period_year, $record->period_month),
                    $record->company?->title,
                    $record->workplace?->registration_no,
                    $record->site?->name,
                    $record->late_charge_as_of?->format('Y-m-d'),
                    $record->premium_debt,
                    $record->premium_late_charge,
                    $record->effective_due_date?->format('Y-m-d'),
                    $record->remaining,
                    $record->status,
                ];
                fputcsv($output, $row, ';');
            }
            fclose($output);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
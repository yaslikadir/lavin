<?php

namespace Modules\SGKDebt\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Modules\SGKDebt\Models\Accrual;
use Modules\SGKDebt\Models\Payment;

class PaymentController extends BaseController
{
    public const PAYERS = [
        'Rıdvan Sunar',
        'Ferhat Sunar',
        'Fecri Dalgıç',
    ];

    public function index()
    {
        $this->authorizeModule();
        $records = Payment::query()
            ->where('branch_id', $this->branch())
            ->with(['accrual.company', 'accrual.workplace'])
            ->latest('payment_date')
            ->latest('id')
            ->get();

        return view('sgk_debt::payments.index', compact('records'));
    }

    public function receipt($id)
    {
        $this->authorizeModule();
        $payment = Payment::query()->where('branch_id', $this->branch())->findOrFail($id);
        abort_unless($payment->receipt_path && Storage::disk('public')->exists($payment->receipt_path), 404);
        return Storage::disk('public')->download($payment->receipt_path, $payment->receipt_name ?: basename($payment->receipt_path));
    }

    public function store(Request $request, $id)
    {
        $this->authorizeModule();
        $branchId = $this->branch();
        $data = $request->validate([
            'payment_date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'paid_by' => ['required', 'string', Rule::in(self::PAYERS)],
            'payment_method' => ['nullable', 'in:bank,online,other'],
            'bank_reference' => ['nullable', 'string', 'max:255'],
            'receipt' => ['nullable', 'file', 'max:20480', 'mimes:pdf,jpg,jpeg,png'],
        ]);
        $file = $request->file('receipt');
        $path = $file?->store('sgk-debt/' . $branchId . '/receipts', 'public');

        DB::transaction(function () use ($id, $branchId, $data, $file, $path): void {
            $accrual = Accrual::query()->where('branch_id', $branchId)->lockForUpdate()->findOrFail($id);
            abort_if(in_array($accrual->status, ['draft', 'pending_approval', 'cancelled'], true), 409, 'Önce tahakkuk onaylanmalı.');

            $remaining = max(0, (float) $accrual->principal_amount
                - (float) $accrual->incentive_amount
                + (float) $accrual->adjustment_amount
                - (float) $accrual->paid_amount);
            $reserved = (float) $accrual->payments()->where('status', 'recorded')->where('allocation_status', 'unconfirmed')->sum('amount');
            abort_if((float) $data['amount'] > $remaining - $reserved + 0.005, 422, 'Ödeme tutarı, bekleyen dekontlar düşüldükten sonraki kullanılabilir bakiyeyi aşıyor.');

            Payment::query()->create([
                'branch_id' => $branchId,
                'accrual_id' => $accrual->id,
                'payment_date' => $data['payment_date'],
                'amount' => $data['amount'],
                'paid_by' => $data['paid_by'],
                'payment_method' => $data['payment_method'] ?? null,
                'bank_reference' => $data['bank_reference'] ?? null,
                'receipt_path' => $path,
                'receipt_name' => $file?->getClientOriginalName(),
                'status' => 'recorded',
                'allocation_status' => 'unconfirmed',
                'recorded_by' => auth()->id(),
            ]);
        });

        return back()->with('success', 'Ödeme kaydedildi; SGK borcuna mahsup doğrulanana kadar bakiye kapanmaz.');
    }

    public function confirmAllocation($id)
    {
        $this->authorizeModule();
        $branchId = $this->branch();

        DB::transaction(function () use ($id, $branchId): void {
            $payment = Payment::query()->where('branch_id', $branchId)->lockForUpdate()->findOrFail($id);
            abort_unless($payment->status === 'recorded' && $payment->allocation_status === 'unconfirmed', 409, 'Yalnızca bekleyen bir ödeme mahsup için doğrulanabilir.');
            $accrual = Accrual::query()->where('branch_id', $branchId)->lockForUpdate()->findOrFail($payment->accrual_id);
            $remaining = max(0, (float) $accrual->principal_amount
                - (float) $accrual->incentive_amount
                + (float) $accrual->adjustment_amount
                - (float) $accrual->paid_amount);
            abort_if((float) $payment->amount > $remaining + 0.005, 409, 'Doğrulanacak tutar güncel kalan borcu aşıyor.');

            $newPaid = (float) $accrual->paid_amount + (float) $payment->amount;
            $effectivePrincipal = max(0, (float) $accrual->principal_amount
                - (float) $accrual->incentive_amount
                + (float) $accrual->adjustment_amount);
            $accrual->update([
                'paid_amount' => $newPaid,
                'status' => $newPaid + 0.005 >= $effectivePrincipal ? 'paid' : 'partial',
                'last_reconciled_at' => now(),
            ]);
            $payment->update(['allocation_status' => 'confirmed', 'confirmed_at' => now()]);
        });

        return back()->with('success', 'Ödemenin SGK borcuna mahsup edildiği doğrulandı; borç bakiyesi güncellendi.');
    }

    public function reverse(Request $request, $id)
    {
        $this->authorizeModule();
        $branchId = $this->branch();
        $data = $request->validate(['reason' => 'required|string|min:10|max:1000']);

        DB::transaction(function () use ($branchId, $id, $data): void {
            $payment = Payment::query()->where('branch_id', $branchId)->lockForUpdate()->findOrFail($id);
            abort_unless($payment->status === 'recorded', 409, 'Yalnızca kayıtlı ödeme için ters kayıt yapılabilir.');
            $accrual = Accrual::query()->where('branch_id', $branchId)->lockForUpdate()->findOrFail($payment->accrual_id);

            if ($payment->allocation_status === 'confirmed') {
                $newPaid = max(0, (float) $accrual->paid_amount - (float) $payment->amount);
                $effectivePrincipal = max(0, (float) $accrual->principal_amount
                    - (float) $accrual->incentive_amount
                    + (float) $accrual->adjustment_amount);
                $accrual->update([
                    'paid_amount' => $newPaid,
                    'status' => $newPaid <= 0 ? 'payable' : ($newPaid + 0.005 >= $effectivePrincipal ? 'paid' : 'partial'),
                ]);
            }

            Payment::query()->create([
                'branch_id' => $branchId,
                'accrual_id' => $accrual->id,
                'payment_date' => today(),
                'amount' => -(float) $payment->amount,
                'paid_by' => $payment->paid_by,
                'payment_method' => 'other',
                'bank_reference' => 'Ters kayıt #' . $payment->id,
                'status' => 'reversal',
                'allocation_status' => 'unconfirmed',
                'reverses_payment_id' => $payment->id,
                'correction_reason' => $data['reason'],
                'recorded_by' => auth()->id(),
            ]);
            $payment->update(['status' => 'reversed', 'correction_reason' => $data['reason']]);
        });

        return back()->with('success', 'Ödeme silinmedi; gerekçeli ters kayıt oluşturuldu.');
    }
}
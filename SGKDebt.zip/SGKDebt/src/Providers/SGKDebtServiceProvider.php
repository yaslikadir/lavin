<?php
namespace Modules\SGKDebt\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class SGKDebtServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'sgk_debt');
        $path = __DIR__ . '/../../routes/web.php';
        if (is_file($path)) {
            Route::middleware(['web', 'auth', 'verified', 'active_user'])
                ->prefix('admin')->name('admin.')
                ->group($path);
        }
    }
}

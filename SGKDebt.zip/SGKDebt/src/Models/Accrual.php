<?php

namespace Modules\SGKDebt\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Accrual extends Model
{
    use SoftDeletes;

    protected $table = 'sgk_accruals';
    protected $guarded = ['id'];

    protected $casts = [
        'period_year' => 'integer',
        'period_month' => 'integer',
        'late_charge_as_of' => 'date',
        'normal_due_date' => 'date',
        'effective_due_date' => 'date',
        'due_date_verified_at' => 'date',
        'accrued_at' => 'date',
        'paid_amount' => 'decimal:2',
        'principal_amount' => 'decimal:2',
        'incentive_amount' => 'decimal:2',
        'adjustment_amount' => 'decimal:2',
        'late_cost_estimate' => 'decimal:2',
        'premium_debt' => 'decimal:2',
        'premium_late_charge' => 'decimal:2',
        'administrative_penalty_debt' => 'decimal:2',
        'administrative_penalty_late_charge' => 'decimal:2',
        'education_contribution_debt' => 'decimal:2',
        'education_contribution_late_charge' => 'decimal:2',
        'special_transaction_tax_debt' => 'decimal:2',
        'special_transaction_tax_late_charge' => 'decimal:2',
        'unemployment_debt' => 'decimal:2',
        'unemployment_late_charge' => 'decimal:2',
        'stamp_tax_debt' => 'decimal:2',
        'frozen_premium_late_debt' => 'decimal:2',
        'frozen_unemployment_debt' => 'decimal:2',
        'frozen_unemployment_late_charge' => 'decimal:2',
        'debt_only_total' => 'decimal:2',
        'late_charge_total' => 'decimal:2',
        'due_date_verified' => 'boolean',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function workplace()
    {
        return $this->belongsTo(Workplace::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    /** Borç ve zam toplamı ödeme sürecinin açılış bakiyesidir. */
    public function getRemainingAttribute(): float
    {
        $calculatedPrincipal = (float) $this->premium_debt + (float) $this->premium_late_charge;
        $baseTotal = $calculatedPrincipal > 0 ? $calculatedPrincipal : (float) $this->principal_amount;

        $total = $baseTotal
            - (float) $this->incentive_amount
            + (float) $this->adjustment_amount;

        return max(0, round($total - (float) $this->paid_amount, 2));
    }

    public function getDisplayDueDateAttribute()
    {
        return $this->effective_due_date ?: $this->normal_due_date;
    }
}
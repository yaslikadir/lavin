<?php
namespace Modules\SGKDebt\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Workplace extends Model { use SoftDeletes; protected $table='sgk_workplaces'; protected $guarded=['id']; public function company(){return $this->belongsTo(Company::class);} public function site(){return $this->belongsTo(Site::class);} public function parent(){return $this->belongsTo(self::class,'parent_workplace_id');} public function children(){return $this->hasMany(self::class,'parent_workplace_id');} public function accruals(){return $this->hasMany(Accrual::class);} }

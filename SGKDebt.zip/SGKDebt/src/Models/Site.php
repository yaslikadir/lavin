<?php
namespace Modules\SGKDebt\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Site extends Model { use SoftDeletes; protected $table='sgk_sites'; protected $guarded=['id']; public function company(){return $this->belongsTo(Company::class);} public function workplaceRecords(){return $this->hasMany(Workplace::class,'site_id');} public function project(){return $this->belongsTo(\Modules\ConstructionProjects\Models\ConstructionProject::class,'construction_project_id');} }

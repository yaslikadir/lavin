<?php
namespace Modules\SGKDebt\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Reminder extends Model { use SoftDeletes; protected $table='sgk_reminders'; protected $guarded=['id']; protected $casts=['scheduled_at'=>'datetime','sent_at'=>'datetime']; public function accrual(){return $this->belongsTo(Accrual::class);} }

<?php
namespace Modules\SGKDebt\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Payment extends Model { use SoftDeletes; protected $table='sgk_payments'; protected $guarded=['id']; protected $casts=['payment_date'=>'date','confirmed_at'=>'datetime','amount'=>'decimal:2']; public function accrual(){return $this->belongsTo(Accrual::class);} public function reversal(){return $this->belongsTo(self::class,'reverses_payment_id');} }

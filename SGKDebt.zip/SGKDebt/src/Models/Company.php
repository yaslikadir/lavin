<?php
namespace Modules\SGKDebt\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Company extends Model { use SoftDeletes; protected $table='sgk_companies'; protected $guarded=['id']; public function sites(){return $this->hasMany(Site::class,'company_id');} public function workplaces(){return $this->hasMany(Workplace::class,'company_id');} public function accruals(){return $this->hasMany(Accrual::class,'company_id');} }

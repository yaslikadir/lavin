# SGK Borç ve Prim Takibi Modülü

İnşaat firmaları için şirket → şantiye → SGK işyeri sicili → tahakkuk → ödeme/mahsup izlemesini şube bazında tutan bağımsız Laravel modülüdür. Tek şantiyede birden çok sicil ve alt işveren sicili desteklenir; SGK sicili şantiye kaydına gömülmez.

## İlk sürüm
- Şirket, şantiye ve işyeri sicili kayıtları; opsiyonel mevcut `construction_projects` bağlantısı.
- SGK tahakkuk fişi alanları, paylaşılan örnek PDF'deki sütunlara göre tutulur: dönem yılı/ayı, fiş durumu, gecikme zammı esas tarihi; prim, idari para cezası, eğitime katkı payı, özel işlem vergisi, işsizlik borcu ve bunların fişte yer alan gecikme zamları; damga vergisi; donmuş prim/GZEPK kalemleri; sadece borçlar toplamı ve gecikme zammı toplamı.
- Normal vade ve geçerli son vade ayrı alanlarda; vade doğrulama işareti ve doğrulama tarihi.
- CSV dosyasından taslak tahakkuk içe aktarma ve CSV dışa aktarma.
- Onaya gönderme/onay akışı; tahakkuk ve ödemeler şube kapsamlı.
- Manuel/ kısmi ödeme, dekont ekleme, banka referansı ve ödeme kaydı ile SGK mahsup onayının ayrılması.
- Ödeme silinmez: gerekçeli ters kayıtla düzeltilir.
- Dashboard: açık ana para, yaklaşan vade, gecikmiş borç, doğrulanmamış vade, onay kuyruğu, şantiye bazlı bakiye.

## Kurulum
1. ZIP'i proje `modules/SGKDebt` klasörüne çıkarın (arşiv kökü `SGKDebt/`).
2. Modül yöneticisinin manifest `provider` alanını okuduğunu doğrulayın. Provider: `Modules\\SGKDebt\\Providers\\SGKDebtServiceProvider`.
3. Yeni tablo kurulumu için migration'ları uygulamanızın migration politikasına göre çalıştırın. `sgk_accruals` tablosu zaten mevcutsa yalnızca yeni alanları ekleyen `2026_11_03_000002_add_statement_fields_to_sgk_accruals.php` migration'ını çalıştırın; mevcut tablo varken ilk kurulum migration'ını tekrar çalıştırmayın.
4. `php artisan optimize:clear` çalıştırıp route'ları doğrulayın: `php artisan route:list --path=sgk-`.
5. Menünüzde `admin.sgk-debt.dashboard` rotasına bağlayın. Middleware `check.module:sgk_debt` kullanır; kullanıcı/rol yetki sisteminizde aynı modül anahtarıyla erişim verin.

Bu modül `active_branch_id` yoksa 403 döndürür; şube seçme/provider mantığını değiştirmez. CSV içe aktarımı seçili şubedeki bir işyeri siciline bağlanır ve satırları taslak açar.

## Veri ve mevzuat güvenliği
Vade formu normal ve geçerli son vadeyi ayrı saklar; son tarih otomatik doğrulanmış gibi gösterilmez. CSV'den gelen vade doğrulanmamış kalır. Mevzuat oranları veya gecikme maliyeti formülü kod içine sabitlenmemiştir. Gecikme maliyeti alanı yalnızca doğrulanmış dış hesaplamanın kaydı içindir; sistem resmi SGK hesabı iddiasında bulunmaz.

Tahakkuk ana kaydı ödemeler oluştuktan sonra düzenlenemez/silinemez. Ödeme kaydı saklanır; düzeltme gerekçeli ters ödeme kaydı oluşturur. Dekont, tek başına borcun SGK'ya mahsup kanıtı sayılmaz. Mahsup ayrıca kullanıcı tarafından doğrulanır.

İlk sürümde yaklaşan/ geciken vade uyarıları dashboard üzerinde gösterilir. Günlük e-posta gönderimi ve Laravel database notification job/scheduler entegrasyonu henüz etkin değildir; alıcı/rol kuralları ve e-posta altyapısı projede netleştirildikten sonra ayrı fazda bağlanmalıdır. Bu modül kendiliğinden e-posta kuyruğu çalıştırmaz. SGK entegrasyonu veya resmî portala otomatik erişim eklenmemiştir.

## Şema
`sgk_companies`, `sgk_sites`, `sgk_workplaces`, `sgk_accruals`, `sgk_payments`, `sgk_reminders`. PDF fişindeki her borç ve gecikme kalemi ayrı ondalık sütunda saklanır. Ödeme akışı mevcut uyumluluk için fişteki `Sadece Borçlar Toplamı + Gecikme Zammı Toplamı` değerini tahakkukun açılış bakiyesi olarak kullanır.

## Ana dashboard kartları
Ana inşaat dashboard'u modül yetkisi varsa seçili şube için alınan çek, verilen çek, alınan borç (ödenecek bakiye) ve verilen borç/alacak (tahsil edilecek bakiye) kartlarını gösterir. Borç/alacak toplamları yalnızca açık/kısmi, TRY/TL kayıtların kalan bakiyesidir; ödemeler, silinmemiş ödeme kayıtları üzerinden düşülür.

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sgk_payments', function (Blueprint $table) {
            if (!Schema::hasColumn('sgk_payments', 'paid_by')) {
                $table->string('paid_by', 100)->nullable()->after('payment_method');
            }
        });
    }

    public function down(): void
    {
        Schema::table('sgk_payments', function (Blueprint $table) {
            if (Schema::hasColumn('sgk_payments', 'paid_by')) {
                $table->dropColumn('paid_by');
            }
        });
    }
};
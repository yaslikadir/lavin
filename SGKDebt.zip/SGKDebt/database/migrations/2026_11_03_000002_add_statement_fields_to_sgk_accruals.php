<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const AMOUNTS = [
        'premium_debt',
        'premium_late_charge',
        'administrative_penalty_debt',
        'administrative_penalty_late_charge',
        'education_contribution_debt',
        'education_contribution_late_charge',
        'special_transaction_tax_debt',
        'special_transaction_tax_late_charge',
        'unemployment_debt',
        'unemployment_late_charge',
        'stamp_tax_debt',
        'frozen_premium_late_debt',
        'frozen_unemployment_debt',
        'frozen_unemployment_late_charge',
        'debt_only_total',
        'late_charge_total',
    ];

    public function up(): void
    {
        if (!Schema::hasTable('sgk_accruals')) {
            return;
        }

        foreach (self::AMOUNTS as $column) {
            if (!Schema::hasColumn('sgk_accruals', $column)) {
                Schema::table('sgk_accruals', function (Blueprint $table) use ($column): void {
                    $table->decimal($column, 15, 2)->default(0);
                });
            }
        }

        if (!Schema::hasColumn('sgk_accruals', 'period_year')) {
            Schema::table('sgk_accruals', function (Blueprint $table): void {
                $table->unsignedSmallInteger('period_year')->nullable();
            });
        }
        if (!Schema::hasColumn('sgk_accruals', 'period_month')) {
            Schema::table('sgk_accruals', function (Blueprint $table): void {
                $table->unsignedTinyInteger('period_month')->nullable();
            });
        }
        if (!Schema::hasColumn('sgk_accruals', 'statement_status')) {
            Schema::table('sgk_accruals', function (Blueprint $table): void {
                $table->string('statement_status', 40)->nullable();
            });
        }
        if (!Schema::hasColumn('sgk_accruals', 'late_charge_as_of')) {
            Schema::table('sgk_accruals', function (Blueprint $table): void {
                $table->date('late_charge_as_of')->nullable();
            });
        }

        if (Schema::hasColumn('sgk_accruals', 'period')) {
            DB::table('sgk_accruals')
                ->whereNull('period_year')
                ->orWhereNull('period_month')
                ->orderBy('id')
                ->chunkById(500, function ($records): void {
                    foreach ($records as $record) {
                        if (preg_match('/^(\d{4})-(\d{2})$/', (string) $record->period, $matches)) {
                            DB::table('sgk_accruals')->where('id', $record->id)->update([
                                'period_year' => (int) $matches[1],
                                'period_month' => (int) $matches[2],
                            ]);
                        }
                    }
                });
        }
    }

    public function down(): void
    {
        if (!Schema::hasTable('sgk_accruals')) {
            return;
        }
        foreach (array_merge(self::AMOUNTS, ['period_year', 'period_month', 'statement_status', 'late_charge_as_of']) as $column) {
            if (Schema::hasColumn('sgk_accruals', $column)) {
                Schema::table('sgk_accruals', function (Blueprint $table) use ($column): void {
                    $table->dropColumn($column);
                });
            }
        }
    }
};

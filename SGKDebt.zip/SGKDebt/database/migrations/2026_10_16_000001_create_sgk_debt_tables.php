<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('sgk_companies', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->string('code'); $t->string('title');
            $t->string('tax_number')->nullable(); $t->string('tax_office')->nullable(); $t->string('email')->nullable();
            $t->string('phone')->nullable(); $t->text('address')->nullable(); $t->unsignedBigInteger('accountant_user_id')->nullable();
            $t->string('status')->default('active'); $t->text('notes')->nullable(); $t->timestamps(); $t->softDeletes();
            $t->unique(['branch_id','code'],'sgk_companies_branch_code_uq');
        });
        Schema::create('sgk_sites', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->unsignedBigInteger('company_id');
            $t->unsignedBigInteger('construction_project_id')->nullable(); $t->string('code'); $t->string('name');
            $t->text('address')->nullable(); $t->string('city')->nullable(); $t->string('district')->nullable();
            $t->date('planned_start')->nullable(); $t->date('planned_end')->nullable(); $t->string('site_manager')->nullable();
            $t->string('status')->default('active'); $t->text('notes')->nullable(); $t->timestamps(); $t->softDeletes();
            $t->unique(['branch_id','company_id','code'],'sgk_sites_branch_company_code_uq');
            $t->index(['branch_id','construction_project_id'],'sgk_sites_project_idx');
        });
        Schema::create('sgk_workplaces', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->unsignedBigInteger('company_id');
            $t->unsignedBigInteger('site_id')->nullable(); $t->unsignedBigInteger('parent_workplace_id')->nullable();
            $t->string('registration_no'); $t->string('unit_name')->nullable(); $t->string('workplace_type')->default('construction');
            $t->string('employer_type')->default('main'); $t->string('responsible_name')->nullable();
            $t->unsignedBigInteger('accountant_user_id')->nullable(); $t->date('opened_at')->nullable(); $t->date('closed_at')->nullable();
            $t->string('status')->default('active'); $t->text('notes')->nullable(); $t->timestamps(); $t->softDeletes();
            $t->unique(['branch_id','registration_no'],'sgk_workplaces_branch_registration_uq');
        });
        Schema::create('sgk_accruals', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->unsignedBigInteger('company_id');
            $t->unsignedBigInteger('site_id')->nullable(); $t->unsignedBigInteger('workplace_id');
            $t->string('period',7); $t->string('accrual_type'); $t->string('accrual_no')->nullable();
            $t->date('accrued_at')->nullable(); $t->date('normal_due_date')->nullable(); $t->date('effective_due_date')->nullable();
            $t->boolean('due_date_verified')->default(false); $t->date('due_date_verified_at')->nullable();
            $t->decimal('principal_amount',15,2)->default(0); $t->decimal('incentive_amount',15,2)->default(0);
            $t->decimal('adjustment_amount',15,2)->default(0); $t->decimal('paid_amount',15,2)->default(0);
            $t->decimal('late_cost_estimate',15,2)->nullable(); $t->string('currency',3)->default('TRY');
            $t->string('status')->default('draft'); $t->string('source')->default('manual'); $t->string('external_reference')->nullable();
            $t->text('description')->nullable(); $t->string('document_path')->nullable(); $t->string('document_name')->nullable();
            $t->unsignedBigInteger('created_by')->nullable(); $t->unsignedBigInteger('approved_by')->nullable(); $t->dateTime('approved_at')->nullable();
            $t->dateTime('last_reconciled_at')->nullable(); $t->timestamps(); $t->softDeletes();
            $t->index(['branch_id','effective_due_date','status'],'sgk_accruals_due_idx');
            $t->index(['branch_id','workplace_id','period'],'sgk_accruals_period_idx');
        });
        Schema::create('sgk_payments', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->unsignedBigInteger('accrual_id');
            $t->date('payment_date'); $t->decimal('amount',15,2); $t->string('payment_method')->nullable();
            $t->string('bank_reference')->nullable(); $t->string('receipt_path')->nullable(); $t->string('receipt_name')->nullable();
            $t->string('status')->default('recorded'); $t->string('allocation_status')->default('unconfirmed');
            $t->unsignedBigInteger('reverses_payment_id')->nullable(); $t->text('correction_reason')->nullable();
            $t->unsignedBigInteger('recorded_by')->nullable(); $t->dateTime('confirmed_at')->nullable();
            $t->timestamps(); $t->softDeletes(); $t->index(['branch_id','payment_date'],'sgk_payments_date_idx');
        });
        Schema::create('sgk_reminders', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('branch_id')->index(); $t->unsignedBigInteger('accrual_id')->nullable();
            $t->string('channel')->default('in_app'); $t->string('recipient')->nullable(); $t->string('title'); $t->text('message');
            $t->dateTime('scheduled_at'); $t->dateTime('sent_at')->nullable(); $t->string('status')->default('pending');
            $t->text('error_message')->nullable(); $t->timestamps(); $t->softDeletes();
            $t->index(['branch_id','scheduled_at','status'],'sgk_reminders_due_idx');
        });
    }
    public function down(): void {
        Schema::dropIfExists('sgk_reminders'); Schema::dropIfExists('sgk_payments'); Schema::dropIfExists('sgk_accruals');
        Schema::dropIfExists('sgk_workplaces'); Schema::dropIfExists('sgk_sites'); Schema::dropIfExists('sgk_companies');
    }
};

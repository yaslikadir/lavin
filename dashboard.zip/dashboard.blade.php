@extends('layouts.admin')

@section('title', 'İnşaat Operasyon Merkezi')

@push('css')
<style>
    .construction-dashboard { --cd-ink:#14253d; --cd-muted:#718096; --cd-line:#e8edf4; color:var(--cd-ink); }
    .cd-hero { position:relative; overflow:hidden; border:0; border-radius:1.25rem; color:#fff; background:linear-gradient(118deg,#102a43 0%,#155e75 52%,#168aad 100%); box-shadow:0 18px 45px rgba(15,54,82,.18); }
    .cd-hero:before,.cd-hero:after { content:""; position:absolute; border:1px solid rgba(255,255,255,.12); border-radius:50%; pointer-events:none; }
    .cd-hero:before { width:390px;height:390px;right:-115px;top:-210px; }
    .cd-hero:after { width:270px;height:270px;right:36px;bottom:-215px; }
    .cd-hero-content { position:relative; z-index:1; }
    .cd-eyebrow { display:inline-flex;align-items:center;gap:.5rem;padding:.4rem .7rem;border:1px solid rgba(255,255,255,.2);border-radius:999px;background:rgba(255,255,255,.1);font-size:.78rem;letter-spacing:.04em; }
    .cd-hero h1 { font-weight:750;letter-spacing:-.035em; }
    .cd-hero p { max-width:690px;color:rgba(255,255,255,.78); }
    .cd-hero .btn-light { color:#12334a;font-weight:700; }
    .cd-quick { background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff; }
    .cd-quick:hover { color:#102a43;background:#fff; }
    .cd-filter-bar { border:1px solid var(--cd-line);border-radius:1rem;background:#fff;box-shadow:0 6px 20px rgba(24,39,75,.04); }
    .cd-metric { height:100%;border:1px solid var(--cd-line);border-radius:1rem;background:#fff;box-shadow:0 6px 20px rgba(24,39,75,.045);transition:transform .18s ease,box-shadow .18s ease; }
    .cd-metric:hover { transform:translateY(-3px);box-shadow:0 12px 28px rgba(24,39,75,.09); }
    .cd-metric-top { display:flex;align-items:flex-start;justify-content:space-between;gap:1rem; }
    .cd-metric-label { color:var(--cd-muted);font-size:.76rem;font-weight:750;letter-spacing:.065em;text-transform:uppercase; }
    .cd-metric-value { margin-top:.55rem;color:var(--cd-ink);font-size:1.55rem;font-weight:760;line-height:1.1;letter-spacing:-.035em; }
    .cd-metric-note { margin-top:.55rem;color:var(--cd-muted);font-size:.78rem; }
    .cd-icon { display:grid;place-items:center;width:44px;height:44px;flex:none;border-radius:14px;font-size:1.1rem; }
    .cd-blue { color:#1769aa;background:#e8f3ff; }
    .cd-teal { color:#087e8b;background:#e4f7f7; }
    .cd-green { color:#23864b;background:#e9f8ef; }
    .cd-orange { color:#c56b08;background:#fff3df; }
    .cd-red { color:#c43f52;background:#ffebef; }
    .cd-purple { color:#7551b8;background:#f1eaff; }
    .cd-panel { height:100%;border:1px solid var(--cd-line);border-radius:1rem;background:#fff;box-shadow:0 6px 20px rgba(24,39,75,.04); }
    .cd-panel-head { display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;padding:1.15rem 1.25rem;border-bottom:1px solid #f0f3f7; }
    .cd-panel-title { margin:0;font-size:1rem;font-weight:750; }
    .cd-panel-subtitle { margin-top:.2rem;color:var(--cd-muted);font-size:.78rem; }
    .cd-panel-body { padding:1.1rem 1.25rem; }
    .cd-table { margin:0; }
    .cd-table th { padding:.7rem .75rem;color:#76859a;background:#f8fafc;font-size:.69rem;font-weight:750;letter-spacing:.055em;text-transform:uppercase;white-space:nowrap; }
    .cd-table td { padding:.78rem .75rem;color:#334155;font-size:.82rem;vertical-align:middle; }
    .cd-table tbody tr:last-child td { border-bottom:0; }
    .cd-tag { display:inline-flex;align-items:center;padding:.28rem .55rem;border-radius:999px;font-size:.7rem;font-weight:700;white-space:nowrap; }
    .cd-tag-blue { color:#1769aa;background:#e8f3ff; }
    .cd-tag-green { color:#23864b;background:#e9f8ef; }
    .cd-tag-orange { color:#a85d06;background:#fff3df; }
    .cd-tag-red { color:#b83247;background:#ffebef; }
    .cd-tag-gray { color:#5f6c7b;background:#eef2f6; }
    .cd-progress { height:7px;border-radius:99px;background:#edf1f6; }
    .cd-progress .progress-bar { border-radius:99px;background:linear-gradient(90deg,#168aad,#35b6a5); }
    .cd-empty { padding:1.5rem .75rem!important;color:#94a3b8!important;text-align:center; }
    .cd-alert { border:0;border-radius:1rem; }
    .cd-link { color:#1769aa;text-decoration:none;font-size:.8rem;font-weight:700;white-space:nowrap; }
    .cd-link:hover { color:#0d4d82; }
    .cd-project-name { color:var(--cd-ink);font-weight:700; }
    .cd-muted { color:var(--cd-muted); }
    .cd-quick-grid .btn { min-height:42px;border-radius:.75rem;font-weight:650; }
    .cd-payer-card { border-left:4px solid #1769aa; }
    .cd-payer-split { display:grid; grid-template-columns:repeat(2,1fr); gap:.4rem; margin-top:.75rem; padding-top:.65rem; border-top:1px dashed var(--cd-line); }
    .cd-payer-pill { background:#f8fafc; border:1px solid #edf2f7; border-radius:.5rem; padding:.3rem .5rem; font-size:.73rem; display:flex; justify-content:space-between; align-items:center; }
    .cd-check-subbox { margin-top:.65rem; padding-top:.55rem; border-top:1px dashed var(--cd-line); font-size:.75rem; }
    .due-warning-pill { background:#fff5f5;color:#dc3545;border:1px solid #f5c2c7;padding:2px 7px;border-radius:6px;font-size:.72rem;font-weight:700;display:inline-block; }
    @media (max-width:767.98px) {
        .cd-hero { border-radius:1rem; }
        .cd-hero h1 { font-size:1.55rem; }
        .cd-metric-value { font-size:1.35rem; }
        .cd-panel-head,.cd-panel-body { padding:1rem; }
    }
</style>
@endpush

@section('content')
@php
    $projectStatusLabels = [
        'draft' => 'Taslak',
        'planned' => 'Planlandı',
        'active' => 'Devam ediyor',
        'on_hold' => 'Beklemede',
        'completed' => 'Tamamlandı',
        'cancelled' => 'İptal',
    ];
    $priorityLabels = [
        'low' => 'Düşük',
        'normal' => 'Normal',
        'high' => 'Yüksek',
        'urgent' => 'Acil',
    ];
    $months = [
        1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
        5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
        9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık',
    ];
    $payersOptions = ['Ferhat Sunar', 'Rıdvan Sunar', 'Fecri Dalgıç'];
    $payerBorderColors = [
        'Ferhat Sunar' => '#0d6efd',
        'Rıdvan Sunar' => '#198754',
        'Fecri Dalgıç' => '#6f42c1',
    ];

    $yearsOptions = $yearsList ?? range((int) date('Y') + 1, (int) date('Y') - 3);
    $filterProjects = $filterProjectsList ?? collect();
    $payerCards = $payerStats ?? [];
    $bankOverviewList = $bankAccountsOverview ?? collect();
    $periodText = $periodLabel ?? 'Tüm Dönemler';
    $today = \Carbon\Carbon::today();

    $hasCreateProject = $access['projects'] && \Illuminate\Support\Facades\Route::has('admin.construction-projects.create');
    $hasCreateFinance = $access['finance'] && \Illuminate\Support\Facades\Route::has('admin.project-finance-entries.create');
    $hasFinanceReport = $access['finance'] && \Illuminate\Support\Facades\Route::has('admin.project-finance-entries.report');
    $hasCreateUnit = $access['residential'] && \Illuminate\Support\Facades\Route::has('admin.estate-units.create');
    $hasCreateBankTx = $access['banking'] && \Illuminate\Support\Facades\Route::has('admin.bank-transactions.create');
    $hasCreateCheck = $access['checks'] && \Illuminate\Support\Facades\Route::has('admin.checks.create');

    $hasIndexProject = \Illuminate\Support\Facades\Route::has('admin.construction-projects.index');
    $hasIndexTask = \Illuminate\Support\Facades\Route::has('admin.construction-project-tasks.index');
    $hasIndexFinance = \Illuminate\Support\Facades\Route::has('admin.project-finance-entries.index');
    $hasIndexBankAcc = \Illuminate\Support\Facades\Route::has('admin.bank-accounts.index');
    $hasShowBankAcc = \Illuminate\Support\Facades\Route::has('admin.bank-accounts.show');
    $hasIndexLoanInst = \Illuminate\Support\Facades\Route::has('admin.bank-loan-installments.index');
    $hasIndexCheck = \Illuminate\Support\Facades\Route::has('admin.checks.index');
    $hasShowCheck = \Illuminate\Support\Facades\Route::has('admin.checks.show');
    $hasDebtTrackingIndex = \Illuminate\Support\Facades\Route::has('admin.debt-tracking.index');
    $hasSgkDashboard = \Illuminate\Support\Facades\Route::has('admin.sgk-accruals.index');
    $hasIndexUnit = \Illuminate\Support\Facades\Route::has('admin.estate-units.index');

    $hasActiveFilter = request()->filled('year')
        || request()->filled('month')
        || request()->filled('project_id')
        || request()->filled('project_status')
        || request()->filled('payer_name')
        || request()->filled('start_date')
        || request()->filled('end_date');

    $isProjectsEmpty = $projects->isEmpty();
    $isTasksEmpty = $tasks->isEmpty();
    $isLoansEmpty = $loanInstallments->isEmpty();
    $isChecksEmpty = $checks->isEmpty();
    $isBanksEmpty = $bankOverviewList->isEmpty();
    $isRecentFinanceEmpty = $recentFinance->isEmpty();
@endphp

<div class="container-fluid px-3 px-lg-4 py-4 construction-dashboard">
    <!-- Hero Üst Alan -->
    <div class="cd-hero p-4 p-lg-5 mb-4">
        <div class="cd-hero-content">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
                <span class="cd-eyebrow"><i data-feather="hard-hat" style="width:15px;height:15px"></i> İNŞAAT OPERASYON MERKEZİ</span>
                <div class="d-flex flex-wrap gap-2">
                    <span class="cd-eyebrow"><i data-feather="calendar" style="width:15px;height:15px"></i> Dönem: {{ $periodText }}</span>
                    <span class="cd-eyebrow"><i data-feather="git-branch" style="width:15px;height:15px"></i> {{ $branchName }}</span>
                </div>
            </div>
            <div class="row align-items-end g-4">
                <div class="col-lg-7">
                    <h1 class="mb-2">Merhaba, {{ auth()->user()->name ?? 'Yönetici' }}</h1>
                    <p class="mb-0">Projelerin ilerlemesini, nakit akışını, kişi bazlı ödemeleri (Ferhat / Rıdvan / Fecri), SGK tahakkuklarını, banka röntgenlerini ve çek vadelerini tek merkezden yönetin.</p>
                    <div class="small mt-3" style="color:rgba(255,255,255,.72)">{{ now()->translatedFormat('l, d F Y') }} <span class="mx-2">·</span> Son güncelleme {{ now()->format('H:i') }}</div>
                </div>
                <div class="col-lg-5">
                    <div class="d-flex flex-wrap justify-content-lg-end gap-2 cd-quick-grid">
                        @if($hasCreateProject)
                            <a class="btn btn-light" href="{{ route('admin.construction-projects.create') }}"><i data-feather="plus" class="me-1" style="width:15px;height:15px"></i> Yeni proje</a>
                        @endif
                        @if($hasCreateFinance)
                            <a class="btn cd-quick" href="{{ route('admin.project-finance-entries.create') }}"><i data-feather="trending-up" class="me-1" style="width:15px;height:15px"></i> Finans kaydı</a>
                        @endif
                        @if($hasFinanceReport)
                            <a class="btn cd-quick" href="{{ route('admin.project-finance-entries.report', request()->query()) }}"><i data-feather="bar-chart-2" class="me-1" style="width:15px;height:15px"></i> Gelir-Gider Raporu</a>
                        @endif
                        @if($hasSgkDashboard)
                            <a class="btn cd-quick" href="{{ route('admin.sgk-accruals.index') }}"><i data-feather="shield" class="me-1" style="width:15px;height:15px"></i> SGK Tahakkuk</a>
                        @endif
                        @if($hasCreateCheck)
                            <a class="btn cd-quick" href="{{ route('admin.checks.create') }}"><i data-feather="file-text" class="me-1" style="width:15px;height:15px"></i> Çek kaydı</a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ÜST FİLTRE BARI -->
    <div class="cd-filter-bar p-3 p-lg-4 mb-4">
        <form method="GET" action="{{ url()->current() }}">
            <div class="row g-2 align-items-end">
                <div class="col-6 col-md-2 col-xl-1">
                    <label class="form-label small fw-bold text-secondary mb-1">Yıl</label>
                    <select name="year" class="form-select form-select-sm">
                        <option value="">Tümü</option>
                        @foreach($yearsOptions as $yr)
                            <option value="{{ $yr }}" {{ (string) request('year') === (string) $yr ? 'selected' : '' }}>{{ $yr }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-2 col-xl-1">
                    <label class="form-label small fw-bold text-secondary mb-1">Ay</label>
                    <select name="month" class="form-select form-select-sm">
                        <option value="">Tümü</option>
                        @foreach($months as $mNum => $mName)
                            <option value="{{ $mNum }}" {{ (string) request('month') === (string) $mNum ? 'selected' : '' }}>{{ $mName }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-12 col-md-4 col-xl-2">
                    <label class="form-label small fw-bold text-secondary mb-1">Proje</label>
                    <select name="project_id" class="form-select form-select-sm">
                        <option value="">Tüm Projeler</option>
                        @foreach($filterProjects as $fProj)
                            <option value="{{ $fProj->id }}" {{ (string) request('project_id') === (string) $fProj->id ? 'selected' : '' }}>
                                {{ $fProj->project_code }} — {{ $fProj->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-4 col-xl-2">
                    <label class="form-label small fw-bold text-secondary mb-1">Proje Durumu</label>
                    <select name="project_status" class="form-select form-select-sm">
                        <option value="">Tüm Durumlar</option>
                        @foreach($projectStatusLabels as $stKey => $stVal)
                            <option value="{{ $stKey }}" {{ request('project_status') === $stKey ? 'selected' : '' }}>{{ $stVal }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-4 col-xl-2">
                    <label class="form-label small fw-bold text-secondary mb-1">Ödeme Yapan</label>
                    <select name="payer_name" class="form-select form-select-sm">
                        <option value="">Tümü (Ferhat / Rıdvan / Fecri)</option>
                        @foreach($payersOptions as $pOpt)
                            <option value="{{ $pOpt }}" {{ request('payer_name') === $pOpt ? 'selected' : '' }}>{{ $pOpt }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-3 col-xl-1">
                    <label class="form-label small fw-bold text-secondary mb-1">Başlangıç</label>
                    <input type="date" name="start_date" class="form-control form-control-sm" value="{{ request('start_date') }}">
                </div>

                <div class="col-6 col-md-3 col-xl-1">
                    <label class="form-label small fw-bold text-secondary mb-1">Bitiş</label>
                    <input type="date" name="end_date" class="form-control form-control-sm" value="{{ request('end_date') }}">
                </div>

                <div class="col-12 col-md-2 col-xl-2 d-flex gap-2">
                    <button type="submit" class="btn btn-sm btn-primary w-100 fw-semibold">🔍 Uygula</button>
                    @if($hasActiveFilter)
                        <a href="{{ url()->current() }}" class="btn btn-sm btn-outline-secondary" title="Filtreleri Temizle">Sıfırla</a>
                    @endif
                </div>
            </div>
        </form>
    </div>

    @if(!$branchId)
        <div class="alert alert-warning cd-alert mb-4"><strong>Çalışma şubesi seçilmedi.</strong> Şube seçimi yapıldıktan sonra aşağıdaki göstergeler yalnızca seçili şubenin verileriyle doldurulur.</div>
    @endif

    <!-- ANA METRİK KARTLARI (+ SGK ÖZET KARTI) -->
    <div class="row g-3 mb-4">
        @if($access['projects'])
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Aktif Projeler</div>
                            <div class="cd-metric-value">{{ number_format($stats['active_projects']) }}<span class="fs-6 fw-normal cd-muted"> / {{ number_format($stats['total_projects']) }}</span></div>
                            <div class="cd-metric-note">Seçili filtredeki açık proje portföyü</div>
                        </div>
                        <span class="cd-icon cd-blue"><i data-feather="briefcase"></i></span>
                    </div>
                </div>
            </div>
        @endif

        @if($access['finance'])
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Toplam Proje Geliri ({{ $hasActiveFilter ? 'Filtreli' : 'Genel' }})</div>
                            <div class="cd-metric-value text-success">{{ number_format($stats['income_month'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">Tahsil: <strong>{{ number_format($stats['income_paid'], 0, ',', '.') }} ₺</strong> · Bekleyen: {{ number_format($stats['unpaid_income'], 0, ',', '.') }} ₺</div>
                        </div>
                        <span class="cd-icon cd-green"><i data-feather="trending-up"></i></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Toplam Proje Gideri ({{ $hasActiveFilter ? 'Filtreli' : 'Genel' }})</div>
                            <div class="cd-metric-value text-danger">{{ number_format($stats['expense_month'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">Ödenen: <strong>{{ number_format($stats['expense_paid'], 0, ',', '.') }} ₺</strong> · Kalan Borç: {{ number_format($stats['unpaid_expense'], 0, ',', '.') }} ₺</div>
                        </div>
                        <span class="cd-icon cd-orange"><i data-feather="trending-down"></i></span>
                    </div>
                </div>
            </div>
        @endif

        <!-- YENİ: SGK BORÇ & PRİM ÖZET KARTI -->
        <div class="col-6 col-xl-3">
            <a class="text-decoration-none" href="{{ $hasSgkDashboard ? route('admin.sgk-accruals.index') : '#' }}">
                <div class="cd-metric p-3 p-lg-4 h-100">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">SGK Kalan Toplam Borç (Prim + GZ)</div>
                            <div class="cd-metric-value text-danger">{{ number_format((float) $stats['sgk_open_balance'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">
                                Bu Ay Ödenen: <strong class="text-success">{{ number_format((float) $stats['sgk_month_paid'], 0, ',', '.') }} ₺</strong>
                                · 15 günde <strong>{{ number_format($stats['sgk_due_15_count']) }}</strong> vade
                                @if($stats['sgk_overdue_count'] > 0)
                                    · <strong class="text-danger">{{ number_format($stats['sgk_overdue_count']) }} gecikmiş</strong>
                                @endif
                            </div>
                        </div>
                        <span class="cd-icon cd-red"><i data-feather="shield"></i></span>
                    </div>
                </div>
            </a>
        </div>

        @if($access['banking'])
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Mevcut Banka Bakiyesi · TL</div>
                            <div class="cd-metric-value">{{ number_format($stats['bank_balance_try'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">
                                Döviz: <strong>{{ number_format($stats['bank_balance_usd'], 0, ',', '.') }} $</strong> · <strong>{{ number_format($stats['bank_balance_eur'], 0, ',', '.') }} €</strong>
                            </div>
                        </div>
                        <span class="cd-icon cd-blue"><i data-feather="credit-card"></i></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Kredi Vadesi · Yaklaşan & Geciken</div>
                            <div class="cd-metric-value {{ ($stats['loan_overdue'] + $stats['loan_due_14']) > 0 ? 'text-danger' : '' }}">{{ number_format($stats['loan_due_amount'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">14 günde {{ number_format($stats['loan_due_14']) }} taksit · <strong class="text-danger">{{ number_format($stats['loan_overdue']) }} gecikmiş</strong></div>
                        </div>
                        <span class="cd-icon cd-purple"><i data-feather="calendar"></i></span>
                    </div>
                </div>
            </div>
        @endif

        @if($access['checks'])
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Çek Vadesi (≤15 Gün & Geciken)</div>
                            <div class="cd-metric-value {{ ($stats['checks_overdue'] + $stats['checks_due_15']) > 0 ? 'text-warning' : '' }}">{{ number_format($stats['checks_due_amount'], 0, ',', '.') }} <small class="fs-6">₺</small></div>
                            <div class="cd-metric-note">15 günde {{ number_format($stats['checks_due_15']) }} çek · <strong class="text-danger">{{ number_format($stats['checks_overdue']) }} vadesi geçmiş</strong></div>
                        </div>
                        <span class="cd-icon cd-orange"><i data-feather="file-text"></i></span>
                    </div>
                </div>
            </div>
        @endif

        @if($access['residential'])
            <div class="col-6 col-xl-3">
                <div class="cd-metric p-3 p-lg-4">
                    <div class="cd-metric-top">
                        <div>
                            <div class="cd-metric-label">Daire Portföyü</div>
                            <div class="cd-metric-value">{{ number_format($stats['units_available']) }} <small class="fs-6 fw-normal">satışa hazır</small></div>
                            <div class="cd-metric-note">Toplam {{ number_format($stats['units_total']) }} · {{ number_format($stats['units_sold']) }} satılmış</div>
                        </div>
                        <span class="cd-icon cd-teal"><i data-feather="home"></i></span>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <!-- ALINAN ÇEKLER & VERİLEN ÇEKLER (ALTINDA 15 GÜNLÜK VADE DETAYLARI İLE) + BORÇ/ALACAK -->
    @if($access['checks'] || $access['debt_tracking'])
        <div class="row g-3 mb-4">
            @if($access['checks'])
                <div class="col-12 col-md-6 col-xl-3">
                    <a class="text-decoration-none" href="{{ $hasIndexCheck ? route('admin.checks.index', ['direction' => 'received']) : '#' }}">
                        <div class="cd-metric p-3 p-lg-4 h-100">
                            <div class="cd-metric-top">
                                <div>
                                    <div class="cd-metric-label">Alınan Çekler (Portföy)</div>
                                    <div class="cd-metric-value text-success">{{ number_format((float) $stats['checks_received_pending'], 2, ',', '.') }} <small class="fs-6">₺</small></div>
                                    <div class="cd-metric-note">Tahsil edilmemiş müşteri çekleri</div>
                                </div>
                                <span class="cd-icon cd-green"><i data-feather="corner-down-left"></i></span>
                            </div>
                            <div class="cd-check-subbox">
                                <div class="d-flex justify-content-between align-items-center text-dark fw-semibold">
                                    <span>⏳ 15 Gün İçinde ({{ $stats['checks_received_due_15_count'] }} Çek):</span>
                                    <span class="text-success">{{ number_format((float) $stats['checks_received_due_15_amount'], 0, ',', '.') }} ₺</span>
                                </div>
                                @if(!empty($stats['checks_received_due_list']))
                                    <div class="small cd-muted mt-1">
                                        Vadeler: <strong>{{ implode(' · ', $stats['checks_received_due_list']) }}</strong>
                                    </div>
                                @else
                                    <div class="small cd-muted mt-1">15 gün içinde vadesi gelen alınan çek yok.</div>
                                @endif
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-12 col-md-6 col-xl-3">
                    <a class="text-decoration-none" href="{{ $hasIndexCheck ? route('admin.checks.index', ['direction' => 'issued']) : '#' }}">
                        <div class="cd-metric p-3 p-lg-4 h-100">
                            <div class="cd-metric-top">
                                <div>
                                    <div class="cd-metric-label">Verilen (Ödenecek) Çekler</div>
                                    <div class="cd-metric-value text-danger">{{ number_format((float) $stats['checks_issued_pending'], 2, ',', '.') }} <small class="fs-6">₺</small></div>
                                    <div class="cd-metric-note">Ödenmemiş kendi çek yükümlülüğümüz</div>
                                </div>
                                <span class="cd-icon cd-red"><i data-feather="corner-up-right"></i></span>
                            </div>
                            <div class="cd-check-subbox">
                                <div class="d-flex justify-content-between align-items-center text-dark fw-semibold">
                                    <span>⚠️ 15 Gün İçinde ({{ $stats['checks_issued_due_15_count'] }} Çek):</span>
                                    <span class="text-danger">{{ number_format((float) $stats['checks_issued_due_15_amount'], 0, ',', '.') }} ₺</span>
                                </div>
                                @if(!empty($stats['checks_issued_due_list']))
                                    <div class="small cd-muted mt-1">
                                        Vadeler: <strong class="text-danger">{{ implode(' · ', $stats['checks_issued_due_list']) }}</strong>
                                    </div>
                                @else
                                    <div class="small cd-muted mt-1">15 gün içinde ödenecek çek vadesi yok.</div>
                                @endif
                            </div>
                        </div>
                    </a>
                </div>
            @endif

            @if($access['debt_tracking'])
                <div class="col-6 col-xl-3">
                    <a class="text-decoration-none" href="{{ $hasDebtTrackingIndex ? route('admin.debt-tracking.index', ['type' => 'payable']) : '#' }}">
                        <div class="cd-metric p-3 p-lg-4 h-100">
                            <div class="cd-metric-top">
                                <div>
                                    <div class="cd-metric-label">Alınan Borçlar</div>
                                    <div class="cd-metric-value text-success">{{ number_format((float) $stats['debt_taken_outstanding'], 2, ',', '.') }} <small class="fs-6">₺</small></div>
                                    <div class="cd-metric-note">Ödenecek, kalan borç bakiyesi</div>
                                </div>
                                <span class="cd-icon cd-red"><i data-feather="arrow-down-left"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-xl-3">
                    <a class="text-decoration-none" href="{{ $hasDebtTrackingIndex ? route('admin.debt-tracking.index', ['type' => 'receivable']) : '#' }}">
                        <div class="cd-metric p-3 p-lg-4 h-100">
                            <div class="cd-metric-top">
                                <div>
                                    <div class="cd-metric-label">Verilen Borçlar / Alacaklar</div>
                                    <div class="cd-metric-value text-danger">{{ number_format((float) $stats['debt_given_outstanding'], 2, ',', '.') }} <small class="fs-6">₺</small></div>
                                    <div class="cd-metric-note">Tahsil edilecek, kalan alacak bakiyesi</div>
                                </div>
                                <span class="cd-icon cd-green"><i data-feather="arrow-up-right"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
            @endif
        </div>
    @endif

    <!-- KİŞİ BAZLI YAPILAN ÖDEME TUTARLARI (ALTINDA PROJE FİNANS / ÇEK / KREDİ / SGK DAĞILIMI İLE) -->
    @if($access['finance'])
        <div class="row g-3 mb-4">
            @foreach($payerCards as $pKey => $pInfo)
                @php
                    $bColor = $payerBorderColors[$pKey] ?? '#0d6efd';
                    $bd = $pInfo['breakdown'] ?? ['finance' => 0, 'check' => 0, 'loan' => 0, 'sgk' => 0];
                @endphp
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="cd-metric cd-payer-card p-3 p-lg-4" style="border-left-color: {{ $bColor }} !important;">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="cd-metric-label" style="color: {{ $bColor }};">👤 {{ $pInfo['title'] }}</span>
                            <span class="cd-tag cd-tag-gray">{{ $pInfo['count'] }} İşlem</span>
                        </div>
                        <div class="cd-metric-value" style="color: {{ $bColor }};">
                            {{ number_format((float) $pInfo['paid_try'], 0, ',', '.') }} <small class="fs-6">₺</small>
                        </div>

                        <!-- Tek Bakışta Ödeme Kırılımı (Proje, Çek, Kredi, SGK) -->
                        <div class="cd-payer-split">
                            <div class="cd-payer-pill">
                                <span class="text-muted">🏗️ Proje/Cari:</span>
                                <strong class="text-dark">{{ number_format((float) $bd['finance'], 0, ',', '.') }} ₺</strong>
                            </div>
                            <div class="cd-payer-pill">
                                <span class="text-muted">🧾 Çek:</span>
                                <strong class="text-dark">{{ number_format((float) $bd['check'], 0, ',', '.') }} ₺</strong>
                            </div>
                            <div class="cd-payer-pill">
                                <span class="text-muted">🏦 Kredi:</span>
                                <strong class="text-dark">{{ number_format((float) $bd['loan'], 0, ',', '.') }} ₺</strong>
                            </div>
                            <div class="cd-payer-pill">
                                <span class="text-muted">🛡️ SGK:</span>
                                <strong class="text-dark">{{ number_format((float) $bd['sgk'], 0, ',', '.') }} ₺</strong>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

            <div class="col-12 col-md-6 col-xl-3">
                @php
                    $netCashflow = (float) $stats['income_paid'] - (float) $stats['expense_paid'];
                    $netCashColor = $netCashflow >= 0 ? '#198754' : '#dc3545';
                @endphp
                <div class="cd-metric cd-payer-card p-3 p-lg-4" style="border-left-color: {{ $netCashColor }} !important;">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="cd-metric-label">⚖️ Net Nakit Dengesi (Tahsilat - Ödeme)</span>
                        <span class="cd-tag {{ $netCashflow >= 0 ? 'cd-tag-green' : 'cd-tag-red' }}">Fiili Kasa</span>
                    </div>
                    <div class="cd-metric-value" style="color: {{ $netCashColor }};">
                        {{ number_format($netCashflow, 2, ',', '.') }} <small class="fs-6">₺</small>
                    </div>
                    <div class="cd-metric-note d-flex justify-content-between mt-3 pt-2 border-top">
                        <span>Tanımlı Proje Bütçesi:</span>
                        <strong>{{ number_format((float) $stats['budget_total'], 0, ',', '.') }} ₺</strong>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- GRAFİKLER -->
    <div class="row g-3 mb-4">
        @if($access['finance'])
            <div class="col-xl-8">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Proje Gelir-Gider Eğilimi</h2>
                            <div class="cd-panel-subtitle">{{ request('year') ? request('year') . ' Yılı Aylık TRY Gelir ve Gider Dağılımı' : 'Son Altı Ayda Kayda Alınan TRY Gelir ve Giderleri' }}</div>
                        </div>
                        @if($hasIndexFinance)
                            <a class="cd-link" href="{{ route('admin.project-finance-entries.index', request()->query()) }}">Finans kayıtları <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                        @endif
                    </div>
                    <div class="cd-panel-body">
                        <div style="height:290px"><canvas id="cdFinanceChart" aria-label="Proje gelir gider grafiği"></canvas></div>
                    </div>
                </div>
            </div>
        @endif
        @if($access['residential'])
            <div class="col-xl-4">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Daire Satış Durumu</h2>
                            <div class="cd-panel-subtitle">Seçili şubenin daire portföyü</div>
                        </div>
                        @if($hasIndexUnit)
                            <a class="cd-link" href="{{ route('admin.estate-units.index') }}">Daireler <i data-feather="arrow-up-right" style="width:14px;height:15px"></i></a>
                        @endif
                    </div>
                    <div class="cd-panel-body">
                        <div style="height:250px"><canvas id="cdUnitsChart" aria-label="Dairelerin satış durumları grafiği"></canvas></div>
                        <div class="text-center small cd-muted mt-2">Toplam {{ number_format($stats['units_total']) }} bağımsız bölüm</div>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <!-- BANKA HESAPLARI RÖNTGEN ÖZETİ & KREDİ / ÇEK VADE UYARILARI -->
    <div class="row g-3 mb-4">
        @if($access['banking'])
            <div class="col-xl-4">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Banka Hesapları & Mevcut Bakiye</h2>
                            <div class="cd-panel-subtitle">Açılış, güncel bakiye ve tek tıkla banka röntgeni</div>
                        </div>
                        @if($hasIndexBankAcc)
                            <a class="cd-link" href="{{ route('admin.bank-accounts.index') }}">Tüm Bankalar <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                        @endif
                    </div>
                    <div class="table-responsive">
                        <table class="table cd-table">
                            <thead>
                                <tr>
                                    <th>Banka / Hesap</th>
                                    <th class="text-end">Açılış</th>
                                    <th class="text-end">Mevcut</th>
                                    <th>Röntgen</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($bankOverviewList as $bAcc)
                                    @php
                                        $curBal = (float) ($bAcc->current_balance ?? 0);
                                        $balClass = $curBal >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold';
                                    @endphp
                                    <tr>
                                        <td>
                                            <div class="fw-bold">{{ $bAcc->bank_name }}</div>
                                            <div class="small cd-muted">{{ $bAcc->account_name }} ({{ $bAcc->currency }})</div>
                                        </td>
                                        <td class="text-end text-nowrap">{{ number_format((float) $bAcc->opening_balance, 0, ',', '.') }}</td>
                                        <td class="text-end text-nowrap {{ $balClass }}">{{ number_format($curBal, 0, ',', '.') }}</td>
                                        <td class="text-nowrap">
                                            @if($hasShowBankAcc)
                                                <a href="{{ route('admin.bank-accounts.show', $bAcc->id) }}" class="btn btn-sm btn-outline-info py-0 px-2">👁️ Röntgen</a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                @if($isBanksEmpty)
                                    <tr><td colspan="4" class="cd-empty">Henüz banka hesabı bulunmuyor.</td></tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Kredi Ödeme Takvimi & Uyarılar</h2>
                            <div class="cd-panel-subtitle">Vadesine ≤10 gün kalan taksitler kırmızı uyarı verir</div>
                        </div>
                        @if($hasIndexLoanInst)
                            <a class="cd-link" href="{{ route('admin.bank-loan-installments.index') }}">Taksitler <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                        @endif
                    </div>
                    <div class="table-responsive">
                        <table class="table cd-table">
                            <thead>
                                <tr>
                                    <th>Kredi / Banka</th>
                                    <th>Vade & Uyarı</th>
                                    <th class="text-end">Kalan</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($loanInstallments as $loan)
                                    @php
                                        $loanRemaining = max(0, (float) $loan->principal_amount + (float) $loan->interest_amount + (float) $loan->fees_amount - (float) $loan->paid_amount);
                                        $dueObj = \Carbon\Carbon::parse($loan->due_date)->startOfDay();
                                        $daysRem = (int) $today->diffInDays($dueObj, false);
                                    @endphp
                                    <tr>
                                        <td>
                                            <div class="fw-semibold">{{ $loan->loan_name ?? 'Banka Kredisi' }}</div>
                                            <div class="small cd-muted">{{ $loan->bank_name ?? '—' }} · {{ $loan->installment_no }}. Taksit</div>
                                        </td>
                                        <td class="text-nowrap">
                                            <div>{{ $dueObj->format('d.m.Y') }}</div>
                                            @if($daysRem < 0)
                                                <span class="due-warning-pill mt-1">⚠️ {{ abs($daysRem) }} gün gecikti!</span>
                                            @elseif($daysRem <= 10)
                                                <span class="due-warning-pill mt-1">⚠️ {{ $daysRem }} gün kaldı</span>
                                            @else
                                                <span class="small cd-muted">{{ $daysRem }} gün kaldı</span>
                                            @endif
                                        </td>
                                        <td class="text-end text-nowrap fw-bold text-danger">
                                            {{ number_format($loanRemaining, 2, ',', '.') }} {{ $loan->currency ?? 'TRY' }}
                                        </td>
                                    </tr>
                                @endforeach
                                @if($isLoansEmpty)
                                    <tr><td colspan="3" class="cd-empty">Yakın vadeli kredi taksiti yok.</td></tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif

        @if($access['checks'])
            <div class="col-xl-4">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Çek Vade Takibi & Uyarılar</h2>
                            <div class="cd-panel-subtitle">Vadesine ≤15 gün kalan ve geciken çekler</div>
                        </div>
                        @if($hasIndexCheck)
                            <a class="cd-link" href="{{ route('admin.checks.index') }}">Çek Portföyü <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                        @endif
                    </div>
                    <div class="table-responsive">
                        <table class="table cd-table">
                            <thead>
                                <tr>
                                    <th>Çek & Banka</th>
                                    <th>Vade & Uyarı</th>
                                    <th class="text-end">Tutar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($checks as $check)
                                    @php
                                        $cDueObj = \Carbon\Carbon::parse($check->due_date)->startOfDay();
                                        $cDaysRem = (int) $today->diffInDays($cDueObj, false);
                                        $isRec = ($check->direction === 'received');
                                    @endphp
                                    <tr>
                                        <td>
                                            <div class="fw-bold">
                                                @if($hasShowCheck)
                                                    <a href="{{ route('admin.checks.show', $check->id) }}" class="text-decoration-none">#{{ $check->check_no }}</a>
                                                @else
                                                    #{{ $check->check_no }}
                                                @endif
                                                <span class="cd-tag {{ $isRec ? 'cd-tag-green' : 'cd-tag-red' }} ms-1">{{ $isRec ? 'Alınan' : 'Verilen' }}</span>
                                            </div>
                                            <div class="small cd-muted">{{ $check->bank_name }} · {{ $check->related_party ?: ($check->project_name ?: '—') }}</div>
                                        </td>
                                        <td class="text-nowrap">
                                            <div>{{ $cDueObj->format('d.m.Y') }}</div>
                                            @if($cDaysRem < 0)
                                                <span class="due-warning-pill mt-1">⚠️ {{ abs($cDaysRem) }} gün geçti!</span>
                                            @elseif($cDaysRem <= 15)
                                                <span class="due-warning-pill mt-1">⚠️ {{ $cDaysRem }} gün kaldı</span>
                                            @else
                                                <span class="small cd-muted">{{ $cDaysRem }} gün kaldı</span>
                                            @endif
                                        </td>
                                        <td class="text-end text-nowrap fw-bold">
                                            {{ number_format((float) $check->amount, 2, ',', '.') }} {{ $check->currency }}
                                        </td>
                                    </tr>
                                @endforeach
                                @if($isChecksEmpty)
                                    <tr><td colspan="3" class="cd-empty">Yakın vadeli çek bulunmuyor.</td></tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <!-- PROJE PORTFÖYÜ & İŞ PROGRAMI -->
    <div class="row g-3 mb-4">
        @if($access['projects'])
            <div class="col-xl-7">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Proje Portföyü</h2>
                            <div class="cd-panel-subtitle">Seçili filtrelere göre proje ilerleme durumu</div>
                        </div>
                        @if($hasIndexProject)
                            <a class="cd-link" href="{{ route('admin.construction-projects.index') }}">Tüm Projeler <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                        @endif
                    </div>
                    <div class="table-responsive">
                        <table class="table cd-table">
                            <thead>
                                <tr>
                                    <th>Proje</th>
                                    <th>Durum</th>
                                    <th style="min-width:150px">İlerleme</th>
                                    <th>Bitiş</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($projects as $project)
                                    @php
                                        $progress = max(0, min(100, (float) $project->actual_progress));
                                        $pTagClass = $project->status === 'active' ? 'cd-tag-green' : ($project->status === 'on_hold' ? 'cd-tag-orange' : 'cd-tag-blue');
                                        $pEndStr = $project->planned_end ? \Illuminate\Support\Carbon::parse($project->planned_end)->format('d.m.Y') : '—';
                                    @endphp
                                    <tr>
                                        <td>
                                            <div class="cd-project-name">{{ $project->name }}</div>
                                            <div class="small cd-muted">{{ $project->project_code }}{{ $project->client_name ? ' · ' . $project->client_name : '' }}</div>
                                        </td>
                                        <td><span class="cd-tag {{ $pTagClass }}">{{ $projectStatusLabels[$project->status] ?? $project->status }}</span></td>
                                        <td>
                                            <div class="d-flex justify-content-between small mb-1">
                                                <span>{{ number_format($progress, 1, ',', '.') }}%</span>
                                                <span class="cd-muted">Plan %{{ number_format((float) $project->planned_progress, 0, ',', '.') }}</span>
                                            </div>
                                            <div class="progress cd-progress">
                                                <div class="progress-bar" role="progressbar" style="width: {{ $progress }}%"></div>
                                            </div>
                                        </td>
                                        <td class="text-nowrap">{{ $pEndStr }}</td>
                                    </tr>
                                @endforeach
                                @if($isProjectsEmpty)
                                    <tr><td colspan="4" class="cd-empty">Seçili kriterlere uygun proje kaydı yok.</td></tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-xl-5">
                <div class="cd-panel">
                    <div class="cd-panel-head">
                        <div>
                            <h2 class="cd-panel-title">Yaklaşan İş Programı</h2>
                            <div class="cd-panel-subtitle">Vadesi yaklaşan ve geciken iş kalemleri</div>
                        </div>
                        @if($hasIndexTask)
                            <a class="cd-link" href="{{ route('admin.construction-project-tasks.index') }}">İş Kalemleri</a>
                        @endif
                    </div>
                    <div class="table-responsive">
                        <table class="table cd-table">
                            <thead>
                                <tr>
                                    <th>İş Kalemi</th>
                                    <th>Proje</th>
                                    <th>Termin</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($tasks as $task)
                                    @php
                                        $tTagClass = $task->priority === 'urgent' ? 'cd-tag-red' : ($task->priority === 'high' ? 'cd-tag-orange' : 'cd-tag-gray');
                                        $tEndStr = \Illuminate\Support\Carbon::parse($task->planned_end)->format('d.m.Y');
                                    @endphp
                                    <tr>
                                        <td>
                                            <div class="fw-semibold">{{ $task->name }}</div>
                                            <span class="cd-tag {{ $tTagClass }}">{{ $priorityLabels[$task->priority] ?? 'Normal' }}</span>
                                        </td>
                                        <td>{{ $task->project_code ?: ($task->project_name ?: '—') }}</td>
                                        <td class="text-nowrap">{{ $tEndStr }}</td>
                                    </tr>
                                @endforeach
                                @if($isTasksEmpty)
                                    <tr><td colspan="3" class="cd-empty">Yaklaşan iş kalemi yok.</td></tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <!-- SON PROJE FİNANS HAREKETLERİ -->
    @if($access['finance'])
        <div class="cd-panel mb-4">
            <div class="cd-panel-head">
                <div>
                    <h2 class="cd-panel-title">Son Proje Finans Hareketleri ({{ $periodText }})</h2>
                    <div class="cd-panel-subtitle">Gelir ve gider kayıtları; tutar, ödenen, kalan bakiye ve ödeme yapan kişi detayı ile</div>
                </div>
                @if($hasIndexFinance)
                    <a class="cd-link" href="{{ route('admin.project-finance-entries.index', request()->query()) }}">Tüm Hareketler <i data-feather="arrow-up-right" style="width:14px;height:14px"></i></a>
                @endif
            </div>
            <div class="table-responsive">
                <table class="table cd-table">
                    <thead>
                        <tr>
                            <th>Tarih</th>
                            <th>Proje</th>
                            <th>Tür</th>
                            <th>Kategori</th>
                            <th>İlgili Kişi/Firma</th>
                            <th>Ödeme Yapan</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-end">Ödenen</th>
                            <th class="text-end">Kalan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentFinance as $entry)
                            @php
                                $amt = (float) $entry->amount;
                                $paid = (float) ($entry->paid_amount ?? 0);
                                $rem = max(0.0, $amt - $paid);
                                $txStr = \Illuminate\Support\Carbon::parse($entry->transaction_date)->format('d.m.Y');
                                $payerName = $entry->payer_name ?? '—';
                            @endphp
                            <tr>
                                <td class="text-nowrap">{{ $txStr }}</td>
                                <td>
                                    <div class="fw-semibold">{{ $entry->project_name ?: '—' }}</div>
                                    <div class="small cd-muted">{{ $entry->project_code ?: '' }}</div>
                                </td>
                                <td>
                                    <span class="cd-tag {{ $entry->entry_type === 'income' ? 'cd-tag-green' : 'cd-tag-orange' }}">
                                        {{ $entry->entry_type === 'income' ? 'Gelir' : 'Gider' }}
                                    </span>
                                </td>
                                <td>{{ $entry->category }}</td>
                                <td>{{ $entry->counterparty ?: '—' }}</td>
                                <td class="fw-semibold text-dark">{{ $payerName ?: '—' }}</td>
                                <td class="text-end text-nowrap fw-semibold">{{ number_format($amt, 2, ',', '.') }} {{ $entry->currency }}</td>
                                <td class="text-end text-nowrap text-success">{{ number_format($paid, 2, ',', '.') }} {{ $entry->currency }}</td>
                                <td class="text-end text-nowrap {{ $rem > 0 ? 'text-danger fw-bold' : 'text-muted' }}">{{ number_format($rem, 2, ',', '.') }} {{ $entry->currency }}</td>
                            </tr>
                        @endforeach
                        @if($isRecentFinanceEmpty)
                            <tr><td colspan="9" class="cd-empty">Seçili filtrelere uygun proje finans hareketi bulunmuyor.</td></tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    @endif

    <div class="text-center small cd-muted py-2">Gösterge panelindeki tüm özetler seçili şube ve üst filtre kriterlerine göre dinamik hesaplanır.</div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof Chart === 'undefined') return;
    const money = new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 });
    const financeCanvas = document.getElementById('cdFinanceChart');
    if (financeCanvas) {
        new Chart(financeCanvas, {
            type: 'bar',
            data: {
                labels: @json($monthly['labels']),
                datasets: [
                    { label: 'Gelir', data: @json($monthly['income']), backgroundColor: 'rgba(27, 145, 116, .82)', borderRadius: 7, maxBarThickness: 28 },
                    { label: 'Gider', data: @json($monthly['expense']), backgroundColor: 'rgba(232, 145, 57, .78)', borderRadius: 7, maxBarThickness: 28 }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, padding: 18 } },
                    tooltip: { callbacks: { label: function (context) { return context.dataset.label + ': ' + money.format(context.parsed.y || 0); } } }
                },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, grid: { color: '#edf1f6' }, ticks: { callback: function (value) { return new Intl.NumberFormat('tr-TR', { notation: 'compact', maximumFractionDigits: 1 }).format(value) + ' ₺'; } } }
                }
            }
        });
    }
    const unitsCanvas = document.getElementById('cdUnitsChart');
    if (unitsCanvas) {
        new Chart(unitsCanvas, {
            type: 'doughnut',
            data: {
                labels: @json($unitChart['labels']),
                datasets: [{ data: @json($unitChart['values']), backgroundColor: ['#168aad','#f3ad44','#37a66b','#94a3b8'], borderWidth: 0, hoverOffset: 7 }]
            },
            options: {
                responsive: true, maintainAspectRatio: false, cutout: '68%',
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, padding: 16 } } }
            }
        });
    }
});
</script>
@endpush
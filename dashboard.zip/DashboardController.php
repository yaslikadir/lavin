<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public const PAYER_LIST = [
        'Ferhat Sunar',
        'Rıdvan Sunar',
        'Fecri Dalgıç',
    ];

    public function index(Request $request)
    {
        $user = $request->user();
        $rawBranchId = session('active_branch_id');
        $branchId = filter_var($rawBranchId, FILTER_VALIDATE_INT);
        $branchId = $branchId && $branchId > 0 ? (int) $branchId : null;
        $branchName = session('active_branch_name') ?: 'Şube seçilmedi';

        $access = [
            'projects' => $this->canAccessModule($user, 'construction_projects'),
            'finance' => $this->canAccessModule($user, 'project_finance'),
            'banking' => $this->canAccessModule($user, 'banking'),
            'checks' => $this->canAccessModule($user, 'checks'),
            'residential' => $this->canAccessModule($user, 'residential_estate'),
            'debt_tracking' => $this->canAccessModule($user, 'debt-tracking') || $this->canAccessModule($user, 'debt_tracking'),
            'sgk_debt' => $this->canAccessModule($user, 'sgk_debt') || $this->canAccessModule($user, 'sgk-debt'),
        ];

        $now = Carbon::now();
        $today = Carbon::today();
        $next14 = $today->copy()->addDays(14);
        $next15 = $today->copy()->addDays(15);
        $next30 = $today->copy()->addDays(30);

        // --- ÜST FİLTRE PARAMETRELERİ ---
        $filterYear = $request->filled('year') ? (int) $request->input('year') : null;
        $filterMonth = $request->filled('month') ? (int) $request->input('month') : null;
        $filterProjectId = $request->filled('project_id') ? (int) $request->input('project_id') : null;
        $filterProjectStatus = $request->filled('project_status') ? trim((string) $request->input('project_status')) : null;
        $filterPayer = $request->filled('payer_name') ? trim((string) $request->input('payer_name')) : null;
        $filterStartDate = $request->filled('start_date') ? $request->input('start_date') : null;
        $filterEndDate = $request->filled('end_date') ? $request->input('end_date') : null;

        $monthNames = [
            1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
            5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
            9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık',
        ];
        $periodParts = [];
        if ($filterYear) {
            $periodParts[] = $filterYear . ' Yılı';
        }
        if ($filterMonth && isset($monthNames[$filterMonth])) {
            $periodParts[] = $monthNames[$filterMonth] . ' Ayı';
        }
        if ($filterStartDate || $filterEndDate) {
            $s = $filterStartDate ? Carbon::parse($filterStartDate)->format('d.m.Y') : 'Başlangıç';
            $e = $filterEndDate ? Carbon::parse($filterEndDate)->format('d.m.Y') : 'Bugün';
            $periodParts[] = $s . ' - ' . $e;
        }
        $periodLabel = !empty($periodParts) ? implode(' / ', $periodParts) : 'Tüm Dönemler (Genel)';

        $stats = [
            'active_projects' => 0,
            'total_projects' => 0,
            'average_progress' => 0,
            'open_tasks' => 0,
            'blocked_tasks' => 0,
            'tasks_due_7' => 0,
            'tasks_overdue' => 0,
            'income_month' => 0.0,
            'income_paid' => 0.0,
            'expense_month' => 0.0,
            'expense_paid' => 0.0,
            'unpaid_income' => 0.0,
            'unpaid_expense' => 0.0,
            'budget_total' => 0.0,
            'bank_balance_try' => 0.0,
            'bank_balance_usd' => 0.0,
            'bank_balance_eur' => 0.0,
            'loan_due_14' => 0,
            'loan_due_amount' => 0.0,
            'loan_overdue' => 0,
            'checks_due_15' => 0,
            'checks_due_amount' => 0.0,
            'checks_overdue' => 0,
            'checks_received_pending' => 0.0,
            'checks_received_due_15_amount' => 0.0,
            'checks_received_due_15_count' => 0,
            'checks_received_due_list' => [],
            'checks_issued_pending' => 0.0,
            'checks_issued_due_15_amount' => 0.0,
            'checks_issued_due_15_count' => 0,
            'checks_issued_due_list' => [],
            'sgk_open_balance' => 0.0,
            'sgk_overdue_count' => 0,
            'sgk_due_15_count' => 0,
            'sgk_month_paid' => 0.0,
            'debt_taken_outstanding' => 0.0,
            'debt_given_outstanding' => 0.0,
            'units_total' => 0,
            'units_available' => 0,
            'units_sold' => 0,
            'sales_month' => 0,
            'estate_collections_month' => 0.0,
            'installments_overdue' => 0,
            'installments_overdue_amount' => 0.0,
            'open_service_requests' => 0,
            'warranties_expiring' => 0,
            'planned_handovers' => 0,
        ];

        $payerStats = [];
        foreach (self::PAYER_LIST as $pName) {
            $shortName = explode(' ', $pName)[0];
            $payerStats[$pName] = [
                'title' => $shortName . ' Yapılan Ödeme Tutarı',
                'paid_try' => 0.0,
                'total_try' => 0.0,
                'count' => 0,
                'breakdown' => [
                    'finance' => 0.0,
                    'check' => 0.0,
                    'loan' => 0.0,
                    'sgk' => 0.0,
                ],
            ];
        }

        $monthly = [
            'labels' => [],
            'income' => [],
            'expense' => [],
        ];
        $unitChart = [
            'labels' => ['Satışa hazır', 'Rezerve', 'Satıldı', 'Diğer'],
            'values' => [0, 0, 0, 0],
        ];

        $filterProjectsList = collect();
        $yearsList = range((int) $now->format('Y') + 1, (int) $now->format('Y') - 3);
        $projects = collect();
        $tasks = collect();
        $checks = collect();
        $loanInstallments = collect();
        $bankAccountsOverview = collect();
        $overdueInstallments = collect();
        $serviceRequests = collect();
        $recentFinance = collect();

        if ($branchId !== null) {
            $todayString = $today->toDateString();
            $next14String = $next14->toDateString();
            $next15String = $next15->toDateString();
            $next30String = $next30->toDateString();

            $allProjQuery = $this->branchTable('construction_projects', $branchId);
            if ($allProjQuery) {
                $filterProjectsList = (clone $allProjQuery)
                    ->select(['id', 'project_code', 'name', 'status'])
                    ->orderBy('project_code')
                    ->orderBy('name')
                    ->get();
            }

            $matchingProjectIds = null;
            if ($filterProjectId) {
                $matchingProjectIds = [$filterProjectId];
            } elseif ($filterProjectStatus && $allProjQuery) {
                $matchingProjectIds = (clone $allProjQuery)
                    ->where('status', $filterProjectStatus)
                    ->pluck('id')
                    ->toArray();
            }

            // 1. PROJELER & İŞ KALEMLERİ
            if ($access['projects']) {
                $projectQuery = $this->branchTable('construction_projects', $branchId);
                if ($projectQuery) {
                    if ($filterProjectId) {
                        $projectQuery->where('id', $filterProjectId);
                    }
                    if ($filterProjectStatus) {
                        $projectQuery->where('status', $filterProjectStatus);
                    }

                    $stats['total_projects'] = (clone $projectQuery)->count();
                    $stats['active_projects'] = (clone $projectQuery)
                        ->whereIn('status', ['active', 'planned', 'on_hold'])
                        ->count();
                    $stats['average_progress'] = round((float) ((clone $projectQuery)
                        ->whereIn('status', ['active', 'planned', 'on_hold'])
                        ->avg('actual_progress') ?? 0), 1);

                    $projects = (clone $projectQuery)
                        ->select([
                            'id', 'project_code', 'name', 'client_name', 'status',
                            'actual_progress', 'planned_progress', 'planned_end', 'project_manager',
                        ])
                        ->orderByRaw("CASE WHEN status = 'active' THEN 0 WHEN status = 'planned' THEN 1 ELSE 2 END")
                        ->orderBy('planned_end')
                        ->limit(8)
                        ->get();
                }

                $taskQuery = $this->branchTable('construction_project_tasks', $branchId);
                if ($taskQuery) {
                    if ($matchingProjectIds !== null) {
                        $taskQuery->whereIn('construction_project_tasks.project_id', $matchingProjectIds ?: [0]);
                    }

                    $stats['open_tasks'] = (clone $taskQuery)
                        ->whereIn('status', ['not_started', 'in_progress', 'blocked'])
                        ->count();
                    $stats['blocked_tasks'] = (clone $taskQuery)
                        ->where('status', 'blocked')
                        ->count();
                    $stats['tasks_due_7'] = (clone $taskQuery)
                        ->whereNotIn('status', ['completed'])
                        ->whereNotNull('planned_end')
                        ->whereBetween('planned_end', [$todayString, $today->copy()->addDays(7)->toDateString()])
                        ->count();
                    $stats['tasks_overdue'] = (clone $taskQuery)
                        ->whereNotIn('status', ['completed'])
                        ->whereNotNull('planned_end')
                        ->where('planned_end', '<', $todayString)
                        ->count();

                    $taskListQuery = (clone $taskQuery)
                        ->whereNotIn('construction_project_tasks.status', ['completed'])
                        ->whereNotNull('construction_project_tasks.planned_end')
                        ->where('construction_project_tasks.planned_end', '<=', $next14String);

                    if (Schema::hasTable('construction_projects')) {
                        $taskListQuery->leftJoin('construction_projects as cp', function ($join) use ($branchId): void {
                            $join->on('cp.id', '=', 'construction_project_tasks.project_id')
                                ->where('cp.branch_id', '=', $branchId);
                            if (Schema::hasColumn('construction_projects', 'deleted_at')) {
                                $join->whereNull('cp.deleted_at');
                            }
                        });
                        $taskListQuery->addSelect('cp.name as project_name', 'cp.project_code as project_code');
                    } else {
                        $taskListQuery->addSelect(DB::raw('NULL AS project_name'), DB::raw('NULL AS project_code'));
                    }

                    $tasks = $taskListQuery
                        ->addSelect(
                            'construction_project_tasks.id',
                            'construction_project_tasks.project_id',
                            'construction_project_tasks.name',
                            'construction_project_tasks.assignee',
                            'construction_project_tasks.planned_end',
                            'construction_project_tasks.priority',
                            'construction_project_tasks.status'
                        )
                        ->orderBy('construction_project_tasks.planned_end')
                        ->limit(8)
                        ->get();
                }
            }

            // 2. PROJE FİNANS & GELİR-GİDER + ÖDEME YAPAN KARTLARI (FİNANS PAYI)
            if ($access['finance']) {
                $financeBaseQuery = $this->branchTable('project_finance_entries', $branchId);
                if ($financeBaseQuery) {
                    $hasPayerColumn = Schema::hasColumn('project_finance_entries', 'payer_name');
                    $hasCategoryColumn = Schema::hasColumn('project_finance_entries', 'category');

                    $filteredFinance = clone $financeBaseQuery;
                    if ($matchingProjectIds !== null) {
                        $filteredFinance->whereIn('project_id', $matchingProjectIds ?: [0]);
                    }
                    if ($filterYear) {
                        $filteredFinance->whereYear('transaction_date', $filterYear);
                    }
                    if ($filterMonth) {
                        $filteredFinance->whereMonth('transaction_date', $filterMonth);
                    }
                    if ($filterStartDate) {
                        $filteredFinance->whereDate('transaction_date', '>=', $filterStartDate);
                    }
                    if ($filterEndDate) {
                        $filteredFinance->whereDate('transaction_date', '<=', $filterEndDate);
                    }
                    if ($filterPayer && $hasPayerColumn) {
                        $filteredFinance->where('payer_name', $filterPayer);
                    }

                    $stats['income_month'] = (float) (clone $filteredFinance)
                        ->where('entry_type', 'income')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->sum('amount');

                    $stats['income_paid'] = (float) (clone $filteredFinance)
                        ->where('entry_type', 'income')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->sum('paid_amount');

                    $stats['expense_month'] = (float) (clone $filteredFinance)
                        ->where('entry_type', 'expense')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->sum('amount');

                    $stats['expense_paid'] = (float) (clone $filteredFinance)
                        ->where('entry_type', 'expense')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->sum('paid_amount');

                    $stats['unpaid_income'] = (float) ((clone $filteredFinance)
                        ->where('entry_type', 'income')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->selectRaw('COALESCE(SUM(CASE WHEN amount > paid_amount THEN amount - paid_amount ELSE 0 END), 0) AS outstanding')
                        ->value('outstanding') ?? 0);

                    $stats['unpaid_expense'] = (float) ((clone $filteredFinance)
                        ->where('entry_type', 'expense')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('payment_status', '!=', 'cancelled')
                        ->selectRaw('COALESCE(SUM(CASE WHEN amount > paid_amount THEN amount - paid_amount ELSE 0 END), 0) AS outstanding')
                        ->value('outstanding') ?? 0);

                    if ($hasPayerColumn) {
                        $payerSelect = ['payer_name', 'amount', 'paid_amount', 'payment_status', 'currency'];
                        if ($hasCategoryColumn) {
                            $payerSelect[] = 'category';
                        }
                        $payerRows = (clone $filteredFinance)
                            ->where('payment_status', '!=', 'cancelled')
                            ->whereNotNull('payer_name')
                            ->where('payer_name', '!=', '')
                            ->select($payerSelect)
                            ->get();

                        foreach ($payerRows as $pRow) {
                            $pName = trim((string) $pRow->payer_name);
                            if (!isset($payerStats[$pName])) {
                                continue;
                            }
                            $amt = (float) $pRow->amount;
                            $paid = (float) $pRow->paid_amount;
                            $effectivePaid = $paid > 0 ? $paid : ($pRow->payment_status === 'paid' ? $amt : 0.0);

                            $catLower = mb_strtolower((string) ($pRow->category ?? ''), 'UTF-8');
                            if (str_contains($catLower, 'kredi')) {
                                $payerStats[$pName]['breakdown']['loan'] += $effectivePaid;
                            } elseif (str_contains($catLower, 'sgk')) {
                                $payerStats[$pName]['breakdown']['sgk'] += $effectivePaid;
                            } elseif (str_contains($catLower, 'çek') || str_contains($catLower, 'cek')) {
                                $payerStats[$pName]['breakdown']['check'] += $effectivePaid;
                            } else {
                                $payerStats[$pName]['breakdown']['finance'] += $effectivePaid;
                            }

                            $payerStats[$pName]['paid_try'] += $effectivePaid;
                            $payerStats[$pName]['total_try'] += $amt;
                            $payerStats[$pName]['count']++;
                        }
                    }

                    $selectCols = [
                        'id', 'project_name', 'project_code', 'entry_type', 'category',
                        'counterparty', 'amount', 'paid_amount', 'currency', 'transaction_date', 'due_date', 'payment_status',
                    ];
                    if ($hasPayerColumn) {
                        $selectCols[] = 'payer_name';
                    }

                    $recentFinance = (clone $filteredFinance)
                        ->select($selectCols)
                        ->where('payment_status', '!=', 'cancelled')
                        ->orderByDesc('transaction_date')
                        ->orderByDesc('id')
                        ->limit(10)
                        ->get();

                    $budgetQuery = $this->branchTable('project_finance_budgets', $branchId);
                    if ($budgetQuery) {
                        if ($matchingProjectIds !== null) {
                            $budgetQuery->whereIn('project_id', $matchingProjectIds ?: [0]);
                        }
                        $stats['budget_total'] = (float) (clone $budgetQuery)
                            ->whereIn('currency', ['TRY', 'TL'])
                            ->sum('budget_amount');
                    }
                }

                if ($filterYear) {
                    for ($m = 1; $m <= 12; $m++) {
                        $mDate = Carbon::createFromDate($filterYear, $m, 1);
                        $monthly['labels'][] = $monthNames[$m];
                        $range = [$mDate->copy()->startOfMonth()->toDateString(), $mDate->copy()->endOfMonth()->toDateString()];

                        $chartQ = $financeBaseQuery ? clone $financeBaseQuery : null;
                        if ($chartQ && $matchingProjectIds !== null) {
                            $chartQ->whereIn('project_id', $matchingProjectIds ?: [0]);
                        }
                        if ($chartQ && $filterPayer && Schema::hasColumn('project_finance_entries', 'payer_name')) {
                            $chartQ->where('payer_name', $filterPayer);
                        }

                        $monthly['income'][] = $chartQ
                            ? (float) (clone $chartQ)->where('entry_type', 'income')->whereIn('currency', ['TRY', 'TL'])->where('payment_status', '!=', 'cancelled')->whereBetween('transaction_date', $range)->sum('amount')
                            : 0.0;
                        $monthly['expense'][] = $chartQ
                            ? (float) (clone $chartQ)->where('entry_type', 'expense')->whereIn('currency', ['TRY', 'TL'])->where('payment_status', '!=', 'cancelled')->whereBetween('transaction_date', $range)->sum('amount')
                            : 0.0;
                    }
                } else {
                    $chartStart = $now->copy()->startOfMonth()->subMonths(5);
                    for ($offset = 0; $offset < 6; $offset++) {
                        $month = $chartStart->copy()->addMonths($offset);
                        $monthly['labels'][] = $month->format('m/Y');
                        $range = [$month->copy()->startOfMonth()->toDateString(), $month->copy()->endOfMonth()->toDateString()];

                        $chartQ = $financeBaseQuery ? clone $financeBaseQuery : null;
                        if ($chartQ && $matchingProjectIds !== null) {
                            $chartQ->whereIn('project_id', $matchingProjectIds ?: [0]);
                        }
                        if ($chartQ && $filterPayer && Schema::hasColumn('project_finance_entries', 'payer_name')) {
                            $chartQ->where('payer_name', $filterPayer);
                        }

                        $monthly['income'][] = $chartQ
                            ? (float) (clone $chartQ)->where('entry_type', 'income')->whereIn('currency', ['TRY', 'TL'])->where('payment_status', '!=', 'cancelled')->whereBetween('transaction_date', $range)->sum('amount')
                            : 0.0;
                        $monthly['expense'][] = $chartQ
                            ? (float) (clone $chartQ)->where('entry_type', 'expense')->whereIn('currency', ['TRY', 'TL'])->where('payment_status', '!=', 'cancelled')->whereBetween('transaction_date', $range)->sum('amount')
                            : 0.0;
                    }
                }
            }

            // 3. BANKA HESAPLARI & KREDİ TAKSİTLERİ (+ KİŞİ BAZLI KREDİ ÖDEMESİ EĞER SÜTUN VARSA)
            if ($access['banking']) {
                $accountsQuery = $this->branchTable('bank_accounts', $branchId);
                $transactionsQuery = $this->branchTable('bank_transactions', $branchId);

                foreach (['TRY' => 'bank_balance_try', 'USD' => 'bank_balance_usd', 'EUR' => 'bank_balance_eur'] as $currCode => $statKey) {
                    $currList = $currCode === 'TRY' ? ['TRY', 'TL'] : [$currCode];
                    $opening = $accountsQuery
                        ? (float) (clone $accountsQuery)->whereIn('currency', $currList)->sum('opening_balance')
                        : 0.0;
                    $movement = 0.0;
                    if ($transactionsQuery) {
                        $txClone = (clone $transactionsQuery)->whereIn('currency', $currList);
                        if ($matchingProjectIds !== null) {
                            $txClone->whereIn('project_id', $matchingProjectIds ?: [0]);
                        }
                        $movement = (float) ($txClone
                            ->selectRaw("COALESCE(SUM(CASE WHEN transaction_type IN ('deposit','transfer_in','interest') THEN amount WHEN transaction_type IN ('withdrawal','transfer_out','fee','loan_payment','other') THEN -amount ELSE 0 END), 0) AS net")
                            ->value('net') ?? 0);
                    }
                    $stats[$statKey] = $opening + $movement;
                }

                if ($accountsQuery) {
                    $rawAccounts = (clone $accountsQuery)->orderBy('bank_name')->limit(6)->get();
                    foreach ($rawAccounts as $acc) {
                        $netMove = 0.0;
                        if ($transactionsQuery) {
                            $netMove = (float) ((clone $transactionsQuery)
                                ->where('bank_account_id', $acc->id)
                                ->selectRaw("COALESCE(SUM(CASE WHEN transaction_type IN ('deposit','transfer_in','interest') THEN amount WHEN transaction_type IN ('withdrawal','transfer_out','fee','loan_payment','other') THEN -amount ELSE 0 END), 0) AS net")
                                ->value('net') ?? 0);
                        }
                        $acc->current_balance = (float) $acc->opening_balance + $netMove;
                        $bankAccountsOverview->push($acc);
                    }
                }

                $loanQuery = $this->branchTable('bank_loan_installments', $branchId);
                if ($loanQuery) {
                    $unpaidLoanQuery = (clone $loanQuery)->where('status', '!=', 'paid');
                    $stats['loan_due_14'] = (clone $unpaidLoanQuery)
                        ->whereBetween('due_date', [$todayString, $next14String])
                        ->count();
                    $stats['loan_overdue'] = (clone $unpaidLoanQuery)
                        ->where('due_date', '<', $todayString)
                        ->count();
                    if (Schema::hasTable('bank_loans')) {
                        $tryLoanDue = DB::table('bank_loan_installments as i')
                            ->join('bank_loans as l', function ($join) use ($branchId): void {
                                $join->on('l.id', '=', 'i.bank_loan_id')->where('l.branch_id', '=', $branchId);
                                if (Schema::hasColumn('bank_loans', 'deleted_at')) {
                                    $join->whereNull('l.deleted_at');
                                }
                            })
                            ->where('i.branch_id', $branchId)
                            ->whereNull('i.deleted_at')
                            ->where('i.status', '!=', 'paid')
                            ->where('i.due_date', '<=', $next14String)
                            ->whereIn('l.currency', ['TRY', 'TL']);
                        $stats['loan_due_amount'] = (float) ($tryLoanDue
                            ->selectRaw('COALESCE(SUM(CASE WHEN i.principal_amount + i.interest_amount + i.fees_amount > i.paid_amount THEN i.principal_amount + i.interest_amount + i.fees_amount - i.paid_amount ELSE 0 END), 0) AS amount_due')
                            ->value('amount_due') ?? 0);
                    }

                    // Eğer kredi taksitlerinde paid_by veya payer_name sütunu varsa kişi kartlarına ekle
                    $loanPayerCol = Schema::hasColumn('bank_loan_installments', 'paid_by')
                        ? 'paid_by'
                        : (Schema::hasColumn('bank_loan_installments', 'payer_name') ? 'payer_name' : null);

                    if ($loanPayerCol) {
                        $paidLoansQ = (clone $loanQuery)->whereNotNull($loanPayerCol)->where($loanPayerCol, '!=', '');
                        if ($filterYear) {
                            $paidLoansQ->whereYear('due_date', $filterYear);
                        }
                        if ($filterMonth) {
                            $paidLoansQ->whereMonth('due_date', $filterMonth);
                        }
                        if ($filterPayer) {
                            $paidLoansQ->where($loanPayerCol, $filterPayer);
                        }
                        foreach ($paidLoansQ->get() as $lRow) {
                            $pName = trim((string) $lRow->{$loanPayerCol});
                            if (!isset($payerStats[$pName])) {
                                continue;
                            }
                            $totalInst = (float) $lRow->principal_amount + (float) $lRow->interest_amount + (float) $lRow->fees_amount;
                            $paidInst = (float) $lRow->paid_amount > 0 ? (float) $lRow->paid_amount : ($lRow->status === 'paid' ? $totalInst : 0.0);
                            if ($paidInst > 0) {
                                $payerStats[$pName]['breakdown']['loan'] += $paidInst;
                                $payerStats[$pName]['paid_try'] += $paidInst;
                                $payerStats[$pName]['total_try'] += $totalInst;
                                $payerStats[$pName]['count']++;
                            }
                        }
                    }

                    $loanList = DB::table('bank_loan_installments as i')
                        ->where('i.branch_id', $branchId)
                        ->whereNull('i.deleted_at')
                        ->where('i.status', '!=', 'paid')
                        ->where('i.due_date', '<=', $next14String);
                    if (Schema::hasTable('bank_loans')) {
                        $loanList->leftJoin('bank_loans as l', function ($join) use ($branchId): void {
                            $join->on('l.id', '=', 'i.bank_loan_id')->where('l.branch_id', '=', $branchId);
                            if (Schema::hasColumn('bank_loans', 'deleted_at')) {
                                $join->whereNull('l.deleted_at');
                            }
                        })->addSelect('l.loan_name', 'l.bank_name', 'l.currency');
                    } else {
                        $loanList->addSelect(DB::raw('NULL AS loan_name'), DB::raw('NULL AS bank_name'), DB::raw("'TRY' AS currency"));
                    }
                    $loanInstallments = $loanList
                        ->addSelect('i.id', 'i.installment_no', 'i.due_date', 'i.principal_amount', 'i.interest_amount', 'i.fees_amount', 'i.paid_amount', 'i.status')
                        ->orderBy('i.due_date')
                        ->limit(8)
                        ->get();
                }
            }

            // 4. ÇEK YÖNETİMİ (15 GÜNLÜK VADE KIRILIMI + KİŞİ BAZLI ÇEK ÖDEMESİ)
            if ($access['checks']) {
                $checkQuery = $this->branchTable('checks', $branchId);
                if ($checkQuery) {
                    if ($matchingProjectIds !== null) {
                        $checkQuery->whereIn('project_id', $matchingProjectIds ?: [0]);
                    }
                    $outstandingChecks = (clone $checkQuery)
                        ->whereNotIn('status', ['collected', 'paid', 'returned', 'cancelled']);

                    $stats['checks_received_pending'] = (float) (clone $outstandingChecks)
                        ->where('direction', 'received')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->sum('amount');

                    $stats['checks_issued_pending'] = (float) (clone $outstandingChecks)
                        ->where('direction', 'issued')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->sum('amount');

                    // 15 Gün İçinde Alınan ve Verilen Çek Vadeleri
                    $recDue15Query = (clone $outstandingChecks)
                        ->where('direction', 'received')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->whereNotNull('due_date')
                        ->where('due_date', '<=', $next15String);

                    $stats['checks_received_due_15_amount'] = (float) (clone $recDue15Query)->sum('amount');
                    $stats['checks_received_due_15_count'] = (clone $recDue15Query)->count();
                    $stats['checks_received_due_list'] = (clone $recDue15Query)
                        ->orderBy('due_date')
                        ->limit(3)
                        ->get(['check_no', 'due_date', 'amount', 'related_party'])
                        ->map(fn ($c) => Carbon::parse($c->due_date)->format('d.m') . ' (' . number_format((float) $c->amount, 0, ',', '.') . ' ₺)')
                        ->toArray();

                    $issDue15Query = (clone $outstandingChecks)
                        ->where('direction', 'issued')
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->whereNotNull('due_date')
                        ->where('due_date', '<=', $next15String);

                    $stats['checks_issued_due_15_amount'] = (float) (clone $issDue15Query)->sum('amount');
                    $stats['checks_issued_due_15_count'] = (clone $issDue15Query)->count();
                    $stats['checks_issued_due_list'] = (clone $issDue15Query)
                        ->orderBy('due_date')
                        ->limit(3)
                        ->get(['check_no', 'due_date', 'amount', 'related_party'])
                        ->map(fn ($c) => Carbon::parse($c->due_date)->format('d.m') . ' (' . number_format((float) $c->amount, 0, ',', '.') . ' ₺)')
                        ->toArray();

                    $stats['checks_due_15'] = (clone $outstandingChecks)
                        ->whereBetween('due_date', [$todayString, $next15String])
                        ->count();
                    $stats['checks_due_amount'] = (float) (clone $outstandingChecks)
                        ->whereIn('currency', ['TRY', 'TL'])
                        ->where('due_date', '<=', $next15String)
                        ->sum('amount');
                    $stats['checks_overdue'] = (clone $outstandingChecks)
                        ->where('due_date', '<', $todayString)
                        ->count();

                    $checks = (clone $outstandingChecks)
                        ->select(['id', 'direction', 'check_no', 'bank_name', 'related_party', 'project_name', 'amount', 'currency', 'due_date', 'status'])
                        ->where('due_date', '<=', $next15String)
                        ->orderBy('due_date')
                        ->limit(8)
                        ->get();

                    // Kişi Bazlı Çek Ödemeleri (paid_by sütunu)
                    if (Schema::hasColumn('checks', 'paid_by')) {
                        $paidChecksQ = (clone $checkQuery)
                            ->whereNotIn('status', ['cancelled', 'returned'])
                            ->whereNotNull('paid_by')
                            ->where('paid_by', '!=', '')
                            ->whereIn('currency', ['TRY', 'TL']);

                        if ($filterYear) {
                            $paidChecksQ->whereYear('due_date', $filterYear);
                        }
                        if ($filterMonth) {
                            $paidChecksQ->whereMonth('due_date', $filterMonth);
                        }
                        if ($filterStartDate) {
                            $paidChecksQ->whereDate('due_date', '>=', $filterStartDate);
                        }
                        if ($filterEndDate) {
                            $paidChecksQ->whereDate('due_date', '<=', $filterEndDate);
                        }
                        if ($filterPayer) {
                            $paidChecksQ->where('paid_by', $filterPayer);
                        }

                        foreach ($paidChecksQ->get(['paid_by', 'amount', 'status']) as $chkRow) {
                            $pName = trim((string) $chkRow->paid_by);
                            if (!isset($payerStats[$pName])) {
                                continue;
                            }
                            $cAmt = (float) $chkRow->amount;
                            $payerStats[$pName]['breakdown']['check'] += $cAmt;
                            $payerStats[$pName]['paid_try'] += $cAmt;
                            $payerStats[$pName]['total_try'] += $cAmt;
                            $payerStats[$pName]['count']++;
                        }
                    }
                }
            }

            // 4b. SGK BORÇ VE TAHAKKUK ÖZETİ + KİŞİ BAZLI SGK ÖDEMESİ
            if (Schema::hasTable('sgk_accruals')) {
                $sgkAccrualQuery = $this->branchTable('sgk_accruals', $branchId);
                if ($sgkAccrualQuery) {
                    $openSgk = (clone $sgkAccrualQuery)->whereNotIn('status', ['paid', 'cancelled', 'disputed']);
                    $calcTotalSql = 'CASE WHEN (premium_debt + premium_late_charge) > 0 THEN (premium_debt + premium_late_charge) ELSE principal_amount END';

                    $stats['sgk_open_balance'] = (float) ((clone $openSgk)
                        ->selectRaw("COALESCE(SUM(GREATEST(({$calcTotalSql}) - incentive_amount + adjustment_amount - paid_amount, 0)), 0) AS aggregate")
                        ->value('aggregate') ?? 0);

                    $stats['sgk_overdue_count'] = (clone $openSgk)
                        ->whereNotNull('effective_due_date')
                        ->where('effective_due_date', '<', $todayString)
                        ->count();

                    $stats['sgk_due_15_count'] = (clone $openSgk)
                        ->whereNotNull('effective_due_date')
                        ->whereBetween('effective_due_date', [$todayString, $next15String])
                        ->count();
                }

                if (Schema::hasTable('sgk_payments')) {
                    $sgkPayQuery = $this->branchTable('sgk_payments', $branchId);
                    if ($sgkPayQuery) {
                        $stats['sgk_month_paid'] = (float) (clone $sgkPayQuery)
                            ->where('status', 'recorded')
                            ->whereBetween('payment_date', [$today->copy()->startOfMonth()->toDateString(), $today->copy()->endOfMonth()->toDateString()])
                            ->sum('amount');

                        if (Schema::hasColumn('sgk_payments', 'paid_by')) {
                            $payerSgkQ = (clone $sgkPayQuery)
                                ->where('status', 'recorded')
                                ->whereNotNull('paid_by')
                                ->where('paid_by', '!=', '');

                            if ($filterYear) {
                                $payerSgkQ->whereYear('payment_date', $filterYear);
                            }
                            if ($filterMonth) {
                                $payerSgkQ->whereMonth('payment_date', $filterMonth);
                            }
                            if ($filterStartDate) {
                                $payerSgkQ->whereDate('payment_date', '>=', $filterStartDate);
                            }
                            if ($filterEndDate) {
                                $payerSgkQ->whereDate('payment_date', '<=', $filterEndDate);
                            }
                            if ($filterPayer) {
                                $payerSgkQ->where('paid_by', $filterPayer);
                            }

                            foreach ($payerSgkQ->get(['paid_by', 'amount']) as $sPay) {
                                $pName = trim((string) $sPay->paid_by);
                                if (!isset($payerStats[$pName])) {
                                    continue;
                                }
                                $sAmt = (float) $sPay->amount;
                                $payerStats[$pName]['breakdown']['sgk'] += $sAmt;
                                $payerStats[$pName]['paid_try'] += $sAmt;
                                $payerStats[$pName]['total_try'] += $sAmt;
                                $payerStats[$pName]['count']++;
                            }
                        }
                    }
                }
            }

            // 4c. BORÇ / ALACAK TAKİBİ
            if ($access['debt_tracking']
                && Schema::hasTable('debt_tracking_entries')
                && Schema::hasTable('debt_tracking_payments')) {
                $paymentsByEntry = DB::table('debt_tracking_payments')
                    ->where('branch_id', $branchId)
                    ->when(Schema::hasColumn('debt_tracking_payments', 'deleted_at'), fn ($q) => $q->whereNull('deleted_at'))
                    ->select('entry_id')
                    ->selectRaw('COALESCE(SUM(amount), 0) AS paid_total')
                    ->groupBy('entry_id');

                $debtBase = DB::table('debt_tracking_entries as d')
                    ->leftJoinSub($paymentsByEntry, 'p', function ($join): void {
                        $join->on('p.entry_id', '=', 'd.id');
                    })
                    ->where('d.branch_id', $branchId)
                    ->when(Schema::hasColumn('debt_tracking_entries', 'deleted_at'), fn ($q) => $q->whereNull('d.deleted_at'))
                    ->whereIn('d.status', ['open', 'partial'])
                    ->whereIn('d.currency', ['TRY', 'TL']);

                $stats['debt_taken_outstanding'] = (float) (clone $debtBase)
                    ->where('d.record_type', 'payable')
                    ->selectRaw('COALESCE(SUM(GREATEST(d.amount - COALESCE(p.paid_total, 0), 0)), 0) AS outstanding')
                    ->value('outstanding');

                $stats['debt_given_outstanding'] = (float) (clone $debtBase)
                    ->where('d.record_type', 'receivable')
                    ->selectRaw('COALESCE(SUM(GREATEST(d.amount - COALESCE(p.paid_total, 0), 0)), 0) AS outstanding')
                    ->value('outstanding');
            }

            // 5. DAİRE & MALİK HİZMETLERİ
            if ($access['residential']) {
                $unitQuery = $this->branchTable('estate_units', $branchId);
                if ($unitQuery) {
                    if ($matchingProjectIds !== null && Schema::hasColumn('estate_units', 'project_id')) {
                        $unitQuery->whereIn('project_id', $matchingProjectIds ?: [0]);
                    }
                    $stats['units_total'] = (clone $unitQuery)->count();
                    $stats['units_available'] = (clone $unitQuery)->where('status', 'available')->count();
                    $stats['units_sold'] = (clone $unitQuery)->where('status', 'sold')->count();
                    $statusCounts = (clone $unitQuery)
                        ->select('status', DB::raw('COUNT(*) AS total'))
                        ->groupBy('status')
                        ->get()
                        ->keyBy('status');
                    $unitChart['values'] = [
                        (int) ($statusCounts->get('available')->total ?? 0),
                        (int) ($statusCounts->get('reserved')->total ?? 0),
                        (int) ($statusCounts->get('sold')->total ?? 0),
                        (int) $statusCounts->filter(fn ($item, $key) => !in_array($key, ['available', 'reserved', 'sold'], true))->sum('total'),
                    ];
                }

                $contractQuery = $this->branchTable('estate_sales_contracts', $branchId);
                if ($contractQuery) {
                    $stats['sales_month'] = (int) (clone $contractQuery)
                        ->whereIn('status', ['active', 'signed', 'completed'])
                        ->count();
                }

                $paymentQuery = $this->branchTable('estate_payments', $branchId);
                if ($paymentQuery && Schema::hasTable('estate_sales_contracts')) {
                    $stats['estate_collections_month'] = (float) DB::table('estate_payments as p')
                        ->join('estate_sales_contracts as c', function ($join) use ($branchId): void {
                            $join->on('c.id', '=', 'p.contract_id')->where('c.branch_id', '=', $branchId);
                            if (Schema::hasColumn('estate_sales_contracts', 'deleted_at')) {
                                $join->whereNull('c.deleted_at');
                            }
                        })
                        ->where('p.branch_id', $branchId)
                        ->whereNull('p.deleted_at')
                        ->whereIn('c.currency', ['TRY', 'TL'])
                        ->sum('p.amount');
                }

                $installmentQuery = $this->branchTable('estate_installments', $branchId);
                if ($installmentQuery) {
                    $unpaid = (clone $installmentQuery)
                        ->where('due_date', '<', $todayString)
                        ->whereColumn('paid_amount', '<', 'amount')
                        ->where('status', '!=', 'paid');
                    $stats['installments_overdue'] = (clone $unpaid)->count();
                    if (Schema::hasTable('estate_sales_contracts')) {
                        $stats['installments_overdue_amount'] = (float) DB::table('estate_installments as i')
                            ->join('estate_sales_contracts as c', function ($join) use ($branchId): void {
                                $join->on('c.id', '=', 'i.contract_id')->where('c.branch_id', '=', $branchId);
                                if (Schema::hasColumn('estate_sales_contracts', 'deleted_at')) {
                                    $join->whereNull('c.deleted_at');
                                }
                            })
                            ->where('i.branch_id', $branchId)
                            ->whereNull('i.deleted_at')
                            ->whereIn('c.currency', ['TRY', 'TL'])
                            ->where('i.due_date', '<', $todayString)
                            ->whereColumn('i.paid_amount', '<', 'i.amount')
                            ->where('i.status', '!=', 'paid')
                            ->selectRaw('COALESCE(SUM(CASE WHEN i.amount > i.paid_amount THEN i.amount - i.paid_amount ELSE 0 END), 0) AS outstanding')
                            ->value('outstanding');
                    }

                    if (Schema::hasTable('estate_sales_contracts') && Schema::hasTable('estate_units') && Schema::hasTable('estate_owners')) {
                        $overdueInstallments = DB::table('estate_installments as i')
                            ->leftJoin('estate_sales_contracts as c', function ($join) use ($branchId): void {
                                $join->on('c.id', '=', 'i.contract_id')->where('c.branch_id', '=', $branchId);
                                if (Schema::hasColumn('estate_sales_contracts', 'deleted_at')) {
                                    $join->whereNull('c.deleted_at');
                                }
                            })
                            ->leftJoin('estate_units as u', function ($join) use ($branchId): void {
                                $join->on('u.id', '=', 'c.unit_id')->where('u.branch_id', '=', $branchId);
                                if (Schema::hasColumn('estate_units', 'deleted_at')) {
                                    $join->whereNull('u.deleted_at');
                                }
                            })
                            ->leftJoin('estate_owners as o', function ($join) use ($branchId): void {
                                $join->on('o.id', '=', 'c.owner_id')->where('o.branch_id', '=', $branchId);
                                if (Schema::hasColumn('estate_owners', 'deleted_at')) {
                                    $join->whereNull('o.deleted_at');
                                }
                            })
                            ->where('i.branch_id', $branchId)
                            ->whereNull('i.deleted_at')
                            ->where('i.due_date', '<', $todayString)
                            ->whereColumn('i.paid_amount', '<', 'i.amount')
                            ->where('i.status', '!=', 'paid')
                            ->select('i.id', 'i.installment_no', 'i.due_date', 'i.amount', 'i.paid_amount', 'c.contract_no', 'c.currency', 'u.unit_code', 'o.full_name')
                            ->orderBy('i.due_date')
                            ->limit(8)
                            ->get();
                    }
                }

                $serviceQuery = $this->branchTable('estate_service_requests', $branchId);
                if ($serviceQuery) {
                    $openStatuses = ['open', 'assigned', 'in_progress', 'waiting'];
                    $stats['open_service_requests'] = (clone $serviceQuery)
                        ->whereIn('status', $openStatuses)
                        ->count();

                    if (Schema::hasTable('estate_units')) {
                        $serviceRequests = DB::table('estate_service_requests as sr')
                            ->leftJoin('estate_units as u', function ($join) use ($branchId): void {
                                $join->on('u.id', '=', 'sr.unit_id')->where('u.branch_id', '=', $branchId);
                                if (Schema::hasColumn('estate_units', 'deleted_at')) {
                                    $join->whereNull('u.deleted_at');
                                }
                            })
                            ->where('sr.branch_id', $branchId)
                            ->whereNull('sr.deleted_at')
                            ->whereIn('sr.status', $openStatuses)
                            ->select('sr.id', 'sr.request_no', 'sr.title', 'sr.priority', 'sr.status', 'sr.reported_at', 'sr.assigned_to', 'u.unit_code')
                            ->orderByRaw("CASE WHEN sr.priority = 'urgent' THEN 0 WHEN sr.priority = 'high' THEN 1 ELSE 2 END")
                            ->orderBy('sr.reported_at')
                            ->limit(8)
                            ->get();
                    }
                }

                $warrantyQuery = $this->branchTable('estate_warranties', $branchId);
                if ($warrantyQuery) {
                    $stats['warranties_expiring'] = (clone $warrantyQuery)
                        ->whereNotNull('warranty_end')
                        ->whereBetween('warranty_end', [$todayString, $next30String])
                        ->count();
                }

                $handoverQuery = $this->branchTable('estate_handovers', $branchId);
                if ($handoverQuery) {
                    $stats['planned_handovers'] = (clone $handoverQuery)
                        ->whereIn('status', ['planned', 'in_progress'])
                        ->count();
                }
            }
        }

        return view('admin.dashboard', compact(
            'access',
            'branchId',
            'branchName',
            'stats',
            'payerStats',
            'periodLabel',
            'filterProjectsList',
            'yearsList',
            'monthly',
            'unitChart',
            'projects',
            'tasks',
            'checks',
            'loanInstallments',
            'bankAccountsOverview',
            'overdueInstallments',
            'serviceRequests',
            'recentFinance'
        ));
    }

    private function canAccessModule($user, string $module): bool
    {
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'hasRole') && $user->hasRole('admin')) {
            return true;
        }

        return method_exists($user, 'hasPermissionToAccessModule')
            && (bool) $user->hasPermissionToAccessModule($module);
    }

    private function branchTable(string $table, int $branchId): ?Builder
    {
        if (!Schema::hasTable($table) || !Schema::hasColumn($table, 'branch_id')) {
            return null;
        }

        $query = DB::table($table)->where($table . '.branch_id', $branchId);

        if (Schema::hasColumn($table, 'deleted_at')) {
            $query->whereNull($table . '.deleted_at');
        }

        return $query;
    }
}